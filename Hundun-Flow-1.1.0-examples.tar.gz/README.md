# Hundun-Flow 1.1.0 examples

`g` is the JL4 gas example and `cf` is the kerosene spray example.
Each case README supplies its initial state and launch commands.
`g-restart` is the accepted step-1 gas checkpoint created by this release.

With the runtime bundle at `$HUNDUN`, continue the gas example using:

```sh
"$HUNDUN/mpirun" -n 2 "$HUNDUN/run" run g --restart g-restart --output next --steps 1 --restart-interval 1
```

Use a fresh output directory for each run. The bundle selects its private dependencies.
