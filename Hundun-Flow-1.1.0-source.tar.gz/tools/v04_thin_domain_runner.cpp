// SPDX-License-Identifier: Apache-2.0
// Developed by WANG YUDONG | Email: wangyudong@buaa.edu.cn | Github/Wechat: windcicada | Year.M: 2026.09

#include <fcntl.h>
#include <mpi.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <locale>
#include <optional>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

// Optional LD_PRELOAD observer: absent in ordinary runs and never a required
// product dependency. The observer wraps PMPI without adding collectives.
extern "C" void hundun_v04_observe_step(std::uint64_t, int)
    __attribute__((weak));

#include "app_evidence_detail.hpp"
#include "app_identity_detail.hpp"
#include "hundun/v04_app.hpp"
#include "hundun/v04_case.hpp"
#include "hundun/v04_mpi_runtime.hpp"
#include "hundun/v04_physics.hpp"
#include "local_timing_detail.hpp"
#include "io_output_detail.hpp"

namespace {

namespace fs = std::filesystem;
using namespace hundun::v04;

constexpr std::uint32_t kRunnerInput = 10901U;
constexpr std::string_view kSpecMagic =
    "HUNDUN_V04_LITERATURE_STATISTICS_V1";
constexpr std::string_view kRunMagic =
    "HUNDUN_V04_THIN_DOMAIN_RUN_V1";
constexpr std::string_view kStatisticsMagic =
    "HUNDUN_V04_THIN_DOMAIN_STATISTICS_V1";
constexpr std::string_view kAccumulatorMagic =
    "HUNDUN_V04_THIN_DOMAIN_ACCUMULATOR_V3";
constexpr std::string_view kStepAccumulatorMagic =
    "HUNDUN_V04_THIN_DOMAIN_ACCUMULATOR_V2";
constexpr std::string_view kLegacyAccumulatorMagic =
    "HUNDUN_V04_THIN_DOMAIN_ACCUMULATOR_V1";
constexpr std::string_view kCheckpointMagic =
    "HUNDUN_V04_THIN_DOMAIN_CHECKPOINT_V1";

static_assert(kRuntimePressureEnergyRefinementCapacity ==
              kPressureEnergyRefinementCapacity);

struct Options {
  fs::path spec;
  fs::path case_root;
  fs::path run_root;
  fs::path restart_root;
  std::uint64_t steps{};
  std::uint64_t visit_interval{};
  bool have_steps{};
  bool have_visit_interval{};
  bool dry_plan{};
  bool self_test{};
  bool observe_performance{};
  bool observe_mg_cost{};
  bool observe_fgmres_recovery{};
  DriverCellTraceWindow trace_window{};
  bool restart_method_recovery{};
  bool have_restart_development_steps{};
  std::uint64_t restart_development_steps{};
  RestartStorageCompatibility restart_storage_compatibility{
      RestartStorageCompatibility::strict};
};

struct StatisticsSpec {
  std::uint64_t development_steps{};
  std::uint64_t collection_end_step{};
  std::uint64_t checkpoint_interval{};
  double rho_ref{};
  double u_ref{};
  double diameter{};
  double span{};
  double cylinder_center_x{};
  std::vector<double> station_x_over_d;
};

struct Bracket {
  std::int32_t lower{};
  std::int32_t upper{};
  double upper_weight{};
};

struct RuntimeGeometry {
  std::vector<Bracket> station_brackets;
  Bracket centerline_bracket{};
};

enum class StatisticsResetReason : std::uint8_t {
  fresh, method_recovery, missing_history, legacy_statistics
};

const char* reset_reason_name(StatisticsResetReason reason) noexcept {
  switch (reason) {
    case StatisticsResetReason::fresh: return "fresh";
    case StatisticsResetReason::method_recovery: return "method_recovery";
    case StatisticsResetReason::missing_history: return "missing_history";
    case StatisticsResetReason::legacy_statistics: return "legacy_statistics";
  }
  return "invalid";
}

struct StatisticsEpoch {
  std::uint64_t start_step{};
  std::uint64_t development_steps{};
  std::uint64_t sampling_start_step{2U};
  std::uint64_t discarded_samples{};
  StatisticsResetReason reason{StatisticsResetReason::fresh};
  RuntimeSha256Digest source_manifest{};
};

struct Accumulator {
  std::vector<double> profile;
  std::vector<double> centerline;
  std::uint64_t sample_steps{};
  StatisticsEpoch epoch{};
};

struct ThermoExtrema {
  double pressure_min{};
  double pressure_max{};
  double temperature_min{};
  double temperature_max{};
  double density_min{};
  double density_max{};
  std::array<std::uint64_t, 2U> region_count{};
  // Region-major p-/p+/T-/T+/rho-/rho+. Maximums are negated during MIN.
  std::array<double, 12U> regional{};
  std::array<std::uint64_t, 12U> region_cell{};
};

struct RestartBinding {
  fs::path statistics;
  fs::path accumulator;
  std::string generation;
};

std::string_view ibm_reconstruction_policy_name(
    IbmReconstructionPolicy policy) noexcept {
  switch (policy) {
    case IbmReconstructionPolicy::strict_quadratic:
      return "strict_quadratic";
    case IbmReconstructionPolicy::adaptive_order:
      return "adaptive_order";
  }
  return "invalid";
}

bool parse_u64(std::string_view text, std::uint64_t& out) {
  if (text.empty() || text.front() == '-') return false;
  errno = 0;
  char* end = nullptr;
  const std::string owned(text);
  const unsigned long long value = std::strtoull(owned.c_str(), &end, 10);
  if (errno != 0 || end != owned.c_str() + owned.size()) return false;
  out = static_cast<std::uint64_t>(value);
  return true;
}

bool parse_real(std::string_view text, double& out) {
  if (text.empty()) return false;
  errno = 0;
  char* end = nullptr;
  const std::string owned(text);
  const double value = std::strtod(owned.c_str(), &end);
  if (errno != 0 || end != owned.c_str() + owned.size() ||
      !std::isfinite(value))
    return false;
  out = value;
  return true;
}

bool parse_options(int argc, char** argv, Options& out) {
  for (int index = 1; index < argc; ++index) {
    const std::string_view token(argv[index]);
    if (token == "--dry-plan") {
      if (out.dry_plan) return false;
      out.dry_plan = true;
    } else if (token == "--self-test") {
      if (out.self_test) return false;
      out.self_test = true;
    } else if (token == "--observe-performance") {
      if (out.observe_performance) return false;
      out.observe_performance = true;
    } else if (token == "--observe-mg-cost") {
      if (out.observe_mg_cost) return false;
      out.observe_mg_cost = true;
    } else if (token == "--observe-fgmres-recovery") {
      if (out.observe_fgmres_recovery) return false;
      out.observe_fgmres_recovery = true;
    } else if (token == "--restart-method-recovery") {
      if (out.restart_method_recovery) return false;
      out.restart_method_recovery = true;
    } else {
      if (index + 1 >= argc) return false;
      const std::string_view value(argv[++index]);
      if (token == "--spec" && out.spec.empty()) {
        out.spec = value;
      } else if (token == "--case-root" && out.case_root.empty()) {
        out.case_root = value;
      } else if (token == "--run-root" && out.run_root.empty()) {
        out.run_root = value;
      } else if (token == "--restart-root" && out.restart_root.empty()) {
        out.restart_root = value;
      } else if (token == "--restart-storage-compatibility" &&
                 out.restart_storage_compatibility ==
                     RestartStorageCompatibility::strict &&
                 value == "mg-bundle-ghost-v1") {
        out.restart_storage_compatibility =
            RestartStorageCompatibility::mg_bundle_ghost_v1;
      } else if (token == "--steps" && !out.have_steps &&
                 parse_u64(value, out.steps) && out.steps != 0U) {
        out.have_steps = true;
      } else if (token == "--trace-first" && out.trace_window.first_step == 0U &&
                 parse_u64(value, out.trace_window.first_step) && out.trace_window.first_step != 0U) {
      } else if (token == "--trace-last" && out.trace_window.last_step == 0U &&
                 parse_u64(value, out.trace_window.last_step) && out.trace_window.last_step != 0U) {
      } else if (token == "--trace-cell" && out.trace_window.count < 2U) {
        const auto first = value.find(',');
        const auto second = first == std::string_view::npos ? first : value.find(',', first + 1U);
        std::uint64_t x = 0U, y = 0U, z = 0U;
        if (first == std::string_view::npos || second == std::string_view::npos ||
            !parse_u64(value.substr(0U, first), x) ||
            !parse_u64(value.substr(first + 1U, second - first - 1U), y) ||
            !parse_u64(value.substr(second + 1U), z) || x > INT_MAX || y > INT_MAX || z > INT_MAX)
          return false;
        out.trace_window.cells[out.trace_window.count++] = {
            static_cast<int>(x), static_cast<int>(y), static_cast<int>(z)};
      } else if (token == "--restart-development-steps" &&
                 !out.have_restart_development_steps &&
                 parse_u64(value, out.restart_development_steps)) {
        out.have_restart_development_steps = true;
      } else if (token == "--visit-interval" && !out.have_visit_interval &&
                 parse_u64(value, out.visit_interval)) {
        out.have_visit_interval = true;
      } else {
        return false;
      }
    }
  }
  if ((out.trace_window.count == 0U &&
       (out.trace_window.first_step != 0U || out.trace_window.last_step != 0U)) ||
      (out.trace_window.count != 0U &&
       (out.trace_window.first_step == 0U || out.trace_window.last_step < out.trace_window.first_step ||
        out.self_test || out.dry_plan))) return false;
  if (out.restart_storage_compatibility !=
          RestartStorageCompatibility::strict &&
      out.restart_root.empty())
    return false;
  if (out.restart_method_recovery &&
      (out.restart_root.empty() || out.restart_storage_compatibility !=
                                       RestartStorageCompatibility::strict))
    return false;
  if (out.have_restart_development_steps && !out.restart_method_recovery)
    return false;
  if (out.observe_mg_cost && !out.observe_performance) return false;
  if (out.observe_fgmres_recovery && !out.observe_performance) return false;
  if (out.self_test)
    return !out.observe_performance && !out.dry_plan && out.spec.empty() &&
           out.case_root.empty() && out.run_root.empty() &&
           out.restart_root.empty() && !out.have_steps &&
           !out.have_visit_interval;
  if (out.spec.empty() || out.case_root.empty()) return false;
  if (out.dry_plan)
    return !out.observe_performance && out.run_root.empty() &&
           out.restart_root.empty() && !out.have_steps;
  return !out.run_root.empty() && out.have_steps;
}

bool parse_spec(const fs::path& path, StatisticsSpec& out,
                std::string& error) {
  std::ifstream input(path);
  if (!input) {
    error = "cannot_open_spec";
    return false;
  }
  std::string line;
  if (!std::getline(input, line) || line != kSpecMagic) {
    error = "invalid_spec_magic";
    return false;
  }
  StatisticsSpec candidate;
  bool development = false;
  bool collection_end = false;
  bool checkpoint = false;
  bool rho = false;
  bool velocity = false;
  bool diameter = false;
  bool span = false;
  bool center = false;
  bool ended = false;
  while (std::getline(input, line)) {
    if (line.empty()) continue;
    if (ended) {
      error = "data_after_end";
      return false;
    }
    std::istringstream row(line);
    std::string key;
    std::string value;
    std::string extra;
    if (!(row >> key)) continue;
    if (key == "end") {
      if (row >> extra) {
        error = "invalid_end";
        return false;
      }
      ended = true;
      continue;
    }
    if (!(row >> value) || row >> extra) {
      error = "invalid_spec_row";
      return false;
    }
    if (key == "development_steps" && !development) {
      development = parse_u64(value, candidate.development_steps);
      if (!development) error = "invalid_development_steps";
    } else if (key == "collection_end_step" && !collection_end) {
      collection_end = parse_u64(value, candidate.collection_end_step);
      if (!collection_end) error = "invalid_collection_end_step";
    } else if (key == "checkpoint_interval" && !checkpoint) {
      checkpoint = parse_u64(value, candidate.checkpoint_interval) &&
                   candidate.checkpoint_interval != 0U;
      if (!checkpoint) error = "invalid_checkpoint_interval";
    } else if (key == "rho_ref" && !rho) {
      rho = parse_real(value, candidate.rho_ref) && candidate.rho_ref > 0.0;
      if (!rho) error = "invalid_rho_ref";
    } else if (key == "u_ref" && !velocity) {
      velocity = parse_real(value, candidate.u_ref) && candidate.u_ref > 0.0;
      if (!velocity) error = "invalid_u_ref";
    } else if (key == "diameter" && !diameter) {
      diameter = parse_real(value, candidate.diameter) &&
                 candidate.diameter > 0.0;
      if (!diameter) error = "invalid_diameter";
    } else if (key == "span" && !span) {
      span = parse_real(value, candidate.span) && candidate.span > 0.0;
      if (!span) error = "invalid_span";
    } else if (key == "cylinder_center_x" && !center) {
      center = parse_real(value, candidate.cylinder_center_x);
      if (!center) error = "invalid_cylinder_center_x";
    } else if (key == "station_x_over_d") {
      double station = 0.0;
      if (!parse_real(value, station)) {
        error = "invalid_station";
        return false;
      }
      candidate.station_x_over_d.push_back(station);
    } else {
      error = "unknown_or_duplicate_key";
      return false;
    }
    if (!error.empty()) return false;
  }
  if (!ended || !development || !collection_end || !checkpoint || !rho ||
      !velocity || !diameter || !span || !center ||
      candidate.station_x_over_d.empty() ||
      candidate.collection_end_step <= candidate.development_steps) {
    error = "incomplete_or_inconsistent_spec";
    return false;
  }
  for (std::size_t index = 1U; index < candidate.station_x_over_d.size();
       ++index) {
    if (!(candidate.station_x_over_d[index] >
          candidate.station_x_over_d[index - 1U])) {
      error = "stations_not_strictly_increasing";
      return false;
    }
  }
  out = std::move(candidate);
  return true;
}

std::uint64_t mix(std::uint64_t hash, std::uint64_t value) {
  hash ^= value + UINT64_C(0x9e3779b97f4a7c15) + (hash << 6U) +
          (hash >> 2U);
  return hash;
}

std::uint64_t bits(double value) {
  std::uint64_t result = 0U;
  std::memcpy(&result, &value, sizeof(result));
  return result;
}

std::uint64_t spec_fingerprint(const StatisticsSpec& spec) {
  std::uint64_t hash = UINT64_C(0x5448494e53544154);
  hash = mix(hash, spec.development_steps);
  hash = mix(hash, spec.collection_end_step);
  hash = mix(hash, spec.checkpoint_interval);
  hash = mix(hash, bits(spec.rho_ref));
  hash = mix(hash, bits(spec.u_ref));
  hash = mix(hash, bits(spec.diameter));
  hash = mix(hash, bits(spec.span));
  hash = mix(hash, bits(spec.cylinder_center_x));
  hash = mix(hash, spec.station_x_over_d.size());
  for (double station : spec.station_x_over_d)
    hash = mix(hash, bits(station));
  return hash == 0U ? 1U : hash;
}

bool all_true(MPI_Comm communicator, bool local) {
  int value = local ? 1 : 0;
  return MPI_Allreduce(MPI_IN_PLACE, &value, 1, MPI_INT, MPI_MIN,
                       communicator) == MPI_SUCCESS &&
         value == 1;
}

// Local work only: never wrap a callback that itself communicates. Every rank
// reaches this decision even when a path, vector or encoder throws locally.
template <class Work>
bool local_stage(MPI_Comm communicator, Work&& work) noexcept {
  bool okay = false;
  try {
    okay = work();
  } catch (...) {
    okay = false;
  }
  return all_true(communicator, okay);
}

bool consensus_u64(MPI_Comm communicator, std::uint64_t value) {
  std::uint64_t minimum = value;
  std::uint64_t maximum = value;
  return MPI_Allreduce(MPI_IN_PLACE, &minimum, 1, MPI_UINT64_T, MPI_MIN,
                       communicator) == MPI_SUCCESS &&
         MPI_Allreduce(MPI_IN_PLACE, &maximum, 1, MPI_UINT64_T, MPI_MAX,
                       communicator) == MPI_SUCCESS &&
         minimum == maximum;
}

bool write_exclusive(const fs::path& path, std::string_view text) {
  return detail::output_write_file(
      path, reinterpret_cast<const std::uint8_t*>(text.data()), text.size(),
      detail::OutputFileMode::exclusive, nullptr, 0444);
}

// Independent cold authority for rank/level coverage, not inferred from logs.
// One bounded wire per rank; no field storage and no hot-path communication.
bool write_mg_layout(MPI_Comm communicator, int rank, int ranks,
                     const ProductDriver& driver, const fs::path& root,
                     RuntimeSha256Digest& digest) {
  constexpr std::size_t width = 1U + 8U * kMgMaximumLevels;
  static_assert(width <= INT_MAX);
  std::array<std::int32_t, width> wire{};
  std::vector<std::int32_t> gathered;
  if (!local_stage(communicator, [&] {
        const auto view = driver.pressure_mg_profile();
        if (!view.enabled || view.level_count == 0U ||
            view.level_count > kMgMaximumLevels || ranks <= 0) return false;
        wire[0] = static_cast<std::int32_t>(view.level_count);
        for (std::size_t n = 0U; n < view.level_count; ++n) {
          MgLevelView level;
          if (!driver.pressure_mg_level(n, level)) return false;
          const std::array<std::int32_t, 8U> entry{{
              level.global_shape.x, level.global_shape.y, level.global_shape.z,
              level.local_shape.x, level.local_shape.y, level.local_shape.z,
              static_cast<std::int32_t>(level.coarsening), level.line_axis_mask}};
          std::copy(entry.begin(), entry.end(), wire.begin() + 1U + 8U * n);
        }
        if (rank == 0) {
          if (static_cast<std::size_t>(ranks) > gathered.max_size() / width)
            return false;
          gathered.resize(static_cast<std::size_t>(ranks) * width);
        }
        return true;
      })) return false;
  const bool gathered_ok = MPI_Gather(wire.data(), static_cast<int>(width), MPI_INT32_T,
      rank == 0 ? gathered.data() : nullptr, static_cast<int>(width), MPI_INT32_T,
      0, communicator) == MPI_SUCCESS;
  if (!all_true(communicator, gathered_ok)) return false;
  return local_stage(communicator, [&] {
    if (rank != 0) return true;
    std::ostringstream text;
    text.exceptions(std::ios::badbit | std::ios::failbit);
    text.imbue(std::locale::classic());
    text << "HUNDUN_MG_LAYOUT_V1\nexpected_ranks " << ranks
         << "\nmaximum_levels " << kMgMaximumLevels << '\n';
    for (int r = 0; r < ranks; ++r) {
      const auto offset = static_cast<std::size_t>(r) * width;
      const auto count = gathered[offset];
      text << "rank " << r << ' ' << count << '\n';
      for (std::int32_t n = 0; n < count; ++n) {
        text << "level " << r << ' ' << n;
        for (std::size_t c = 0U; c < 8U; ++c)
          text << ' ' << gathered[offset + 1U + 8U * static_cast<std::size_t>(n) + c];
        text << '\n';
      }
    }
    text << "end\n";
    const std::string encoded = text.str();
    return detail::runtime_sha256_bytes(
        {reinterpret_cast<const std::uint8_t*>(encoded.data()), encoded.size()}, digest) &&
        write_exclusive(root / "mg-layout.meta", encoded);
  });
}

void write_mg_loop(std::ostream& out, const MgSolveProfile& mg) {
  out << ',' << mg.enabled << ',' << mg.complete << ',' << mg.attempts
      << ',' << mg.successes << ',' << mg.failures << ',' << mg.apply_nanoseconds
      << ',' << mg.reduction_nanoseconds << ',' << mg.halo_wait_nanoseconds
      << ',' << mg.halo_control_nanoseconds << ',' << mg.halo_control_calls;
  for (const auto* phase : {&mg.pre_smooth, &mg.residual, &mg.restriction,
                           &mg.prolongation, &mg.post_smooth, &mg.terminal, &mg.direct_mpi})
    out << ',' << phase->calls << ',' << phase->nanoseconds;
  out << ',' << mg.finest_pre_smooth_nanoseconds
      << ',' << mg.finest_post_smooth_nanoseconds;
}

// A value copy is needed before advance: the public view is borrowed, not history.
MgApplyProfile mg_snapshot(const ProductDriver& driver) noexcept {
  const auto view = driver.pressure_mg_profile();
  MgApplyProfile result;
  if (view.cumulative != nullptr) result = *view.cumulative;
  else {
    result.enabled = view.enabled;
    result.level_count = view.level_count;
  }
  result.complete = result.complete && view.enabled &&
      view.initialized == (view.cumulative != nullptr) &&
      result.enabled && result.level_count == view.level_count &&
      view.level_count != 0U && view.level_count <= kMgMaximumLevels;
  return result;
}

// Only observation can become incomplete. Counter discontinuities never alter
// the accepted state or the numerical Status. Compute all deltas before writing
// any complete flag, so a later bad level also invalidates the total row.
void write_mg_step(std::ostream& out, std::uint64_t step, int rank,
                   const ProductDriver& driver, const MgApplyProfile& before,
                   const RuntimeSha256Digest& source) {
  auto change = mg_snapshot(driver);
  change.complete = change.complete && before.complete && before.enabled &&
      before.level_count == change.level_count;
  const auto subtract = [&](std::uint64_t& value, std::uint64_t old) noexcept {
    if (old == UINT64_MAX || value == UINT64_MAX || value < old) {
      change.complete = false;
      value = 0U;
    } else value -= old;
  };
  subtract(change.attempts, before.attempts);
  subtract(change.successes, before.successes);
  subtract(change.failures, before.failures);
  subtract(change.apply_nanoseconds, before.apply_nanoseconds);
  subtract(change.reduction_nanoseconds, before.reduction_nanoseconds);
  for (std::size_t n = 0U; n < std::min(change.level_count, kMgMaximumLevels); ++n) {
    auto& now = change.levels[n];
    const auto& old = before.levels[n];
    subtract(now.visits, old.visits);
    const auto phase = [&](MgPhaseProfile& value, const MgPhaseProfile& first) noexcept {
      subtract(value.calls, first.calls);
      subtract(value.nanoseconds, first.nanoseconds);
    };
    phase(now.pre_smooth, old.pre_smooth);
    phase(now.residual, old.residual);
    phase(now.restriction, old.restriction);
    phase(now.prolongation, old.prolongation);
    phase(now.post_smooth, old.post_smooth);
    phase(now.terminal, old.terminal);
    phase(now.direct_mpi, old.direct_mpi);
    subtract(now.halo_wait_nanoseconds, old.halo_wait_nanoseconds);
    subtract(now.halo_control_nanoseconds, old.halo_control_nanoseconds);
    subtract(now.halo_control_calls, old.halo_control_calls);
  }
  const bool initialized = driver.pressure_mg_profile().initialized;
  const MgLevelApplyProfile empty;
  // Total (-1) and level rows have disjoint columns, avoiding repeated totals.
  for (int n = -1; n < static_cast<int>(std::min(change.level_count, kMgMaximumLevels)); ++n) {
    const bool total = n == -1;
    const auto& level = total ? empty : change.levels[static_cast<std::size_t>(n)];
    out << step << ',' << rank << ',' << n << ',' << initialized << ',' << change.complete
        << ',' << (total ? change.attempts : 0U)
        << ',' << (total ? change.successes : 0U)
        << ',' << (total ? change.failures : 0U)
        << ',' << (total ? change.apply_nanoseconds : 0U)
        << ',' << (total ? change.reduction_nanoseconds : 0U)
        << ',' << level.visits;
    for (const auto* p : {&level.pre_smooth, &level.residual, &level.restriction,
                         &level.prolongation, &level.post_smooth, &level.terminal, &level.direct_mpi})
      out << ',' << p->calls << ',' << p->nanoseconds;
    out << ',' << level.halo_wait_nanoseconds << ',' << level.halo_control_nanoseconds
        << ',' << level.halo_control_calls << ',' << source.data() << '\n';
  }
}

class EvidenceFile {
 public:
  EvidenceFile() = default;
  EvidenceFile(const EvidenceFile&) = delete;
  EvidenceFile& operator=(const EvidenceFile&) = delete;

  ~EvidenceFile() {
    if (descriptor_ >= 0) ::close(descriptor_);
  }

  bool open_exclusive(const fs::path& path) noexcept {
    if (descriptor_ >= 0) return false;
    do {
      descriptor_ = ::open(path.c_str(),
                           O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0644);
    } while (descriptor_ < 0 && errno == EINTR);
    return descriptor_ >= 0;
  }

  bool append(std::string_view text) noexcept {
    if (descriptor_ < 0) return false;
    std::size_t cursor = 0U;
    while (cursor < text.size()) {
      const ssize_t count =
          ::write(descriptor_, text.data() + cursor, text.size() - cursor);
      if (count < 0 && errno == EINTR) continue;
      if (count <= 0) return false;
      cursor += static_cast<std::size_t>(count);
    }
    return true;
  }

  bool sync() noexcept {
    if (descriptor_ < 0) return false;
    int result;
    do { result = ::fsync(descriptor_); } while (result != 0 && errno == EINTR);
    return result == 0;
  }

  bool close() noexcept {
    if (descriptor_ < 0) return false;
    const int descriptor = descriptor_;
    descriptor_ = -1;
    return ::close(descriptor) == 0;
  }

  bool is_open() const noexcept { return descriptor_ >= 0; }

 private:
  int descriptor_{-1};
};

// Buffered log completion, NOT a checkpoint durability barrier. Keep the first
// local failure even if a subsequent close clears/changes stream state. This
// function runs on failure exits too, without changing committed solver state.
bool complete_logs(MPI_Comm communicator, int rank,
                   const std::array<std::ofstream*, 8U>& streams,
                   EvidenceFile& evidence) {
  constexpr std::array<const char*, 9U> names{{"force.csv", "health.csv",
      "conservation.csv", "probe.csv", "performance.csv", "solver-rank.csv",
      "cell-trace-rank.csv", "mg-rank.csv", "evidence.jsonl"}};
  constexpr std::array<const char*, 3U> operations{{"write", "flush", "close"}};
  std::array<int, 3U> first{{-1, 0, 0}};
  const auto record = [&](std::size_t stream, int operation) noexcept {
    if (first[0U] < 0)
      first = {{static_cast<int>(stream), operation, errno == 0 ? EIO : errno}};
  };
  for (std::size_t i = 0U; i < streams.size(); ++i) {
    auto& stream = *streams[i];
    if (!stream.is_open()) continue;  // Disabled outputs are not failed outputs.
    errno = 0;
    if (!stream) record(i, 0);
    try {
      stream.flush();
      if (!stream) record(i, 1);
    } catch (...) { record(i, 1); }
    errno = 0;
    try {
      stream.close();
      if (!stream) record(i, 2);
    } catch (...) { record(i, 2); }
  }
  errno = 0;
  if (evidence.is_open() && !evidence.close()) record(streams.size(), 2);
  int owner = first[0U] < 0 ? INT_MAX : rank;
  int first_rank = INT_MAX;
  if (MPI_Allreduce(&owner, &first_rank, 1, MPI_INT, MPI_MIN, communicator) != MPI_SUCCESS)
    return false;
  if (first_rank == INT_MAX) return true;
  if (MPI_Bcast(first.data(), static_cast<int>(first.size()), MPI_INT,
                first_rank, communicator) != MPI_SUCCESS) return false;
  if (rank == 0)
    std::cerr << "log_completion_failure rank=" << first_rank
              << " stream=" << names[static_cast<std::size_t>(first[0U])]
              << " operation=" << operations[static_cast<std::size_t>(first[1U])]
              << " errno=" << first[2U] << '\n';
  return false;
}

bool sync_directory(const fs::path& path) {
  return detail::output_sync_directory(path);
}

std::string checkpoint_name(std::uint64_t step, std::string_view suffix) {
  std::ostringstream name;
  name.exceptions(std::ios::badbit | std::ios::failbit);
  name << "step-" << std::setw(20) << std::setfill('0') << step << suffix;
  return name.str();
}

bool bracket(Span<const double> coordinates, double target, Bracket& out) {
  if (coordinates.data == nullptr || coordinates.size == 0U ||
      !std::isfinite(target) || target < coordinates.data[0] ||
      target > coordinates.data[coordinates.size - 1U])
    return false;
  const double* begin = coordinates.data;
  const double* end = begin + coordinates.size;
  const double* found = std::lower_bound(begin, end, target);
  if (found != end && *found == target) {
    const auto index = static_cast<std::int32_t>(found - begin);
    out = {index, index, 0.0};
    return true;
  }
  if (found == begin || found == end) return false;
  const auto upper = static_cast<std::int32_t>(found - begin);
  const auto lower = upper - 1;
  const double width = coordinates.data[upper] - coordinates.data[lower];
  if (!(width > 0.0)) return false;
  const double weight = (target - coordinates.data[lower]) / width;
  if (!std::isfinite(weight) || weight < 0.0 || weight > 1.0) return false;
  out = {lower, upper, weight};
  return true;
}

const SnapshotFieldView* find_field(const CommittedOutputSnapshot& snapshot,
                                    std::string_view name,
                                    std::uint8_t components) {
  const SnapshotFieldView* result = nullptr;
  for (std::size_t index = 0U; index < snapshot.fields.size; ++index) {
    const SnapshotFieldView& field = snapshot.fields.data[index];
    if (field.stable_name == name) {
      if (result != nullptr || field.values.components != components)
        return nullptr;
      result = &field;
    }
  }
  return result;
}

bool prepare_geometry(const StatisticsSpec& spec,
                      const CommittedOutputSnapshot& snapshot,
                      RuntimeGeometry& out) {
  if (!snapshot.committed || snapshot.geometry == nullptr) return false;
  RuntimeGeometry candidate;
  const Span<const double> x = snapshot.geometry->x().centres();
  const Span<const double> y = snapshot.geometry->y().centres();
  candidate.station_brackets.resize(spec.station_x_over_d.size());
  for (std::size_t index = 0U; index < spec.station_x_over_d.size(); ++index) {
    const double target = spec.cylinder_center_x +
                          spec.station_x_over_d[index] * spec.diameter;
    if (!bracket(x, target, candidate.station_brackets[index])) return false;
  }
  if (!bracket(y, 0.0, candidate.centerline_bracket)) return false;
  out = std::move(candidate);
  return true;
}

bool owns(std::int32_t global, std::int32_t begin, std::int32_t cells) {
  return global >= begin && global < begin + cells;
}

bool add_sample(const StatisticsSpec& spec, const RuntimeGeometry& runtime,
                const CommittedOutputSnapshot& snapshot, double dt,
                Accumulator& accumulator) {
  const SnapshotFieldView* velocity = find_field(snapshot, "U", 3U);
  if (velocity == nullptr || snapshot.geometry == nullptr ||
      !std::isfinite(dt) || dt <= 0.0) return false;
  const ConstFieldView u = velocity->values;
  const MeshPatch patch = snapshot.patch;
  const Int3 global = snapshot.geometry->global_cells();
  const std::size_t expected_profile =
      spec.station_x_over_d.size() * static_cast<std::size_t>(global.y) * 6U;
  const std::size_t expected_center = static_cast<std::size_t>(global.x) * 3U;
  if (u.interior.x != patch.cells.x || u.interior.y != patch.cells.y ||
      u.interior.z != patch.cells.z || global.x <= 0 || global.y <= 0 ||
      global.z <= 0 || accumulator.profile.size() != expected_profile ||
      accumulator.centerline.size() != expected_center)
    return false;

  for (std::size_t station = 0U; station < runtime.station_brackets.size();
       ++station) {
    const Bracket selected = runtime.station_brackets[station];
    const std::array<std::int32_t, 2U> planes{{selected.lower,
                                               selected.upper}};
    const std::array<double, 2U> weights{{1.0 - selected.upper_weight,
                                          selected.upper_weight}};
    const std::size_t plane_count = selected.lower == selected.upper ? 1U : 2U;
    for (std::size_t side = 0U; side < plane_count; ++side) {
      const std::int32_t gx = planes[side];
      const double weight = dt * weights[side];
      if (weight == 0.0 || !owns(gx, patch.begin.x, patch.cells.x)) continue;
      const std::int32_t lx = gx - patch.begin.x;
      for (std::int32_t lz = 0; lz < patch.cells.z; ++lz) {
        for (std::int32_t ly = 0; ly < patch.cells.y; ++ly) {
          const double ux = u.unchecked({lx, ly, lz}, 0U);
          const double uy = u.unchecked({lx, ly, lz}, 1U);
          if (!std::isfinite(ux) || !std::isfinite(uy)) return false;
          const std::size_t gy =
              static_cast<std::size_t>(patch.begin.y + ly);
          const std::size_t base =
              (station * static_cast<std::size_t>(global.y) + gy) * 6U;
          accumulator.profile[base] += weight;
          accumulator.profile[base + 1U] += weight * ux;
          accumulator.profile[base + 2U] += weight * uy;
          accumulator.profile[base + 3U] += weight * ux * ux;
          accumulator.profile[base + 4U] += weight * uy * uy;
          accumulator.profile[base + 5U] += weight * ux * uy;
        }
      }
    }
  }

  const Bracket selected = runtime.centerline_bracket;
  const std::array<std::int32_t, 2U> planes{{selected.lower, selected.upper}};
  const std::array<double, 2U> weights{{1.0 - selected.upper_weight,
                                        selected.upper_weight}};
  const std::size_t plane_count = selected.lower == selected.upper ? 1U : 2U;
  for (std::size_t side = 0U; side < plane_count; ++side) {
    const std::int32_t gy = planes[side];
    const double weight = dt * weights[side];
    if (weight == 0.0 || !owns(gy, snapshot.patch.begin.y,
                               snapshot.patch.cells.y))
      continue;
    const std::int32_t ly = gy - snapshot.patch.begin.y;
    for (std::int32_t lz = 0; lz < snapshot.patch.cells.z; ++lz) {
      for (std::int32_t lx = 0; lx < snapshot.patch.cells.x; ++lx) {
        const double ux = u.unchecked({lx, ly, lz}, 0U);
        if (!std::isfinite(ux)) return false;
        const std::size_t gx =
            static_cast<std::size_t>(snapshot.patch.begin.x + lx);
        const std::size_t base = gx * 3U;
        accumulator.centerline[base] += weight;
        accumulator.centerline[base + 1U] += weight * ux;
        accumulator.centerline[base + 2U] += weight * ux * ux;
      }
    }
  }
  ++accumulator.sample_steps;
  return true;
}

bool collect_probes(MPI_Comm communicator, const RuntimeGeometry& runtime,
                    const CommittedOutputSnapshot& snapshot,
                    std::vector<double>& out) {
  const SnapshotFieldView* velocity = find_field(snapshot, "U", 3U);
  if (!all_true(communicator, velocity != nullptr)) return false;
  const ConstFieldView u = velocity->values;
  std::vector<double> sums;
  if (!local_stage(communicator, [&] {
        sums.assign(runtime.station_brackets.size() * 4U, 0.0);
        out.resize(runtime.station_brackets.size() * 3U);
        return true;
      })) return false;
  const Bracket y_selected = runtime.centerline_bracket;
  const std::array<std::int32_t, 2U> y_planes{{y_selected.lower,
                                                y_selected.upper}};
  const std::array<double, 2U> y_weights{{1.0 - y_selected.upper_weight,
                                          y_selected.upper_weight}};
  const std::size_t y_count =
      y_selected.lower == y_selected.upper ? 1U : 2U;
  bool local_valid = true;
  for (std::size_t station = 0U; station < runtime.station_brackets.size();
       ++station) {
    const Bracket x_selected = runtime.station_brackets[station];
    const std::array<std::int32_t, 2U> x_planes{{x_selected.lower,
                                                  x_selected.upper}};
    const std::array<double, 2U> x_weights{{1.0 - x_selected.upper_weight,
                                            x_selected.upper_weight}};
    const std::size_t x_count =
        x_selected.lower == x_selected.upper ? 1U : 2U;
    for (std::size_t xs = 0U; xs < x_count; ++xs) {
      if (!owns(x_planes[xs], snapshot.patch.begin.x,
                snapshot.patch.cells.x))
        continue;
      const std::int32_t lx = x_planes[xs] - snapshot.patch.begin.x;
      for (std::size_t ys = 0U; ys < y_count; ++ys) {
        if (!owns(y_planes[ys], snapshot.patch.begin.y,
                  snapshot.patch.cells.y))
          continue;
        const std::int32_t ly = y_planes[ys] - snapshot.patch.begin.y;
        const double weight = x_weights[xs] * y_weights[ys];
        if (weight == 0.0) continue;
        for (std::int32_t lz = 0; lz < snapshot.patch.cells.z; ++lz) {
          const Int3 cell{lx, ly, lz};
          const double ux = u.unchecked(cell, 0U);
          const double uy = u.unchecked(cell, 1U);
          const double uz = u.unchecked(cell, 2U);
          if (!std::isfinite(ux) || !std::isfinite(uy) ||
              !std::isfinite(uz)) {
            local_valid = false;
            continue;
          }
          const std::size_t base = station * 4U;
          sums[base] += weight;
          sums[base + 1U] += weight * ux;
          sums[base + 2U] += weight * uy;
          sums[base + 3U] += weight * uz;
        }
      }
    }
  }
  if (!all_true(communicator, local_valid)) return false;
  if (sums.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()) ||
      MPI_Allreduce(MPI_IN_PLACE, sums.data(), static_cast<int>(sums.size()),
                    MPI_DOUBLE, MPI_SUM, communicator) != MPI_SUCCESS)
    return false;
  for (std::size_t station = 0U; station < runtime.station_brackets.size();
       ++station) {
    const std::size_t source = station * 4U;
    const std::size_t target = station * 3U;
    if (!std::isfinite(sums[source]) || sums[source] <= 0.0) return false;
    for (std::size_t component = 0U; component < 3U; ++component) {
      const double value = sums[source + component + 1U] / sums[source];
      if (!std::isfinite(value)) return false;
      out[target + component] = value;
    }
  }
  return true;
}

bool reduce_vector(MPI_Comm communicator, int rank,
                   const std::vector<double>& local,
                   std::vector<double>& global) {
  if (!local_stage(communicator, [&] {
        if (local.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
          return false;
        if (rank == 0) global.resize(local.size());
        return true;
      })) return false;
  const bool reduced = MPI_Reduce(local.data(), rank == 0 ? global.data() : nullptr,
                    static_cast<int>(local.size()), MPI_DOUBLE, MPI_SUM, 0,
                       communicator) == MPI_SUCCESS;
  return all_true(communicator, reduced);
}

std::string encode_accumulator(std::uint64_t fingerprint,
                               PlanFingerprint plan,
                               PlanFingerprint schema,
                               std::uint64_t step, double time,
                               const Accumulator& accumulator) {
  std::ostringstream text;
  text.exceptions(std::ios::badbit | std::ios::failbit);
  text.imbue(std::locale::classic());
  text << std::setprecision(17) << kAccumulatorMagic << '\n'
       << "spec_fingerprint " << fingerprint << '\n'
       << "plan " << plan << '\n'
       << "schema " << schema << '\n'
       << "step " << step << '\n'
       << "time " << time << '\n'
       << "sample_steps " << accumulator.sample_steps << '\n'
       << "epoch_start_step " << accumulator.epoch.start_step << '\n'
       << "epoch_development_steps " << accumulator.epoch.development_steps << '\n'
       << "epoch_sampling_start_step " << accumulator.epoch.sampling_start_step << '\n'
       << "epoch_discarded_samples " << accumulator.epoch.discarded_samples << '\n'
       << "epoch_reset_reason " << reset_reason_name(accumulator.epoch.reason) << '\n'
       << "epoch_source_manifest "
       << (detail::valid_runtime_sha256(accumulator.epoch.source_manifest)
               ? accumulator.epoch.source_manifest.data() : "none") << '\n'
       << "profile_size " << accumulator.profile.size() << '\n'
       << "centerline_size " << accumulator.centerline.size() << '\n';
  for (std::size_t index = 0U; index < accumulator.profile.size(); ++index)
    text << "p " << index << ' ' << accumulator.profile[index] << '\n';
  for (std::size_t index = 0U; index < accumulator.centerline.size(); ++index)
    text << "c " << index << ' ' << accumulator.centerline[index] << '\n';
  text << "end\n";
  return text.str();
}

bool decode_accumulator(const fs::path& path, std::uint64_t fingerprint,
                        PlanFingerprint plan, PlanFingerprint schema,
                        std::uint64_t step, double time,
                        Accumulator& accumulator) {
  std::ifstream input(path);
  std::string line;
  if (!input || !std::getline(input, line) ||
      (line != kAccumulatorMagic && line != kStepAccumulatorMagic &&
       line != kLegacyAccumulatorMagic))
    return false;
  const bool legacy_weights = line != kAccumulatorMagic;
  const bool has_epoch = line != kLegacyAccumulatorMagic;
  unsigned epoch_fields = 0U;
  if (!has_epoch) accumulator.epoch.reason = StatisticsResetReason::legacy_statistics;
  bool have_spec = false;
  bool have_plan = false;
  bool have_schema = false;
  bool have_step = false;
  bool have_time = false;
  bool have_samples = false;
  bool have_profile_size = false;
  bool have_centerline_size = false;
  bool ended = false;
  std::vector<bool> profile_seen(accumulator.profile.size(), false);
  std::vector<bool> centerline_seen(accumulator.centerline.size(), false);
  while (std::getline(input, line)) {
    if (line.empty()) continue;
    std::istringstream row(line);
    row.imbue(std::locale::classic());
    std::string key;
    if (!(row >> key) || ended) return false;
    if (key == "end") {
      std::string extra;
      if (row >> extra) return false;
      ended = true;
      continue;
    }
    if (key == "p" || key == "c") {
      std::size_t index = 0U;
      double value = 0.0;
      std::string extra;
      if (!(row >> index >> value) || row >> extra || !std::isfinite(value))
        return false;
      std::vector<double>& target =
          key == "p" ? accumulator.profile : accumulator.centerline;
      std::vector<bool>& seen = key == "p" ? profile_seen : centerline_seen;
      if (index >= target.size() || seen[index]) return false;
      target[index] = value;
      seen[index] = true;
      continue;
    }
    std::string value;
    std::string extra;
    if (!(row >> value) || row >> extra) return false;
    std::uint64_t number = 0U;
    if (key == "spec_fingerprint" && !have_spec) {
      have_spec = parse_u64(value, number) && number == fingerprint;
      if (!have_spec) return false;
    } else if (key == "plan" && !have_plan) {
      have_plan = parse_u64(value, number) && number == plan;
      if (!have_plan) return false;
    } else if (key == "schema" && !have_schema) {
      have_schema = parse_u64(value, number) && number == schema;
      if (!have_schema) return false;
    } else if (key == "step" && !have_step) {
      have_step = parse_u64(value, number) && number == step;
      if (!have_step) return false;
    } else if (key == "time" && !have_time) {
      double parsed = 0.0;
      have_time = parse_real(value, parsed) && parsed == time;
      if (!have_time) return false;
    } else if (key == "sample_steps" && !have_samples) {
      have_samples = parse_u64(value, accumulator.sample_steps);
      if (!have_samples) return false;
    } else if (key == "profile_size" && !have_profile_size) {
      have_profile_size = parse_u64(value, number) &&
                          number == accumulator.profile.size();
      if (!have_profile_size) return false;
    } else if (key == "centerline_size" && !have_centerline_size) {
      have_centerline_size = parse_u64(value, number) &&
                             number == accumulator.centerline.size();
      if (!have_centerline_size) return false;
    } else if (has_epoch && key == "epoch_start_step" && !(epoch_fields & 1U)) {
      if (!parse_u64(value, accumulator.epoch.start_step)) return false;
      epoch_fields |= 1U;
    } else if (has_epoch && key == "epoch_development_steps" && !(epoch_fields & 2U)) {
      if (!parse_u64(value, accumulator.epoch.development_steps)) return false;
      epoch_fields |= 2U;
    } else if (has_epoch && key == "epoch_sampling_start_step" && !(epoch_fields & 4U)) {
      if (!parse_u64(value, accumulator.epoch.sampling_start_step)) return false;
      epoch_fields |= 4U;
    } else if (has_epoch && key == "epoch_discarded_samples" && !(epoch_fields & 8U)) {
      if (!parse_u64(value, accumulator.epoch.discarded_samples)) return false;
      epoch_fields |= 8U;
    } else if (has_epoch && key == "epoch_reset_reason" && !(epoch_fields & 16U)) {
      bool found = false;
      for (auto reason : {StatisticsResetReason::fresh, StatisticsResetReason::method_recovery,
                          StatisticsResetReason::missing_history, StatisticsResetReason::legacy_statistics})
        if (value == reset_reason_name(reason)) { accumulator.epoch.reason = reason; found = true; }
      if (!found) return false;
      epoch_fields |= 16U;
    } else if (has_epoch && key == "epoch_source_manifest" && !(epoch_fields & 32U)) {
      accumulator.epoch.source_manifest = {};
      if (value != "none") {
        if (value.size() != kRuntimeSha256HexCharacters) return false;
        std::copy(value.begin(), value.end(), accumulator.epoch.source_manifest.begin());
        if (!detail::valid_runtime_sha256(accumulator.epoch.source_manifest)) return false;
      }
      epoch_fields |= 32U;
    } else {
      return false;
    }
  }
  const auto& epoch = accumulator.epoch;
  const auto development = std::max(epoch.development_steps, UINT64_C(1));
  const bool reset = epoch.reason == StatisticsResetReason::method_recovery ||
                     epoch.reason == StatisticsResetReason::missing_history ||
                     epoch.reason == StatisticsResetReason::legacy_statistics;
  const bool source_valid = detail::valid_runtime_sha256(epoch.source_manifest) &&
      std::any_of(epoch.source_manifest.begin(), epoch.source_manifest.end() - 1,
                  [](char c) { return c != '0'; });
  const auto possible_samples = step >= epoch.sampling_start_step
      ? step - epoch.sampling_start_step + 1U : 0U;
  const bool valid = (!has_epoch || (epoch_fields == 63U && epoch.start_step <= step &&
             development < UINT64_MAX - epoch.start_step &&
             epoch.sampling_start_step == epoch.start_step + development + 1U &&
             accumulator.sample_steps <= possible_samples &&
             (reset ? (source_valid && epoch.start_step > 0U)
                    : (epoch.start_step == 0U && epoch.discarded_samples == 0U &&
                       epoch.source_manifest[0] == '\0')))) &&
         ended && have_spec && have_plan && have_schema && have_step &&
         have_time && have_samples && have_profile_size &&
         have_centerline_size &&
         std::all_of(profile_seen.begin(), profile_seen.end(),
                     [](bool value) { return value; }) &&
         std::all_of(centerline_seen.begin(), centerline_seen.end(),
                     [](bool value) { return value; });
  if (valid && legacy_weights)
    accumulator.epoch.reason = StatisticsResetReason::legacy_statistics;
  return valid;
}

std::string encode_statistics(const StatisticsSpec& spec,
                              std::uint64_t fingerprint,
                              const RuntimeGeometry& runtime,
                              const CommittedOutputSnapshot& snapshot,
                              const Accumulator& accumulator) {
  std::ostringstream text;
  text.exceptions(std::ios::badbit | std::ios::failbit);
  text.imbue(std::locale::classic());
  text << std::setprecision(17)
       << "{\"schema\":\"" << kStatisticsMagic << "\""
       << ",\"spec_fingerprint\":" << fingerprint
       << ",\"plan\":" << snapshot.plan
       << ",\"field_schema\":" << snapshot.schema
       << ",\"snapshot_step\":" << snapshot.step
       << ",\"snapshot_time\":" << snapshot.time
       << ",\"sample_steps\":" << accumulator.sample_steps
       << ",\"statistics_epoch\":{\"start_step\":" << accumulator.epoch.start_step
       << ",\"development_steps\":" << accumulator.epoch.development_steps
       << ",\"sampling_start_step\":" << accumulator.epoch.sampling_start_step
       << ",\"reset_reason\":\"" << reset_reason_name(accumulator.epoch.reason) << "\"}"
       << ",\"profiles\":[";
  const Span<const double> xs = snapshot.geometry->x().centres();
  const Span<const double> ys = snapshot.geometry->y().centres();
  bool first = true;
  for (std::size_t station = 0U; station < runtime.station_brackets.size();
       ++station) {
    const Bracket selected = runtime.station_brackets[station];
    const double target = spec.cylinder_center_x +
                          spec.station_x_over_d[station] * spec.diameter;
    for (std::size_t y = 0U; y < ys.size; ++y) {
      const std::size_t base = (station * ys.size + y) * 6U;
      if (!first) text << ',';
      first = false;
      text << "{\"station\":" << station
           << ",\"x_over_d\":" << spec.station_x_over_d[station]
           << ",\"target_x\":" << target
           << ",\"lower_x\":" << xs.data[selected.lower]
           << ",\"upper_x\":" << xs.data[selected.upper]
           << ",\"upper_weight\":" << selected.upper_weight
           << ",\"y\":" << ys.data[y]
           << ",\"y_over_d\":" << ys.data[y] / spec.diameter
           << ",\"sum_weight\":" << accumulator.profile[base]
           << ",\"sum_u\":" << accumulator.profile[base + 1U]
           << ",\"sum_v\":" << accumulator.profile[base + 2U]
           << ",\"sum_uu\":" << accumulator.profile[base + 3U]
           << ",\"sum_vv\":" << accumulator.profile[base + 4U]
           << ",\"sum_uv\":" << accumulator.profile[base + 5U]
           << '}';
    }
  }
  const Bracket center = runtime.centerline_bracket;
  text << "],\"centerline_bracket\":{\"lower_y\":"
       << ys.data[center.lower] << ",\"upper_y\":"
       << ys.data[center.upper] << ",\"upper_weight\":"
       << center.upper_weight << "},\"centerline\":[";
  for (std::size_t x = 0U; x < xs.size; ++x) {
    const std::size_t base = x * 3U;
    if (x != 0U) text << ',';
    text << "{\"x\":" << xs.data[x] << ",\"x_over_d\":"
         << (xs.data[x] - spec.cylinder_center_x) / spec.diameter
         << ",\"sum_weight\":" << accumulator.centerline[base]
         << ",\"sum_u\":" << accumulator.centerline[base + 1U]
         << ",\"sum_uu\":" << accumulator.centerline[base + 2U]
         << '}';
  }
  text << "]}\n";
  return text.str();
}

bool read_current_generation(const fs::path& restart_root,
                             std::string& generation) {
  std::ifstream input(restart_root / "current");
  return static_cast<bool>(std::getline(input, generation)) &&
         !generation.empty() && generation.find('/') == std::string::npos &&
         generation.find("..") == std::string::npos;
}

bool read_restart_binding(const fs::path& restart_root,
                          const RestartImage& image,
                          std::uint64_t fingerprint,
                          RestartBinding& out) {
  std::string generation;
  if (!read_current_generation(restart_root, generation)) return false;
  const fs::path run_root = restart_root.parent_path();
  const fs::path marker =
      run_root / checkpoint_name(image.step, ".complete");
  std::ifstream input(marker);
  std::string line;
  if (!input || !std::getline(input, line) || line != kCheckpointMagic)
    return false;
  bool have_spec = false;
  bool have_step = false;
  bool have_time = false;
  bool have_plan = false;
  bool have_schema = false;
  bool have_generation = false;
  bool have_statistics = false;
  bool have_accumulator = false;
  bool ended = false;
  fs::path statistics;
  fs::path accumulator;
  while (std::getline(input, line)) {
    if (line.empty()) continue;
    std::istringstream row(line);
    std::string key;
    std::string value;
    std::string extra;
    if (!(row >> key) || ended) return false;
    if (key == "end") {
      if (row >> extra) return false;
      ended = true;
      continue;
    }
    if (!(row >> value) || row >> extra) return false;
    std::uint64_t number = 0U;
    if (key == "spec_fingerprint" && !have_spec) {
      have_spec = parse_u64(value, number) && number == fingerprint;
      if (!have_spec) return false;
    } else if (key == "step" && !have_step) {
      have_step = parse_u64(value, number) && number == image.step;
      if (!have_step) return false;
    } else if (key == "time" && !have_time) {
      double parsed = 0.0;
      have_time = parse_real(value, parsed) && parsed == image.time;
      if (!have_time) return false;
    } else if (key == "plan" && !have_plan) {
      have_plan = parse_u64(value, number) && number == image.plan;
      if (!have_plan) return false;
    } else if (key == "schema" && !have_schema) {
      have_schema = parse_u64(value, number) && number == image.schema;
      if (!have_schema) return false;
    } else if (key == "restart_generation" && !have_generation) {
      have_generation = value == generation;
      if (!have_generation) return false;
    } else if (key == "statistics" && !have_statistics) {
      statistics = run_root / value;
      have_statistics = statistics.filename() == value &&
                        fs::is_regular_file(statistics);
      if (!have_statistics) return false;
    } else if (key == "accumulator" && !have_accumulator) {
      accumulator = run_root / value;
      have_accumulator = accumulator.filename() == value &&
                         fs::is_regular_file(accumulator);
      if (!have_accumulator) return false;
    } else {
      return false;
    }
  }
  if (!ended || !have_spec || !have_step || !have_time || !have_plan ||
      !have_schema || !have_generation || !have_statistics ||
      !have_accumulator)
    return false;
  out = {statistics, accumulator, generation};
  return true;
}

bool write_checkpoint_observables(
    MPI_Comm communicator, int rank, const fs::path& run_root,
    const StatisticsSpec& spec, std::uint64_t fingerprint,
    const RuntimeGeometry& runtime,
    const CommittedOutputSnapshot& snapshot,
    const Accumulator& local_accumulator) {
  Accumulator global;
  global.sample_steps = local_accumulator.sample_steps;
  global.epoch = local_accumulator.epoch;
  bool okay = reduce_vector(communicator, rank, local_accumulator.profile,
                            global.profile) &&
              reduce_vector(communicator, rank, local_accumulator.centerline,
                            global.centerline);
  if (!all_true(communicator, okay)) return false;
  return local_stage(communicator, [&] {
    if (rank != 0) return true;
    const fs::path statistics =
        run_root / checkpoint_name(snapshot.step, ".statistics.json");
    const fs::path accumulator =
        run_root / checkpoint_name(snapshot.step, ".accumulator");
    return write_exclusive(
                statistics,
                encode_statistics(spec, fingerprint, runtime, snapshot,
                                  global)) &&
            write_exclusive(accumulator,
                            encode_accumulator(fingerprint, snapshot.plan,
                                               snapshot.schema, snapshot.step,
                                               snapshot.time, global));
  });
}

bool checkpoint(MPI_Comm communicator, int rank, ProductDriver& driver,
                const IoServicePlan& services,
                const fs::path& run_root, const StatisticsSpec& spec,
                std::uint64_t fingerprint, const RuntimeGeometry& runtime,
                const CommittedOutputSnapshot& snapshot,
                const Accumulator& accumulator) {
  if (!write_checkpoint_observables(communicator, rank, run_root, spec,
                                    fingerprint, runtime, snapshot,
                                    accumulator))
    return false;
  RestartSnapshot restart;
  fs::path restart_root;
  if (!local_stage(communicator, [&] {
        restart_root = run_root / "Restart";
        return static_cast<bool>(driver.committed_restart_snapshot(restart));
      })) return false;
  RestartWriteReport publication;
  const Status status = RestartWriter::write(communicator, restart_root, restart,
      {2U, &publication, detail::output_service(services, RuntimeServiceKind::restart)
                            ->maximum_staging_bytes_per_rank});
  if (rank == 0 && (!status || !publication.cleanup_status)) {
    const auto& error = status ? publication.cleanup_failure : publication.failure;
    std::fprintf(stderr,
        "CHECKPOINT_IO status=%u/%u publication=%u cleanup=%u/%u rank=%d errno=%d path=%s\n",
        static_cast<unsigned>(status.code), status.detail,
        static_cast<unsigned>(publication.publication),
        static_cast<unsigned>(publication.cleanup_status.code), publication.cleanup_status.detail,
        error.rank, error.system_error, error.path.data());
  }
  if (!status) return false;
  return local_stage(communicator, [&] {
    if (rank != 0) return true;
    std::string generation;
    bool okay = read_current_generation(restart_root, generation);
    if (okay) {
      std::ostringstream marker;
      marker.exceptions(std::ios::badbit | std::ios::failbit);
      marker.imbue(std::locale::classic());
      marker << std::setprecision(17) << kCheckpointMagic << '\n'
             << "spec_fingerprint " << fingerprint << '\n'
             << "step " << snapshot.step << '\n'
             << "time " << snapshot.time << '\n'
             << "plan " << snapshot.plan << '\n'
             << "schema " << snapshot.schema << '\n'
             << "restart_generation " << generation << '\n'
             << "statistics "
             << checkpoint_name(snapshot.step, ".statistics.json") << '\n'
             << "accumulator "
             << checkpoint_name(snapshot.step, ".accumulator") << '\n'
             << "end\n";
      okay = write_exclusive(
                 run_root / checkpoint_name(snapshot.step, ".complete"),
                 marker.str()) &&
             sync_directory(run_root);
    }
    return okay;
  });
}

DriverInitialState initial_state(const ValidatedModel& model,
                                 std::vector<double>& scalars) {
  scalars = initial_scalar_values(model);
  DriverInitialState initial;
  initial.transported_scalars = {scalars.data(), scalars.size()};
  for (const BoundaryFaceSpec& boundary : model.boundaries) {
    if (std::isfinite(boundary.temperature) && boundary.temperature > 0.0)
      initial.temperature = boundary.temperature;
    if (model.pressure_reference == PressureReferenceKind::boundary_absolute &&
        boundary.flow_kind == BoundaryKind::pressure_outlet &&
        std::isfinite(boundary.pressure) && boundary.pressure > 0.0)
      initial.pressure_reference = boundary.pressure;
    if (boundary.flow_kind == BoundaryKind::velocity_inlet ||
        boundary.flow_kind == BoundaryKind::static_state_inlet ||
        boundary.flow_kind == BoundaryKind::total_state_inlet)
      initial.velocity = boundary.velocity;
  }
  return initial;
}

bool create_run_root(MPI_Comm communicator, int rank, const fs::path& root) {
  return local_stage(communicator, [&] {
    if (rank != 0) return true;
    std::error_code error;
    return !fs::exists(root, error) && !error &&
            fs::create_directories(root, error) && !error &&
            sync_directory(root.parent_path());
  });
}

bool finite_force(const SurfaceForce& force) {
  const std::array<double, 12U> values{{
      force.pressure.x, force.pressure.y, force.pressure.z,
      force.viscous.x,  force.viscous.y,  force.viscous.z,
      force.total.x,    force.total.y,    force.total.z,
      force.moment.x,   force.moment.y,   force.moment.z}};
  return std::all_of(values.begin(), values.end(),
                     [](double value) { return std::isfinite(value); });
}

bool collect_thermo_extrema(MPI_Comm communicator,
                            const ValidatedModel& model,
                            const ThermodynamicsPlan& thermodynamics,
                            double pressure_reference,
                            const CommittedOutputSnapshot& snapshot,
                            ThermoExtrema& out) {
  const SnapshotFieldView* velocity = find_field(snapshot, "U", 3U);
  const SnapshotFieldView* pressure = find_field(snapshot, "pi", 1U);
  const SnapshotFieldView* enthalpy = find_field(snapshot, "h", 1U);
  bool local_valid =
      velocity != nullptr && pressure != nullptr && enthalpy != nullptr;
  std::vector<const SnapshotFieldView*> independent;
  for (const TransportedScalarSpec& scalar : model.transported_scalars) {
    if (scalar.role == TransportedScalarRole::species) {
      const SnapshotFieldView* field =
          find_field(snapshot, scalar.stable_name, 1U);
      if (field == nullptr) local_valid = false;
      independent.push_back(field);
    }
  }
  local_valid = local_valid &&
                independent.size() ==
                    thermodynamics.independent_species_count();
  if (!all_true(communicator, local_valid)) return false;
  const ConstFieldView u = velocity->values;
  const ConstFieldView pi = pressure->values;
  const ConstFieldView h = enthalpy->values;
  local_valid = u.interior.x == snapshot.patch.cells.x &&
                u.interior.y == snapshot.patch.cells.y &&
                u.interior.z == snapshot.patch.cells.z &&
                pi.interior.x == u.interior.x &&
                pi.interior.y == u.interior.y &&
                pi.interior.z == u.interior.z &&
                h.interior.x == u.interior.x &&
                h.interior.y == u.interior.y &&
                h.interior.z == u.interior.z;
  if (!all_true(communicator, local_valid)) return false;
  std::array<double, 3U> minimum{{
      std::numeric_limits<double>::infinity(),
      std::numeric_limits<double>::infinity(),
      std::numeric_limits<double>::infinity()}};
  std::array<double, 3U> maximum{{
      -std::numeric_limits<double>::infinity(),
      -std::numeric_limits<double>::infinity(),
      -std::numeric_limits<double>::infinity()}};
  const std::size_t owned = static_cast<std::size_t>(u.interior.x) *
                            u.interior.y * u.interior.z;
  const auto activity = snapshot.cell_activity;
  local_valid = activity.size == 0U ||
                (activity.data != nullptr && activity.size == owned);
  if (!all_true(communicator, local_valid)) return false;
  ThermoExtrema regions;
  regions.regional.fill(std::numeric_limits<double>::infinity());
  regions.region_cell.fill(UINT64_MAX);
  const Int3 global = snapshot.geometry->global_cells();
  std::vector<double> fractions(independent.size(), 0.0);
  for (std::int32_t z = 0; z < u.interior.z; ++z) {
    for (std::int32_t y = 0; y < u.interior.y; ++y) {
      for (std::int32_t x = 0; x < u.interior.x; ++x) {
        const Int3 cell{x, y, z};
        for (std::size_t scalar = 0U; scalar < independent.size(); ++scalar)
          fractions[scalar] = independent[scalar]->values.unchecked(cell, 0U);
        const double perturbation = pi.unchecked(cell, 0U);
        const double absolute = pressure_reference + perturbation;
        const double enthalpy_value = h.unchecked(cell, 0U);
        const Real3 velocity_value{u.unchecked(cell, 0U),
                                   u.unchecked(cell, 1U),
                                   u.unchecked(cell, 2U)};
        ThermoState state;
        const Status status = thermodynamics.evaluate_from_reference_pressure(
            pressure_reference, perturbation, enthalpy_value,
            {fractions.data(), fractions.size()}, velocity_value, state);
        if (!status || !std::isfinite(absolute) || absolute <= 0.0 ||
            !std::isfinite(state.temperature) || state.temperature <= 0.0 ||
            !std::isfinite(state.rho) || state.rho <= 0.0) {
          local_valid = false;
          continue;
        }
        minimum[0U] = std::min(minimum[0U], absolute);
        minimum[1U] = std::min(minimum[1U], state.temperature);
        minimum[2U] = std::min(minimum[2U], state.rho);
        maximum[0U] = std::max(maximum[0U], absolute);
        maximum[1U] = std::max(maximum[1U], state.temperature);
        maximum[2U] = std::max(maximum[2U], state.rho);
        const std::size_t flat = static_cast<std::size_t>(x) +
            static_cast<std::size_t>(u.interior.x) *
                (static_cast<std::size_t>(y) +
                 static_cast<std::size_t>(u.interior.y) * z);
        const std::uint8_t active = activity.size == 0U ? 1U : activity.data[flat];
        if (active > 1U) { local_valid = false; continue; }
        const std::size_t region = active == 1U ? 0U : 1U;
        ++regions.region_count[region];
        const std::uint64_t global_cell = snapshot.patch.begin.x + x +
            static_cast<std::uint64_t>(global.x) *
                (snapshot.patch.begin.y + y +
                 static_cast<std::uint64_t>(global.y) * (snapshot.patch.begin.z + z));
        const double values[]{absolute, -absolute, state.temperature,
                              -state.temperature, state.rho, -state.rho};
        for (std::size_t k = 0U; k < 6U; ++k) {
          const std::size_t slot = region * 6U + k;
          if (values[k] < regions.regional[slot] ||
              (values[k] == regions.regional[slot] &&
               global_cell < regions.region_cell[slot])) {
            regions.regional[slot] = values[k];
            regions.region_cell[slot] = global_cell;
          }
        }
      }
    }
  }
  if (!all_true(communicator, local_valid)) return false;
  if (MPI_Allreduce(MPI_IN_PLACE, minimum.data(), 3, MPI_DOUBLE, MPI_MIN,
                    communicator) != MPI_SUCCESS ||
      MPI_Allreduce(MPI_IN_PLACE, maximum.data(), 3, MPI_DOUBLE, MPI_MAX,
                    communicator) != MPI_SUCCESS)
    return false;
  const bool valid =
      std::all_of(minimum.begin(), minimum.end(), [](double value) {
        return std::isfinite(value) && value > 0.0;
      }) &&
      std::all_of(maximum.begin(), maximum.end(), [](double value) {
        return std::isfinite(value) && value > 0.0;
      });
  if (!valid) return false;
  const auto local_extrema = regions.regional;
  if (MPI_Allreduce(MPI_IN_PLACE, regions.region_count.data(), 2,
                    MPI_UINT64_T, MPI_SUM, communicator) != MPI_SUCCESS ||
      MPI_Allreduce(MPI_IN_PLACE, regions.regional.data(), 12,
                    MPI_DOUBLE, MPI_MIN, communicator) != MPI_SUCCESS) return false;
  for (std::size_t k = 0U; k < 12U; ++k)
    if (local_extrema[k] != regions.regional[k]) regions.region_cell[k] = UINT64_MAX;
  if (MPI_Allreduce(MPI_IN_PLACE, regions.region_cell.data(), 12,
                    MPI_UINT64_T, MPI_MIN, communicator) != MPI_SUCCESS) return false;
  for (std::size_t k = 0U; k < 12U; ++k)
    regions.regional[k] = regions.region_count[k / 6U] == 0U
        ? std::numeric_limits<double>::quiet_NaN()
        : (k % 2U == 0U ? regions.regional[k] : -regions.regional[k]);
  out = {minimum[0U], maximum[0U], minimum[1U], maximum[1U], minimum[2U],
         maximum[2U], regions.region_count, regions.regional, regions.region_cell};
  return true;
}

RuntimePressureEnergyRefinementTermination refinement_termination(
    PressureEnergyRefinementTermination termination) {
  switch (termination) {
    case PressureEnergyRefinementTermination::component_residuals_converged:
      return RuntimePressureEnergyRefinementTermination::
          component_residuals_converged;
    case PressureEnergyRefinementTermination::iteration_capacity_exhausted:
      return RuntimePressureEnergyRefinementTermination::
          iteration_capacity_exhausted;
    case PressureEnergyRefinementTermination::rejected_candidate:
      return RuntimePressureEnergyRefinementTermination::rejected_candidate;
    case PressureEnergyRefinementTermination::none:
      return RuntimePressureEnergyRefinementTermination::none;
  }
  return RuntimePressureEnergyRefinementTermination::none;
}

Status collect_evidence_resources(MPI_Comm communicator,
                                  const DriverResourceReport& local,
                                  DriverResourceReport& global) {
  std::array<std::uint64_t, 18U> maxima{{
      local.structured_messages,
      local.structured_bytes,
      local.ibm_messages,
      local.ibm_bytes,
      local.reduction_collectives,
      local.reduction_nanoseconds,
      local.linear_iterations,
      local.exact_numeric_refills,
      local.hierarchy_rebuilds,
      local.preconditioner_applications,
      local.structured_exchanges,
      local.ibm_exchanges,
      local.reduction_logical_bytes,
      local.mg_blocking_collectives,
      local.mg_collective_logical_bytes,
      local.predictor_blocking_collectives,
      local.structured_control_collectives,
      local.ibm_control_collectives,
  }};
  if (MPI_Allreduce(MPI_IN_PLACE, maxima.data(),
                    static_cast<int>(maxima.size()), MPI_UINT64_T, MPI_MAX,
                    communicator) != MPI_SUCCESS)
    return {StatusCode::mpi_failure, kRunnerInput};
  std::array<std::uint64_t, 4U> sums{{
      local.structured_messages, local.structured_bytes, local.ibm_messages,
      local.ibm_bytes}};
  if (MPI_Allreduce(MPI_IN_PLACE, sums.data(), static_cast<int>(sums.size()),
                    MPI_UINT64_T, MPI_SUM, communicator) != MPI_SUCCESS)
    return {StatusCode::mpi_failure, kRunnerInput};
  global = local;
  global.structured_messages = sums[0U];
  global.structured_bytes = sums[1U];
  global.ibm_messages = sums[2U];
  global.ibm_bytes = sums[3U];
  global.reduction_collectives = maxima[4U];
  global.reduction_nanoseconds = maxima[5U];
  global.linear_iterations = maxima[6U];
  global.exact_numeric_refills = maxima[7U];
  global.hierarchy_rebuilds = maxima[8U];
  global.preconditioner_applications = maxima[9U];
  global.structured_exchanges = maxima[10U];
  global.ibm_exchanges = maxima[11U];
  global.reduction_logical_bytes = maxima[12U];
  global.mg_blocking_collectives = maxima[13U];
  global.mg_collective_logical_bytes = maxima[14U];
  global.predictor_blocking_collectives = maxima[15U];
  global.structured_control_collectives = maxima[16U];
  global.ibm_control_collectives = maxima[17U];
  return {};
}

Status collect_peak_rss(MPI_Comm communicator, MPI_Comm node_communicator,
                        std::uint64_t& maximum_rank,
                        std::uint64_t& maximum_node) {
  if (communicator == MPI_COMM_NULL || node_communicator == MPI_COMM_NULL)
    return {StatusCode::invalid_plan, kRunnerInput};
  rusage usage{};
  if (::getrusage(RUSAGE_SELF, &usage) != 0 || usage.ru_maxrss < 0)
    return {StatusCode::io_failure, kRunnerInput};
  const auto kib = static_cast<std::uint64_t>(usage.ru_maxrss);
  if (kib > UINT64_MAX / 1024U)
    return {StatusCode::invalid_plan, kRunnerInput};
  const std::uint64_t local = kib * 1024U;
  if (MPI_Allreduce(&local, &maximum_rank, 1, MPI_UINT64_T, MPI_MAX,
                    communicator) != MPI_SUCCESS)
    return {StatusCode::mpi_failure, kRunnerInput};
  std::uint64_t node = 0U;
  const int reduce = MPI_Allreduce(&local, &node, 1, MPI_UINT64_T, MPI_SUM,
                                   node_communicator);
  if (reduce != MPI_SUCCESS)
    return {StatusCode::mpi_failure, kRunnerInput};
  if (MPI_Allreduce(&node, &maximum_node, 1, MPI_UINT64_T, MPI_MAX,
                    communicator) != MPI_SUCCESS)
    return {StatusCode::mpi_failure, kRunnerInput};
  return {};
}

Status collect_stage_timings(
    MPI_Comm communicator, const DriverStepReport& step,
    std::array<StageTimingRecord, kDriverTimedStageCapacity>& stages) {
  constexpr std::array<StageId, kDriverTimedStageCapacity> kStages{
      10U, 12U, 15U, 20U, 30U, 40U, 45U, 50U, 60U, 70U};
  std::array<std::uint64_t, kDriverTimedStageCapacity> local{};
  for (std::size_t index = 0U; index < step.stage_timing_count; ++index) {
    const DriverStageTiming timing = step.stage_timings[index];
    const auto found = std::find(kStages.begin(), kStages.end(), timing.stage);
    if (timing.stage == 0U || found == kStages.end())
      return {StatusCode::invalid_plan, kRunnerInput};
    const std::size_t target =
        static_cast<std::size_t>(found - kStages.begin());
    if (local[target] != 0U)
      return {StatusCode::invalid_plan, kRunnerInput};
    local[target] = timing.nanoseconds;
  }
  auto minimum = local;
  auto maximum = local;
  auto sum = local;
  if (MPI_Allreduce(MPI_IN_PLACE, minimum.data(),
                    static_cast<int>(minimum.size()), MPI_UINT64_T, MPI_MIN,
                    communicator) != MPI_SUCCESS ||
      MPI_Allreduce(MPI_IN_PLACE, maximum.data(),
                    static_cast<int>(maximum.size()), MPI_UINT64_T, MPI_MAX,
                    communicator) != MPI_SUCCESS ||
      MPI_Allreduce(MPI_IN_PLACE, sum.data(), static_cast<int>(sum.size()),
                    MPI_UINT64_T, MPI_SUM, communicator) != MPI_SUCCESS)
    return {StatusCode::mpi_failure, kRunnerInput};
  int ranks = 0;
  if (MPI_Comm_size(communicator, &ranks) != MPI_SUCCESS || ranks <= 0)
    return {StatusCode::mpi_failure, kRunnerInput};
  for (std::size_t index = 0U; index < stages.size(); ++index)
    stages[index] = {kStages[index], minimum[index],
                     sum[index] / static_cast<std::uint64_t>(ranks),
                     maximum[index]};
  return {};
}

Status append_evidence(
    MPI_Comm communicator, MPI_Comm node_communicator, int rank,
    EvidenceFile& evidence_file,
    const IoServicePlan& services, const ValidatedModel& model,
    PlanFingerprint product, PlanFingerprint cpu, PlanFingerprint stl,
    const RuntimeCandidateIdentity& candidate_identity,
    PlanFingerprint build_identity, PlanFingerprint binary_identity,
    const RuntimeRunStartAnchor& run_start,
    const DriverStepReport& step, std::uint64_t maximum_step_nanoseconds,
    bool restart_recovery, DriverResourceReport& global_resources) {
  Status status =
      collect_evidence_resources(communicator, step.resources,
                                 global_resources);
  if (!status) return status;
  std::uint64_t maximum_rank_rss = 0U;
  std::uint64_t maximum_node_rss = 0U;
  status = collect_peak_rss(communicator, node_communicator, maximum_rank_rss,
                            maximum_node_rss);
  if (!status) return status;
  std::array<StageTimingRecord, kDriverTimedStageCapacity> stages{};
  status = collect_stage_timings(communicator, step, stages);
  if (!status) return status;

  RuntimeEvidenceRecord evidence;
  evidence.build = build_identity;
  evidence.binary = binary_identity;
  evidence.candidate_identity = candidate_identity;
  evidence.case_model = model.fingerprint;
  evidence.stl = stl;
  evidence.product = product;
  evidence.cpu_plan = cpu;
  evidence.run_start = run_start;
  evidence.step = step.accepted_step;
  evidence.previous_committed_time = step.proposal.time;
  evidence.time = step.accepted_time;
  evidence.requested_bdf_order = step.proposal.bdf.order;
  evidence.bdf_order = step.effective_bdf.order;
  evidence.cold = step.piso.cold;
  evidence.coupling = step.piso.cold.active ? RuntimeCouplingKind::cn_be :
      model.solver.coupling == CouplingKind::simple
          ? RuntimeCouplingKind::simple
          : RuntimeCouplingKind::piso;
  evidence.thermophysical_predictor_calls =
      step.thermophysical_predictor_calls;
  evidence.temporal_method_fallback = step.temporal_method_fallback;
  evidence.maximum_rank_step_nanoseconds = maximum_step_nanoseconds;
  evidence.maximum_rank_rss_bytes = maximum_rank_rss;
  evidence.maximum_node_rss_bytes = maximum_node_rss;
  evidence.structured_messages = global_resources.structured_messages;
  evidence.structured_bytes = global_resources.structured_bytes;
  evidence.ibm_messages = global_resources.ibm_messages;
  evidence.ibm_bytes = global_resources.ibm_bytes;
  if (global_resources.mg_blocking_collectives >
      UINT64_MAX - global_resources.reduction_collectives)
    return {StatusCode::invalid_plan, kRunnerInput};
  evidence.blocking_collectives = global_resources.reduction_collectives +
                                  global_resources.mg_blocking_collectives;
  if (global_resources.predictor_blocking_collectives >
      UINT64_MAX - evidence.blocking_collectives)
    return {StatusCode::invalid_plan, kRunnerInput};
  evidence.blocking_collectives +=
      global_resources.predictor_blocking_collectives;
  // Same tracked subtotal as ApplicationService, not the complete PMPI census.
  for (std::uint64_t calls : {global_resources.structured_control_collectives,
                              global_resources.ibm_control_collectives}) {
    if (calls > UINT64_MAX - evidence.blocking_collectives)
      return {StatusCode::invalid_plan, kRunnerInput};
    evidence.blocking_collectives += calls;
  }
  evidence.reduction_nanoseconds = global_resources.reduction_nanoseconds;
  evidence.linear_iterations = global_resources.linear_iterations;
  evidence.exact_numeric_refills = global_resources.exact_numeric_refills;
  evidence.coarse_numeric_refills = global_resources.exact_numeric_refills;
  evidence.preconditioner_setups = global_resources.hierarchy_rebuilds;
  evidence.preconditioner_reuses =
      global_resources.exact_numeric_refills >=
              global_resources.hierarchy_rebuilds
          ? global_resources.exact_numeric_refills -
                global_resources.hierarchy_rebuilds
          : 0U;
  evidence.pressure = step.piso.pressure;
  evidence.pressure_solve_calls = step.piso.pressure_solve_calls;
  evidence.pressure_solve_contract = step.piso.cold.active
      ? RuntimePressureSolveContract::cn_be
      : RuntimePressureSolveContract::continuity_energy_coupled;
  evidence.pressure_energy_refinement_solve_calls =
      step.piso.pressure_energy_refinement_solve_calls;
  evidence.pressure_energy_refinement_termination =
      refinement_termination(step.piso.pressure_energy_refinement_termination);
  for (std::uint8_t index = 0U;
       index < step.piso.pressure_energy_refinement_solve_calls &&
       index < evidence.pressure_energy_refinement.size();
       ++index) {
    const PisoPressureEnergyRefinementSolveReport& source =
        step.piso.pressure_energy_refinement[index];
    RuntimePressureEnergyRefinementSolve& destination =
        evidence.pressure_energy_refinement[index];
    destination.solve = source.solve;
    destination.target_generation = source.target_generation;
    destination.collective_lineage = source.collective_lineage;
    destination.ordinal = source.ordinal;
  }
  evidence.terminal_physical_audit.present =
      step.piso.final_flux_revision != 0U;
  evidence.terminal_physical_audit.final_flux_revision =
      step.piso.final_flux_revision;
  evidence.terminal_physical_audit.eos_residual = step.piso.eos_residual;
  evidence.terminal_physical_audit.eos_tolerance = model.solver.terminal.eos;
  evidence.terminal_physical_audit.continuity_residual =
      step.piso.continuity_residual;
  evidence.terminal_physical_audit.continuity_tolerance =
      model.solver.terminal.continuity;
  evidence.terminal_physical_audit.energy_residual =
      step.piso.energy_residual;
  evidence.terminal_physical_audit.energy_tolerance =
      model.solver.terminal.continuity;
  if (step.piso.cold.active && step.piso.cold.stopping) {
    evidence.terminal_physical_audit.energy_residual = step.piso.cold.reference_residual[1];
    evidence.terminal_physical_audit.energy_tolerance = step.piso.cold.stopping->enthalpy;
  }
  evidence.momentum_predictor_passes =
      step.momentum_predictor_solve.predictor_passes;
  evidence.terminal_physical_audit.closed_mass_residual =
      step.piso.closed_mass_residual;
  evidence.terminal_physical_audit.closed_mass_tolerance =
      model.solver.terminal.closed_mass;
  evidence.terminal_physical_audit.gauge_residual =
      step.piso.gauge_residual;
  evidence.terminal_physical_audit.gauge_tolerance =
      model.solver.terminal.gauge;
  status = detail::runtime_committed_cfl(
      communicator, step.piso.committed_convective_cfl,
      evidence.committed_convective_cfl);
  if (!status) return status;
  evidence.momentum_predictor = step.momentum_predictor_solve.components;
  evidence.momentum_predictor_solve_calls =
      step.momentum_predictor_solve.solve_calls;
  evidence.predictor_enthalpy_endpoint =
      step.thermophysical_predictor.enthalpy_endpoint;
  evidence.predictor_enthalpy_endpoint_alpha =
      step.thermophysical_predictor.enthalpy_endpoint_alpha;
  evidence.predictor_bdf_endpoint_alpha =
      step.thermophysical_predictor.bdf_endpoint_alpha;
  evidence.predictor_source_endpoint_alpha =
      step.thermophysical_predictor.source_endpoint_alpha;
  evidence.predictor_enthalpy_solve_calls =
      step.thermophysical_predictor.enthalpy_solve_calls;
  evidence.momentum_predictor_theta = step.momentum_predictor_limiter.theta;
  evidence.momentum_predictor_activations =
      step.momentum_predictor_limiter.activations;
  evidence.momentum_correction_metrics_applicable =
      step.momentum_predictor_limiter.correction_metrics_applicable;
  evidence.momentum_minimum_face_alpha =
      step.momentum_predictor_limiter.minimum_face_alpha;
  evidence.momentum_active_correction_faces =
      step.momentum_predictor_limiter.active_correction_faces;
  evidence.momentum_limited_face_fraction =
      step.momentum_predictor_limiter.limited_face_fraction;
  evidence.momentum_predictor_limited =
      step.momentum_predictor_limiter.limited;
  if (!step.piso.cold.active)
    status = detail::runtime_advective_cfl(
        communicator, step.momentum_predictor_limiter.advective_cfl,
        evidence.momentum_advective_cfl);
  if (!status) return status;
  evidence.predictor_theta = step.thermophysical_predictor.theta;
  evidence.predictor_mass_flux_scale =
      step.thermophysical_predictor.mass_flux_scale;
  evidence.predictor_low_margin = step.thermophysical_predictor.low_margin;
  evidence.predictor_high_margin = step.thermophysical_predictor.high_margin;
  evidence.predictor_low_order_transport_passes =
      step.thermophysical_predictor.low_order_transport_passes;
  evidence.predictor_low_order_substeps =
      step.thermophysical_predictor.low_order_substeps;
  evidence.predictor_low_order_halo_exchanges =
      step.thermophysical_predictor.low_order_halo_exchanges;
  evidence.predictor_blocking_collectives =
      step.thermophysical_predictor.blocking_collectives;
  evidence.predictor_limiting_cell_x =
      step.thermophysical_predictor.limiting_cell.x;
  evidence.predictor_limiting_cell_y =
      step.thermophysical_predictor.limiting_cell.y;
  evidence.predictor_limiting_cell_z =
      step.thermophysical_predictor.limiting_cell.z;
  evidence.predictor_limiting_rank =
      step.thermophysical_predictor.limiting_rank;
  evidence.predictor_constraint =
      static_cast<std::uint8_t>(step.thermophysical_predictor.constraint);
  evidence.predictor_low_state =
      static_cast<std::uint8_t>(step.thermophysical_predictor.low_state);
  evidence.predictor_limited = step.thermophysical_predictor.limited;
  evidence.stages = {stages.data(), stages.size()};
  evidence.startup = step.accepted_step == 1U;
  evidence.retry = step.attempts != 1U;
  evidence.restart_recovery = restart_recovery;
  // This quick thin-domain comparison is intentionally not a formal release
  // statistics candidate.  The full V6 numerical evidence is still emitted.
  evidence.statistics_eligible = false;
  std::string line;
  status = detail::runtime_encode_evidence_line(
      communicator, services, evidence, line);
  if (!status) return status;
  const bool written = rank != 0 || evidence_file.append(line);
  return all_true(communicator, written)
             ? Status{}
             : Status{StatusCode::io_failure, kRunnerInput};
}

bool terminal_audit_valid(const ValidatedModel& model,
                          const DriverStepReport& step) {
  const bool reference = step.piso.cold.active && step.piso.cold.stopping.has_value();
  const double energy_tolerance = reference ? step.piso.cold.stopping->enthalpy
                                           : model.solver.terminal.continuity;
  const double energy_residual = reference ? step.piso.cold.reference_residual[1]
                                          : step.piso.energy_residual;
  const std::array<double, 10U> values{{
      step.piso.eos_residual,
      model.solver.terminal.eos,
      step.piso.continuity_residual,
      model.solver.terminal.continuity,
      energy_residual,
      energy_tolerance,
      step.piso.closed_mass_residual,
      model.solver.terminal.closed_mass,
      step.piso.gauge_residual,
      model.solver.terminal.gauge}};
  return step.piso.final_flux_revision != 0U &&
         std::all_of(values.begin(), values.end(), [](double value) {
           return std::isfinite(value) && value >= 0.0;
         }) &&
         step.piso.eos_residual <= model.solver.terminal.eos &&
         step.piso.continuity_residual <=
             model.solver.terminal.continuity &&
         energy_residual <= energy_tolerance &&
         step.piso.closed_mass_residual <=
             model.solver.terminal.closed_mass &&
         step.piso.gauge_residual <= model.solver.terminal.gauge &&
         (step.piso.cold.active || step.momentum_predictor_limiter.advective_cfl.valid()) &&
         step.piso.committed_convective_cfl.valid();
}

int run(MPI_Comm communicator, int rank, const Options& options) {
  int ranks = 0;
  if (MPI_Comm_size(communicator, &ranks) != MPI_SUCCESS || ranks <= 0)
    return 2;
  StatisticsSpec spec;
  std::string parse_error;
  bool okay = local_stage(communicator, [&] { return parse_spec(options.spec, spec, parse_error); });
  if (!okay) {
    if (rank == 0) std::cerr << "spec_error=" << parse_error << '\n';
    return 3;
  }
  const std::uint64_t fingerprint = spec_fingerprint(spec);
  // Observation flags change cold/step communication branches, but are not
  // scientific identity and must not change restart/statistics fingerprints.
  const auto control = mix(mix(mix(fingerprint, options.observe_performance),
                               options.observe_mg_cost),
                           options.observe_fgmres_recovery);
  if (!consensus_u64(communicator, control)) {
    if (rank == 0) std::cerr << "spec_consensus_failure\n";
    return 3;
  }

  ValidatedModel model;
  Status status =
      CaseCompiler::load_and_compile(communicator, options.case_root, model);
  ThermodynamicsPlan thermodynamics;
  if (status)
    status = ThermodynamicsPlan::compile(model.thermophysics,
                                         {model.transported_scalars.data(),
                                          model.transported_scalars.size()},
                                         thermodynamics);
  if (!all_true(communicator, static_cast<bool>(status))) return 4;
  CompiledCasePlan plan;
  if (status)
    status = ProductCompiler::compile(communicator, model, options.case_root,
                                      plan);
  if (!status) {
    if (rank == 0)
      std::cerr << "compile_status=" << static_cast<unsigned>(status.code)
                << '/' << status.detail << '\n';
    return 4;
  }
  const PlanFingerprint product_fingerprint = plan.fingerprint();
  const PlanFingerprint cpu_fingerprint = plan.cpu_plan_fingerprint();
  const PlanFingerprint stl_fingerprint = plan.stl_fingerprint();
  const PlanSummary summary = plan.summary();
  if (rank == 0 && summary.immersed) {
    const IbmReconstructionAudit& boundary =
        summary.ibm_boundary_reconstruction;
    const IbmReconstructionAudit& surface =
        summary.ibm_surface_reconstruction;
    std::cerr << "ibm_reconstruction policy="
              << ibm_reconstruction_policy_name(boundary.policy)
              << " boundary_linear=" << boundary.linear_groups << '/'
              << boundary.group_count
              << " surface_linear=" << surface.linear_groups << '/'
              << surface.group_count
              << " expanded="
              << boundary.expanded_search_groups +
                     surface.expanded_search_groups
              << '\n';
  }
  const IoServicePlan* sealed_services = plan.io_services();
  if (sealed_services == nullptr || sealed_services->fingerprint() == 0U)
    return 4;
  const IoServicePlan services = *sealed_services;
  ProductDriver driver;
  status = ProductDriver::create(communicator, std::move(plan), driver);
  if (!status) return 4;

  std::uint64_t starting_step = 0U;
  bool restarted = false;
  bool restart_requires_recovery = false;
  bool restart_storage_migrated = false;
  PlanFingerprint restart_source_plan{}, restart_source_schema{};
  RuntimeRunStartAnchor run_start;
  RestartBinding restart_binding;
  if (!options.restart_root.empty()) {
    RestartExpected expected;
    status = driver.restart_expected(expected,
        options.restart_storage_compatibility,
        options.restart_method_recovery ? RestartHistoryPolicy::rebuild_method_history
                                        : RestartHistoryPolicy::require_compatible);
    RestartImage image;
    if (status)
      status = RestartReader::load(communicator, options.restart_root,
                                   expected, image);
    if (status) {
      starting_step = image.step;
      run_start.kind = RuntimeRunStartKind::restart;
      run_start.previous_step = image.step;
      run_start.previous_time = image.time;
      run_start.restart_manifest_sha256 = image.source_manifest_sha256;
      run_start.source_format_version = image.source_format_version;
      run_start.source_history_signature = image.method_history_signature;
      run_start.target_history_signature = expected.method_history_signature;
      run_start.history_policy = options.restart_method_recovery
          ? RestartHistoryPolicy::rebuild_method_history
          : RestartHistoryPolicy::require_compatible;
      restart_requires_recovery = image.backward_euler_recovery;
      restart_storage_migrated = image.storage_layout_migrated;
      restart_source_plan = image.plan;
      restart_source_schema = image.schema;
      okay = local_stage(communicator, [&] {
        return rank != 0 || read_restart_binding(options.restart_root, image, fingerprint,
                                                 restart_binding);
      });
      if (okay) {
        // The source image remains an immutable description of the file.
        // Method recovery is a separate consumer policy, not missing history.
        restart_requires_recovery = image.backward_euler_recovery ||
                                    options.restart_method_recovery;
        status = driver.initialize_restart(
            image, options.restart_storage_compatibility,
            options.restart_method_recovery
                ? RestartHistoryPolicy::rebuild_method_history
                : RestartHistoryPolicy::require_compatible);
        restarted = true;
      } else {
        status = {StatusCode::invalid_case, kRunnerInput};
      }
    }
  } else if (status) {
    std::vector<double> scalars;
    DriverInitialState initial;
    if (!local_stage(communicator, [&] { initial = initial_state(model, scalars); return true; })) return 5;
    status = driver.initialize(initial);
  }
  if (!status) {
    if (rank == 0)
      std::cerr << "initialize_status=" << static_cast<unsigned>(status.code)
                << '/' << status.detail << '\n';
    return 5;
  }

  status = driver.set_cell_trace_window(options.trace_window);
  if (!status) return 5;
  if (options.observe_mg_cost && !all_true(communicator,
      static_cast<bool>(driver.set_pressure_mg_profiling(true)))) return 5;
  if (options.observe_fgmres_recovery && !all_true(communicator,
      static_cast<bool>(driver.set_pressure_recovery_observation(true)))) return 5;
  CommittedOutputSnapshot snapshot;
  status = driver.committed_output_snapshot(snapshot);
  RuntimeGeometry runtime;
  okay = local_stage(communicator, [&] {
    return static_cast<bool>(status) && prepare_geometry(spec, snapshot, runtime) &&
         find_field(snapshot, "U", 3U) != nullptr &&
         find_field(snapshot, "pi", 1U) != nullptr &&
         find_field(snapshot, "h", 1U) != nullptr;
  });
  if (!okay) {
    if (rank == 0) std::cerr << "snapshot_geometry_failure\n";
    return 5;
  }

  if (options.dry_plan) {
    const std::array<std::int32_t, 6U> local_patch{{
        snapshot.patch.begin.x, snapshot.patch.begin.y, snapshot.patch.begin.z,
        snapshot.patch.cells.x, snapshot.patch.cells.y,
        snapshot.patch.cells.z}};
    int ranks = 0;
    MPI_Comm_size(communicator, &ranks);
    std::vector<std::int32_t> patches;
    if (!local_stage(communicator, [&] {
          if (rank == 0) patches.resize(static_cast<std::size_t>(ranks) * 6U);
          return true;
        })) return 5;
    okay = MPI_Gather(local_patch.data(), 6, MPI_INT32_T,
                      rank == 0 ? patches.data() : nullptr, 6, MPI_INT32_T, 0,
                      communicator) == MPI_SUCCESS;
    if (!all_true(communicator, okay)) return 5;
    if (rank == 0) {
      std::cout << "schema=HUNDUN_V04_THIN_DOMAIN_DRY_PLAN_V1"
                << " spec=" << fingerprint << " case=" << model.fingerprint
                << " product=" << product_fingerprint
                << " cpu=" << cpu_fingerprint << " stl=" << stl_fingerprint
                << " global=" << snapshot.geometry->global_cells().x << ','
                << snapshot.geometry->global_cells().y << ','
                << snapshot.geometry->global_cells().z
                << " lower=" << std::setprecision(17)
                << snapshot.geometry->lower().x << ','
                << snapshot.geometry->lower().y << ','
                << snapshot.geometry->lower().z
                << " upper=" << snapshot.geometry->upper().x << ','
                << snapshot.geometry->upper().y << ','
                << snapshot.geometry->upper().z
                << " arena_doubles=" << summary.arena_doubles
                << " ranks=" << ranks << " step=" << snapshot.step << '\n';
      for (int source = 0; source < ranks; ++source) {
        const std::size_t base = static_cast<std::size_t>(source) * 6U;
        std::cout << "patch rank=" << source << " begin=" << patches[base]
                  << ',' << patches[base + 1U] << ',' << patches[base + 2U]
                  << " cells=" << patches[base + 3U] << ','
                  << patches[base + 4U] << ',' << patches[base + 5U] << '\n';
      }
    }
    return 0;
  }

  if (starting_step >= spec.collection_end_step ||
      options.steps > spec.collection_end_step - starting_step) {
    if (rank == 0) std::cerr << "requested_steps_outside_window\n";
    return 3;
  }
  RuntimeCandidateIdentity candidate_identity;
  status = detail::runtime_candidate_identity(communicator,
                                              candidate_identity,
                                              HUNDUN_RUNTIME_TARGET_MANIFEST,
                                              model.time.scheme == TimeScheme::cn_be);
  if (!status) {
    if (rank == 0)
      std::cerr << "candidate_identity_status="
                << static_cast<unsigned>(status.code) << '/' << status.detail
                << '\n';
    return 5;
  }
  const PlanFingerprint build_identity =
      detail::runtime_sha256_fingerprint(candidate_identity.build_manifest);
  const PlanFingerprint binary_identity =
      detail::runtime_sha256_fingerprint(candidate_identity.executable);
  if (build_identity == 0U || binary_identity == 0U) return 5;
  const Int3 global_cells = snapshot.geometry->global_cells();
  Accumulator accumulator;
  accumulator.epoch.development_steps = spec.development_steps;
  accumulator.epoch.sampling_start_step = std::max(spec.development_steps, UINT64_C(1)) + 1U;
  if (!local_stage(communicator, [&] {
  accumulator.profile.assign(spec.station_x_over_d.size() *
                                 static_cast<std::size_t>(global_cells.y) * 6U,
                             0.0);
  accumulator.centerline.assign(
      static_cast<std::size_t>(global_cells.x) * 3U, 0.0);
    return true;
  })) return 5;
  if (restarted) {
    okay = local_stage(communicator, [&] {
      return rank != 0 || decode_accumulator(restart_binding.accumulator, fingerprint,
                                restart_source_plan, restart_source_schema,
                                snapshot.step, snapshot.time, accumulator);
    });
    if (!okay) {
      if (rank == 0) std::cerr << "restart_accumulator_failure\n";
      return 5;
    }
    if (MPI_Bcast(&accumulator.sample_steps, 1, MPI_UINT64_T, 0,
                  communicator) != MPI_SUCCESS)
      return 5;
    std::array<std::uint64_t, 5U> epoch{{accumulator.epoch.start_step,
        accumulator.epoch.development_steps, accumulator.epoch.sampling_start_step,
        accumulator.epoch.discarded_samples, static_cast<std::uint64_t>(accumulator.epoch.reason)}};
    if (MPI_Bcast(epoch.data(), static_cast<int>(epoch.size()), MPI_UINT64_T, 0, communicator) != MPI_SUCCESS ||
        MPI_Bcast(accumulator.epoch.source_manifest.data(),
                  static_cast<int>(accumulator.epoch.source_manifest.size()), MPI_CHAR, 0,
                  communicator) != MPI_SUCCESS) return 5;
    accumulator.epoch.start_step = epoch[0];
    accumulator.epoch.development_steps = epoch[1];
    accumulator.epoch.sampling_start_step = epoch[2];
    accumulator.epoch.discarded_samples = epoch[3];
    accumulator.epoch.reason = static_cast<StatisticsResetReason>(epoch[4]);
  }
  if (restarted && (restart_requires_recovery ||
      accumulator.epoch.reason == StatisticsResetReason::legacy_statistics)) {
    const auto development = options.have_restart_development_steps
        ? options.restart_development_steps : spec.development_steps;
    if (!consensus_u64(communicator, development) ||
        std::max(development, UINT64_C(1)) >= UINT64_MAX - starting_step) {
      if (rank == 0) std::cerr << "statistics_redevelopment_window_failure\n";
      return 5;
    }
    // Decode and validate the old attachment above, but never mix its values
    // into a different method's statistics. Retain only source provenance.
    const auto discarded = accumulator.sample_steps;
    std::fill(accumulator.profile.begin(), accumulator.profile.end(), 0.0);
    std::fill(accumulator.centerline.begin(), accumulator.centerline.end(), 0.0);
    accumulator.sample_steps = 0U;
    accumulator.epoch = {starting_step, development,
        starting_step + std::max(development, UINT64_C(1)) + 1U, discarded,
        options.restart_method_recovery ? StatisticsResetReason::method_recovery
          : restart_requires_recovery ? StatisticsResetReason::missing_history
                                      : StatisticsResetReason::legacy_statistics,
        run_start.restart_manifest_sha256};
  }
  if (!consensus_u64(communicator, accumulator.sample_steps)) return 5;

  RuntimeSha256Digest observation_source{};
  if (!create_run_root(communicator, rank, options.run_root)) {
    if (rank == 0) std::cerr << "run_root_not_exclusive\n";
    return 6;
  }
  RuntimeSha256Digest mg_layout_digest{};
  if (options.observe_mg_cost && !write_mg_layout(communicator, rank, ranks,
        driver, options.run_root, mg_layout_digest)) return 6;
  okay = local_stage(communicator, [&] {
    if (rank != 0) return true;
    std::ostringstream metadata;
    metadata.exceptions(std::ios::badbit | std::ios::failbit);
    metadata.imbue(std::locale::classic());
    metadata << std::setprecision(17) << kRunMagic << '\n'
             << "spec_fingerprint " << fingerprint << '\n'
             << "case " << model.fingerprint << '\n'
             << "product " << product_fingerprint << '\n'
             << "cpu " << cpu_fingerprint << '\n'
             << "stl " << stl_fingerprint << '\n'
             << "starting_step " << starting_step << '\n'
             << "starting_time " << snapshot.time << '\n'
             << "statistics_weighting elapsed_time\n"
             << "starting_sample_steps " << accumulator.sample_steps << '\n'
             << "statistics_epoch_start_step " << accumulator.epoch.start_step << '\n'
             << "statistics_development_steps " << accumulator.epoch.development_steps << '\n'
             << "statistics_sampling_start_step " << accumulator.epoch.sampling_start_step << '\n'
             << "statistics_reset_reason " << reset_reason_name(accumulator.epoch.reason) << '\n'
             << "statistics_discarded_samples " << accumulator.epoch.discarded_samples << '\n'
             << "statistics_source_manifest_sha256 "
             << (detail::valid_runtime_sha256(accumulator.epoch.source_manifest)
                    ? accumulator.epoch.source_manifest.data() : "none") << '\n'
             << "requested_steps " << options.steps << '\n'
             << "expected_ranks " << ranks << '\n'
             << "observation_schema "
             << (options.observe_fgmres_recovery ? 6 : options.observe_mg_cost ? 5 : 4) << '\n'
             << "observation_start_ns "
             << std::chrono::duration_cast<std::chrono::nanoseconds>(
                    std::chrono::system_clock::now().time_since_epoch()).count() << '\n'
             << "observation_launcher_pid " << ::getpid() << '\n'
             << "visit_interval " << options.visit_interval << '\n'
             << "observe_performance " << options.observe_performance << '\n'
             << "observe_mg_cost " << options.observe_mg_cost << '\n'
             << "observe_fgmres_recovery " << options.observe_fgmres_recovery << '\n'
             << "pressure_linear_algorithm "
             << (model.solver.pressure.algorithm == LinearAlgorithm::fgmres ? "fgmres" :
                 model.solver.pressure.algorithm == LinearAlgorithm::bicgstab ? "bicgstab" : "pcg") << '\n'
             << "trace_cell_count " << options.trace_window.count << '\n'
             << "trace_first_step " << options.trace_window.first_step << '\n'
             << "trace_last_step " << options.trace_window.last_step << '\n'
             << "trace_cell_0 " << options.trace_window.cells[0].x << ','
             << options.trace_window.cells[0].y << ',' << options.trace_window.cells[0].z << '\n'
             << "trace_cell_1 " << options.trace_window.cells[1].x << ','
             << options.trace_window.cells[1].y << ',' << options.trace_window.cells[1].z << '\n'
             << "restarted " << (restarted ? 1 : 0) << '\n'
             << "restart_storage_migrated "
             << (restart_storage_migrated ? 1 : 0) << '\n'
             << "restart_source_plan " << restart_source_plan << '\n'
             << "restart_source_schema " << restart_source_schema << '\n'
             << "restart_requires_recovery "
             << (restart_requires_recovery ? 1 : 0) << '\n'
             << "restart_method_recovery " << options.restart_method_recovery << '\n'
             << "candidate_head " << candidate_identity.head.data() << '\n'
             << "candidate_tree " << candidate_identity.tree.data() << '\n'
             << "build_manifest_sha256 "
             << candidate_identity.build_manifest.data() << '\n'
             << "executable_sha256 " << candidate_identity.executable.data()
             << '\n'
             << "candidate_identity " << candidate_identity.identity.data()
             << '\n'
             << "ibm_reconstruction_policy "
             << ibm_reconstruction_policy_name(
                    summary.ibm_boundary_reconstruction.policy)
             << '\n'
             << "ibm_boundary_reconstruction_groups "
             << summary.ibm_boundary_reconstruction.group_count << '\n'
             << "ibm_boundary_quadratic_groups "
             << summary.ibm_boundary_reconstruction.quadratic_groups << '\n'
             << "ibm_boundary_linear_groups "
             << summary.ibm_boundary_reconstruction.linear_groups << '\n'
             << "ibm_boundary_expanded_search_groups "
             << summary.ibm_boundary_reconstruction.expanded_search_groups
             << '\n'
             << "ibm_surface_reconstruction_groups "
             << summary.ibm_surface_reconstruction.group_count << '\n'
             << "ibm_surface_quadratic_groups "
             << summary.ibm_surface_reconstruction.quadratic_groups << '\n'
             << "ibm_surface_linear_groups "
             << summary.ibm_surface_reconstruction.linear_groups << '\n'
             << "ibm_surface_expanded_search_groups "
             << summary.ibm_surface_reconstruction.expanded_search_groups
             << '\n'
             << "statistics_eligible 0\n";
    if (options.observe_mg_cost)
      metadata << "mg_layout_sha256 " << mg_layout_digest.data() << '\n';
    metadata << "end\n";
    const std::string encoded = metadata.str();
    if (options.observe_performance && !detail::runtime_sha256_bytes(
          {reinterpret_cast<const std::uint8_t*>(encoded.data()), encoded.size()},
          observation_source)) return false;
    return write_exclusive(options.run_root / "RUN.meta", encoded);
  });
  if (!okay) return 6;

  // The full immutable run metadata binds source identity, rank count and
  // requested range. Allocate/encode on rank 0 in the local stage above;
  // communicate only after every rank has agreed that stage succeeded.
  if (options.observe_performance &&
      MPI_Bcast(observation_source.data(), static_cast<int>(observation_source.size()),
                MPI_CHAR, 0, communicator) != MPI_SUCCESS) return 6;

  std::ofstream force;
  std::ofstream health;
  std::ofstream conservation;
  std::ofstream probe;
  std::ofstream performance;
  std::ofstream loop_performance;
  std::ofstream cell_trace;
  std::ofstream mg_performance;
  struct NodeCommunicator {
    MPI_Comm value{MPI_COMM_NULL};
    ~NodeCommunicator() { if (value != MPI_COMM_NULL) MPI_Comm_free(&value); }
  } node;
  auto& node_communicator = node.value;
  EvidenceFile evidence_file;
  const std::uint64_t target_step = starting_step + options.steps;
  // All returns below first join explicit log completion. An earlier solver or
  // checkpoint failure remains the primary exit status if closing also fails.
  const int run_result = [&]() -> int {
  if (options.trace_window.count != 0U && !local_stage(communicator, [&] {
        cell_trace.open(options.run_root / ("cell-trace-rank-" + std::to_string(rank) + ".csv"));
        cell_trace << "step,rank,attempt,sweep,stage,i,j,k,active,rho,h,T,pi,rate,rho_n,rho_nm1,h_n,h_nm1,dropped\n";
        return static_cast<bool>(cell_trace);
      })) return 6;
  if (options.observe_performance && !local_stage(communicator, [&] {
        loop_performance.open(options.run_root / ("solver-rank-" + std::to_string(rank) + ".csv"));
        loop_performance << "step,rank,attempt,scalar_coupling_sweep,dt,attempt_status,corrector,refinement,kind,invoked,"
            "iterations,A_calls,M_calls,linear_initial,linear_final,linear_criterion_valid,"
            "linear_rhs_norm,linear_atol,linear_rtol,linear_residual_limit,prepare_ns,solve_ns,close_ns,"
            "A_ns,M_ns,dot_ns,reduce_ns,update_ns,mg_refill_ns,mg_copy_ns,structured_wait_ns,"
            "structured_control_ns,globalization_valid,baseline_candidates,extrapolated_candidates,"
            "ladder_candidates,incomplete_candidates,candidate_ns,baseline_continuity,baseline_energy,"
            "selected_continuity,selected_energy,selected_alpha,dropped_loops";
        if (options.observe_mg_cost) {
          loop_performance << ",mg_enabled,mg_complete,mg_attempts,mg_successes,mg_failures,"
              "mg_apply_ns,mg_reduction_ns,mg_halo_wait_ns,mg_halo_control_ns,mg_halo_control_calls,"
              "mg_pre_smooth_calls,mg_pre_smooth_ns,mg_residual_calls,mg_residual_ns,"
              "mg_restriction_calls,mg_restriction_ns,mg_prolongation_calls,mg_prolongation_ns,"
              "mg_post_smooth_calls,mg_post_smooth_ns,mg_terminal_calls,mg_terminal_ns,"
              "mg_direct_mpi_calls,mg_direct_mpi_ns,mg_finest_pre_smooth_ns,mg_finest_post_smooth_ns";
          mg_performance.open(options.run_root / ("mg-rank-" + std::to_string(rank) + ".csv"));
          mg_performance << "step,rank,level,initialized,complete,attempts,successes,failures,"
              "apply_ns,reduction_ns,visits,pre_smooth_calls,pre_smooth_ns,residual_calls,residual_ns,"
              "restriction_calls,restriction_ns,prolongation_calls,prolongation_ns,"
              "post_smooth_calls,post_smooth_ns,terminal_calls,terminal_ns,"
              "direct_mpi_calls,direct_mpi_ns,halo_wait_ns,halo_control_ns,halo_control_calls,"
              "source_meta_sha256\n";
        }
        if (options.observe_fgmres_recovery)
          loop_performance << ",fgmres_available,fgmres_norm_restarts,fgmres_unsafe_norms,"
              "fgmres_discarded_columns,fgmres_explicit_reorthogonalizations,"
              "fgmres_unsafe_restarts,fgmres_happy_restarts,fgmres_length_restarts,"
              "fgmres_initial_residual_applies,fgmres_arnoldi_applies,fgmres_unsafe_residual_applies,"
              "fgmres_interior_residual_applies,fgmres_cycle_residual_applies";
        loop_performance << ",source_meta_sha256\n";
        return static_cast<bool>(loop_performance) &&
            (!options.observe_mg_cost || static_cast<bool>(mg_performance));
      })) return 6;
  okay = local_stage(communicator, [&] {
    if (rank != 0) return true;
    force.open(options.run_root / "force.csv", std::ios::out);
    health.open(options.run_root / "health.csv", std::ios::out);
    conservation.open(options.run_root / "conservation.csv", std::ios::out);
    conservation << "step,time,bdf_order,epoch_start_step,final_flux_revision,"
        "mass_kg,internal_energy_J,kinetic_energy_J,"
        "momentum_x_linf_N,momentum_y_linf_N,momentum_z_linf_N,"
        "momentum_x_l1_N,momentum_y_l1_N,momentum_z_l1_N,"
        "continuity_signed_kg_s,energy_signed_W,energy_l1_W,"
        "total_equation_defect_W,mass_outflow_kg_s,enthalpy_outflow_W,"
        "kinetic_energy_outflow_W,conductive_heat_input_W,species_enthalpy_diffusion_input_W,viscous_work_input_W,"
        "mass_bdf_rate_kg_s,total_energy_bdf_rate_W,mass_balance_defect_kg_s,"
        "total_energy_balance_defect_W,cumulative_mass_defect_kg,"
        "cumulative_energy_defect_J,normalization_valid,U_rms_m_s,"
        "momentum_x_normalized,momentum_y_normalized,momentum_z_normalized,"
        "worst_x_gid,worst_x_rank,worst_y_gid,worst_y_rank,worst_z_gid,worst_z_rank,"
        "ibm_adjacent_cells,interior_cells,ibm_x_linf,ibm_y_linf,ibm_z_linf,"
        "interior_x_linf,interior_y_linf,interior_z_linf,ibm_x_rms,ibm_y_rms,ibm_z_rms,"
        "interior_x_rms,interior_y_rms,interior_z_rms\n";
    probe.open(options.run_root / "probe.csv", std::ios::out);
    if (options.observe_performance) {
      performance.open(options.run_root / "performance.csv", std::ios::out);
      performance
          << "step,rank,full_step_ns,advance_ns,observables_ns,visit_ns,"
             "evidence_resources_ns,csv_ns,checkpoint_ns,"
             "candidate_ns,state_copy_ns,velocity_halo_ns,thermo_ns,"
             "boundary_derived_ns,flux_ns,certificate_ns,residual_ns,"
             "equivalence_hash_ns,schur_prepare_ns,krylov_ns,recovery_ns,"
             "baseline_evaluations,extrapolation_evaluations,ladder_"
             "evaluations,"
             "incomplete_evaluations,rejected_extrapolations,"
             "reported_collective_subtotal,structured_control,ibm_control,"
             "pressure_calls,pressure_prepare_ns,pressure_solve_ns,pressure_close_ns,"
             "diagonal_calls,diagonal_prepare_ns,diagonal_solve_ns,diagonal_close_ns,"
             "spatial_calls,spatial_prepare_ns,spatial_solve_ns,spatial_close_ns,"
             "A_apply_ns,M_apply_ns,arnoldi_dot_ns,arnoldi_reduce_ns,arnoldi_update_ns,"
             "final_momentum_ns,terminal_metrics_ns,boundary_ledger_ns,structured_wait_ns,"
             "structured_control_ns,dropped_loops,scalar_remap_ns,scalar_coupling_sweeps,scalar_remap_iterations,source_meta_sha256\n";
    }
    if (force)
      force << "step,time,requested_bdf_order,bdf_order,attempts,"
               "pressure_fx,pressure_fy,pressure_fz,viscous_fx,viscous_fy,"
               "viscous_fz,total_fx,total_fy,total_fz,moment_x,moment_y,"
               "moment_z,cd,cl,cz,certificate_plan,"
               "certificate_terminal_state,certificate_final_flux,"
               "certificate_force,certificate_state,included,exclusion\n";
    if (health)
      health << "step,time,requested_bdf_order,bdf_order,attempts,retry,"
                "restart_recovery,temporal_fallback,terminal_audit_present,"
                "final_flux_revision,eos,eos_tolerance,continuity,"
                "continuity_tolerance,energy,energy_tolerance,closed_mass,"
                "closed_mass_tolerance,gauge,gauge_tolerance,p_min,p_max,"
                "T_min,T_max,rho_min,rho_max,"
                "provisional_cfl_out,provisional_cfl_abs,provisional_cfl_limit,"
                "committed_cfl_out,committed_cfl_abs,committed_cfl_limit,"
                "afc_metrics_applicable,afc_retained_l1_ratio,"
                "afc_minimum_face_alpha,afc_active_correction_faces,"
                "afc_limited_faces,afc_limited_face_fraction,afc_limited,"
                "thermo_predictor_theta,thermo_predictor_limited,"
                "pressure_solve_calls,refinement_solve_calls,linear_iterations,"
                "max_rank_step_ns,included,exclusion";
    if (health) {
      for (const char* region : {"fluid", "solid_placeholder"}) {
        health << ',' << region << "_count";
        for (const char* value : {"p_min", "p_max", "T_min", "T_max", "rho_min", "rho_max"})
          health << ',' << region << '_' << value << ',' << region << '_' << value << "_cell";
      }
      health << '\n';
    }
    if (probe)
      probe << "step,time,station,x_over_d,u,v,w,included,exclusion\n";
    return static_cast<bool>(force) && static_cast<bool>(health) &&
           static_cast<bool>(conservation) &&
           static_cast<bool>(probe) &&
           (!options.observe_performance || static_cast<bool>(performance));
  });
  if (!okay) return 6;

  okay = MPI_Comm_split_type(communicator, MPI_COMM_TYPE_SHARED, 0,
                             MPI_INFO_NULL,
                             &node_communicator) == MPI_SUCCESS;
  if (!all_true(communicator, okay)) return 6;

  okay = local_stage(communicator, [&] {
    return rank != 0 || (evidence_file.open_exclusive(options.run_root / "evidence.jsonl") &&
           sync_directory(options.run_root));
  });
  if (!okay) return 6;

  // Argument construction happens outside Writer's noexcept boundary. Freeze
  // the owned path in a local-only stage, then agree before any Writer call.
  fs::path visit_root;
  if (!local_stage(communicator, [&] {
        if (options.visit_interval != 0U)
          visit_root = options.run_root / "Visit";
        return true;
      })) {
    if (rank == 0) std::cerr << "visit_path_initialization_failure\n";
    return 6;
  }
  const double force_scale = 0.5 * spec.rho_ref * spec.u_ref * spec.u_ref *
                             spec.diameter * spec.span;
  if (!std::isfinite(force_scale) || !(force_scale > 0.0)) return 3;
  std::optional<MgApplyProfile> mg_before;
  for (std::uint64_t index = 0U; index < options.steps; ++index) {
    std::array<std::uint64_t, 6U> local_step_phases{};
    detail::LocalPhaseTimer<6U> step_timer(local_step_phases);
    if (options.observe_mg_cost) mg_before = mg_snapshot(driver);
    const auto begin = std::chrono::steady_clock::now();
    DriverStepReport step;
    if (options.observe_performance && hundun_v04_observe_step)
      hundun_v04_observe_step(starting_step + index + 1U, 1);
    LocalTimeLimits time_limits{1.0, 1.0, 1.0, 1.0, 1.0};
    status = driver.constrain_convective_time_limit(time_limits);
    if (status) status = driver.advance(time_limits, step);
    if (options.observe_performance && hundun_v04_observe_step)
      hundun_v04_observe_step(starting_step + index + 1U, 0);
    step_timer.phase(1U);
    const auto end = std::chrono::steady_clock::now();
    const auto local_nanoseconds = static_cast<std::uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin)
            .count());
    if (!status && rank == 0) {
      (void)write_numerical_failure(std::cerr, step.numerical_failure);
      (void)write_step_completion_failure(std::cerr, step.completion);
    }
    if (options.trace_window.count != 0U && !local_stage(communicator, [&] {
          for (std::size_t k = 0U; k < step.cell_trace.count; ++k) {
            const auto& s = step.cell_trace.samples[k];
            cell_trace << std::setprecision(17) << s.step << ',' << rank << ','
                << s.attempt << ',' << s.composition_sweep << ',' << s.stage << ','
                << s.global_index.x << ',' << s.global_index.y << ',' << s.global_index.z
                << ',' << unsigned(s.active) << ',' << s.rho << ',' << s.h << ','
                << s.temperature << ',' << s.pressure << ',' << s.rate << ','
                << s.rho_accepted << ',' << s.rho_previous << ',' << s.h_accepted
                << ',' << s.h_previous << ',' << step.cell_trace.dropped << '\n';
          }
          cell_trace.flush();
          return static_cast<bool>(cell_trace);
        })) return status ? 6 : 7;
    // Pure local, buffered diagnostic output; agree errors before any later
    // collective. Also preserve rejected attempts when advance ultimately fails.
    if (options.observe_performance && !local_stage(communicator, [&] {
          const auto& perf = step.pressure_energy_performance;
          for (std::size_t n = 0U; n < perf.loop_count; ++n) {
            const auto& row = perf.loops[n];
            const auto& solve = row.solve;
            const auto& linear = row.linear;
            const auto& g = row.globalization;
            const auto& work = g.work;
            loop_performance << std::setprecision(17) << starting_step + index + 1U << ',' << rank
                << ',' << row.attempt << ',' << row.scalar_coupling_sweep << ',' << row.dt << ',' << unsigned(row.attempt_status.code)
                << ',' << unsigned(solve.corrector) << ',' << unsigned(solve.refinement)
                << ',' << unsigned(solve.kind) << ',' << solve.invoked << ',' << linear.iterations
                << ',' << linear.operator_applies << ',' << linear.preconditioner_applies
                << ',' << linear.initial_true_residual << ',' << linear.final_true_residual
                << ',' << linear.true_residual_criterion_valid << ',' << linear.rhs_norm
                << ',' << linear.absolute_tolerance << ',' << linear.relative_tolerance
                << ',' << linear.true_residual_limit;
            for (auto ns : solve.local_nanoseconds) loop_performance << ',' << ns;
            loop_performance << ',' << linear.operator_nanoseconds << ',' << linear.preconditioner_nanoseconds
                << ',' << linear.arnoldi_dot_nanoseconds << ',' << linear.arnoldi_reduce_nanoseconds
                << ',' << linear.arnoldi_update_nanoseconds << ',' << solve.mg_refill_nanoseconds
                << ',' << solve.mg_copy_nanoseconds << ',' << solve.structured_wait_nanoseconds
                << ',' << solve.structured_control_nanoseconds << ',' << g.valid
                << ',' << work.baseline_evaluations << ',' << work.extrapolation_evaluations
                << ',' << work.ladder_evaluations << ',' << work.incomplete_evaluations
                << ',' << work.local_evaluation_nanoseconds << ',' << g.baseline.global_normalized_continuity
                << ',' << g.baseline.global_normalized_energy << ',' << g.selected.global_normalized_continuity
                << ',' << g.selected.global_normalized_energy << ',' << g.selected.alpha
                << ',' << perf.dropped_loops;
            if (options.observe_mg_cost) write_mg_loop(loop_performance, solve.mg_apply);
            if (options.observe_fgmres_recovery) {
              const auto& r = solve.fgmres_recovery;
              loop_performance << ',' << r.available << ',' << linear.norm_breakdown_restarts;
              for (const auto count : {r.unsafe_norms, r.discarded_columns,
                      r.explicit_reorthogonalizations, r.unsafe_restarts, r.happy_restarts,
                      r.length_restarts, r.initial_residual_applies, r.arnoldi_applies,
                      r.unsafe_residual_applies, r.interior_residual_applies, r.cycle_residual_applies})
                loop_performance << ',' << count;
            }
            loop_performance << ',' << observation_source.data() << '\n';
          }
          if (options.observe_mg_cost) {
            write_mg_step(mg_performance, starting_step + index + 1U, rank,
                          driver, *mg_before, observation_source);
            mg_performance.flush();
          }
          loop_performance.flush();
          return static_cast<bool>(loop_performance) &&
              (!options.observe_mg_cost || static_cast<bool>(mg_performance));
        })) return status ? 6 : 7;
    std::uint64_t maximum_nanoseconds = 0U;
    okay = MPI_Allreduce(&local_nanoseconds, &maximum_nanoseconds, 1,
                         MPI_UINT64_T, MPI_MAX, communicator) == MPI_SUCCESS;
    if (!status || !okay || !step.accepted ||
        step.accepted_step != starting_step + index + 1U ||
        !std::isfinite(step.accepted_time) ||
        !terminal_audit_valid(model, step)) {
      std::array<StageTimingRecord, kDriverTimedStageCapacity> failed_stages{};
      const Status failed_timing_status =
          okay ? collect_stage_timings(communicator, step, failed_stages)
               : Status{StatusCode::mpi_failure, kRunnerInput};
      if (rank == 0)
        std::cerr << "advance_failure expected_step="
                  << starting_step + index + 1U
                  << " reported_step=" << step.accepted_step
                  << " attempts=" << step.attempts << " status="
                  << static_cast<unsigned>(status.code) << '/' << status.detail
                  << " stage=" << step.failed_stage
                  << " momentum_predictor_passes="
                  << static_cast<unsigned>(
                         step.momentum_predictor_solve.predictor_passes)
                  << " pressure_solve_calls="
                  << static_cast<unsigned>(step.piso.pressure_solve_calls)
                  << " refinement_solve_calls="
                  << static_cast<unsigned>(
                         step.piso.pressure_energy_refinement_solve_calls)
                  << " max_rank_step_ns=" << maximum_nanoseconds
                  << '\n';
      if (rank == 0 && failed_timing_status) {
        std::cerr << "failure_stage_max_ns";
        for (const StageTimingRecord& timing : failed_stages)
          std::cerr << ' ' << timing.stage << '=' << timing.maximum_nanoseconds;
        std::cerr << '\n';
      }
      if (rank == 0 && step.pressure_energy_globalization.valid &&
          step.pressure_energy_globalization.trajectory_count != 0U) {
        const std::size_t last = static_cast<std::size_t>(
            step.pressure_energy_globalization.trajectory_count - 1U);
        const PressureEnergyGlobalizationIterationReport& iteration =
            step.pressure_energy_globalization.trajectory[last];
        std::cerr << "pressure_energy_failure corrector="
                  << static_cast<unsigned>(iteration.corrector)
                  << " refinement="
                  << static_cast<unsigned>(iteration.refinement_iteration)
                  << " baseline_continuity="
                  << iteration.baseline.global_normalized_continuity
                  << " baseline_energy="
                  << iteration.baseline.global_normalized_energy
                  << " selected_alpha=" << iteration.selected.alpha
                  << " selected_continuity="
                  << iteration.selected.global_normalized_continuity
                  << " selected_energy="
                  << iteration.selected.global_normalized_energy << '\n';
      }
      if (rank == 0 && step.pressure_energy_globalization.valid) {
        const PressureEnergyGlobalizationAttemptReport& attempt =
            step.pressure_energy_globalization;
        for (std::size_t ordinal = 0U; ordinal < attempt.trajectory_count &&
                                       ordinal < attempt.trajectory.size();
             ++ordinal) {
          const auto& iteration = attempt.trajectory[ordinal];
          std::cerr << "pressure_energy_trajectory ordinal=" << ordinal
                    << " corrector="
                    << static_cast<unsigned>(iteration.corrector)
                    << " refinement="
                    << static_cast<unsigned>(iteration.refinement_iteration)
                    << " jacobian="
                    << static_cast<unsigned>(iteration.jacobian_scope)
                    << " baseline_continuity="
                    << iteration.baseline.global_normalized_continuity
                    << " baseline_energy="
                    << iteration.baseline.global_normalized_energy
                    << " alpha=" << iteration.selected.alpha
                    << " selected_continuity="
                    << iteration.selected.global_normalized_continuity
                    << " selected_energy="
                    << iteration.selected.global_normalized_energy << '\n';
        }
        std::cerr << "pressure_energy_attempt corrector="
                  << static_cast<unsigned>(attempt.corrector)
                  << " samples=" << static_cast<unsigned>(attempt.sample_count)
                  << " baseline_evaluations="
                  << attempt.work.baseline_evaluations
                  << " extrapolation_evaluations="
                  << attempt.work.extrapolation_evaluations
                  << " ladder_evaluations=" << attempt.work.ladder_evaluations
                  << " incomplete_evaluations="
                  << attempt.work.incomplete_evaluations
                  << " evaluation_ns_rank0="
                  << attempt.work.local_evaluation_nanoseconds
                  << " max_dp=" << attempt.maximum_absolute_pressure_correction
                  << " max_dh=" << attempt.maximum_absolute_enthalpy_correction
                  << " baseline_continuity="
                  << attempt.baseline.global_normalized_continuity
                  << " baseline_energy="
                  << attempt.baseline.global_normalized_energy << '\n';
        for (std::uint8_t sample = 0U; sample < attempt.sample_count;
             ++sample) {
          const PressureEnergyGlobalizationSample& candidate =
              attempt.candidates[sample];
          std::cerr << "pressure_energy_sample ordinal="
                    << static_cast<unsigned>(sample)
                    << " alpha=" << candidate.alpha
                    << " continuity="
                    << candidate.global_normalized_continuity
                    << " energy=" << candidate.global_normalized_energy
                    << " admissible="
                    << candidate.thermodynamically_admissible << '/'
                    << candidate.state_and_flux_finite << '\n';
        }
      }
      return 7;
    }
    const bool startup = step.accepted_step == 1U;
    // Exact CN/BE restarts retain the accepted endpoint and flux histories.
    const bool recovery =
        restarted && restart_requires_recovery && index == 0U;
    if ((startup || recovery) && step.effective_bdf.order != 1U) {
      if (rank == 0) std::cerr << "backward_euler_provenance_failure\n";
      return 7;
    }
    if (restarted && !restart_requires_recovery && index == 0U &&
        (step.proposal.bdf.order != 1U || step.effective_bdf.order != 1U)) {
      if (rank == 0) std::cerr << "exact_restart_cn_be_provenance_failure\n";
      return 7;
    }
    SurfaceForce surface;
    FinalForceCertificate certificate;
    status = driver.committed_surface_force(surface, certificate);
    if (status) status = driver.committed_output_snapshot(snapshot);
    ThermoExtrema extrema;
    std::vector<double> probes;
    okay = static_cast<bool>(status) && certificate.valid() &&
           finite_force(surface) && snapshot.committed &&
           snapshot.step == step.accepted_step &&
           snapshot.plan == product_fingerprint;
    if (!all_true(communicator, okay)) {
      if (rank == 0) std::cerr << "committed_observable_failure\n";
      return 7;
    }
    okay = collect_thermo_extrema(communicator, model, thermodynamics,
                                  driver.pressure_reference(), snapshot,
                                  extrema);
    if (okay) okay = collect_probes(communicator, runtime, snapshot, probes);
    if (!all_true(communicator, okay)) {
      if (rank == 0) std::cerr << "committed_observable_failure\n";
      return 7;
    }

    const bool in_window = step.accepted_step >= accumulator.epoch.sampling_start_step &&
                           step.accepted_step <= spec.collection_end_step;
    const bool retry = step.attempts != 1U;
    const bool fallback = step.temporal_method_fallback;
    const bool included =
        in_window && !startup && !recovery && !retry && !fallback;
    const char* exclusion =
        included      ? "none"
        : startup     ? "startup"
        : recovery    ? "restart_recovery"
        : retry       ? "retry"
        : fallback    ? "temporal_fallback"
                      : "development";
    if (included) {
      okay = add_sample(spec, runtime, snapshot, step.proposal.dt, accumulator);
      if (!all_true(communicator, okay)) {
        if (rank == 0) std::cerr << "nonfinite_snapshot_observable\n";
        return 7;
      }
    }

    const bool visit =
        options.visit_interval != 0U &&
        (step.accepted_step % options.visit_interval == 0U ||
         step.accepted_step == target_step);
    step_timer.phase(2U);
    if (visit)
      status = VisitWriter::write(communicator, visit_root, services, snapshot);
    if (!status) {
      // An output failure ends the run, not the already committed time step.
      // Query the public committed authority; never retry or roll it back.
      CommittedOutputSnapshot retained;
      const Status retained_status = driver.committed_output_snapshot(retained);
      if (rank == 0)
        std::cerr << "visit_status=" << static_cast<unsigned>(status.code)
                  << '/' << status.detail
                  << " accepted_step=" << step.accepted_step
                  << " committed_step=" << (retained_status ? retained.step : 0U)
                  << " accepted_time=" << std::setprecision(17) << step.accepted_time
                  << " committed_time=" << retained.time << '\n';
      return 6;
    }
    step_timer.phase(3U);
    DriverResourceReport global_resources;
    if (status)
      status = append_evidence(
          communicator, node_communicator, rank, evidence_file, services, model,
          product_fingerprint, cpu_fingerprint, stl_fingerprint,
          candidate_identity, build_identity, binary_identity, run_start,
          step, maximum_nanoseconds, recovery, global_resources);
    if (!status) {
      if (rank == 0)
        std::cerr << "evidence_status=" << static_cast<unsigned>(status.code)
                  << '/' << status.detail << '\n';
      return 6;
    }

    step_timer.phase(4U);
    if (!all_true(communicator, step.terminal_equations.valid &&
        step.conservation.valid && step.terminal_equations.final_flux ==
            step.piso.final_flux_revision)) return 6;
    if (rank == 0) {
      const auto& equation = step.terminal_equations;
      const auto& balance = step.conservation;
      conservation << step.accepted_step << ',' << std::setprecision(17)
          << step.accepted_time << ','
          << static_cast<unsigned>(step.effective_bdf.order) << ','
          << balance.epoch_start_step << ',' << equation.final_flux << ','
          << equation.mass << ',' << equation.internal_energy << ','
          << equation.kinetic_energy;
      for (double value : equation.momentum_linf) conservation << ',' << value;
      for (double value : equation.momentum_l1) conservation << ',' << value;
      conservation << ',' << equation.continuity_signed << ','
          << equation.energy_signed << ',' << equation.energy_l1 << ','
          << equation.total_equation_defect << ',' << balance.mass_outflow
          << ',' << balance.enthalpy_outflow << ','
          << balance.kinetic_energy_outflow << ','
          << balance.conductive_heat_input << ',' << balance.species_enthalpy_diffusion_input
          << ',' << balance.viscous_work_input
          << ',' << balance.mass_bdf_rate << ',' << balance.total_energy_bdf_rate
          << ',' << balance.mass_balance_defect << ','
          << balance.total_energy_balance_defect << ','
          << balance.cumulative_mass_defect << ','
          << balance.cumulative_energy_defect << ',' << equation.momentum_normalization_valid
          << ',' << equation.momentum_reference_velocity;
      for (auto value : equation.momentum_normalized_linf) conservation << ',' << value;
      for (const auto& worst : equation.momentum_worst)
        conservation << ',' << worst.global_location << ',' << worst.rank;
      for (auto count : equation.momentum_region_cells) conservation << ',' << count;
      for (const auto& region : equation.momentum_region_normalized_linf)
        for (auto value : region) conservation << ',' << value;
      for (const auto& region : equation.momentum_region_normalized_rms)
        for (auto value : region) conservation << ',' << value;
      conservation << '\n';
      // Publish the lightweight health ledger to the OS every accepted step;
      // this is not a per-step fsync or a checkpoint durability promise.
      conservation.flush();
      force << step.accepted_step << ',' << std::setprecision(17)
            << step.accepted_time << ','
            << static_cast<unsigned>(step.proposal.bdf.order) << ','
            << static_cast<unsigned>(step.effective_bdf.order) << ','
            << step.attempts << ',' << surface.pressure.x << ','
            << surface.pressure.y << ',' << surface.pressure.z << ','
            << surface.viscous.x << ',' << surface.viscous.y << ','
            << surface.viscous.z << ',' << surface.total.x << ','
            << surface.total.y << ',' << surface.total.z << ','
            << surface.moment.x << ',' << surface.moment.y << ','
            << surface.moment.z << ',' << surface.total.x / force_scale << ','
            << surface.total.y / force_scale << ','
            << surface.total.z / force_scale << ',' << certificate.plan << ','
            << certificate.terminal_state << ',' << certificate.final_flux
            << ',' << certificate.force << ',' << certificate.state << ','
            << (included ? 1 : 0) << ',' << exclusion << '\n';
      health
          << step.accepted_step << ',' << std::setprecision(17)
          << step.accepted_time << ','
          << static_cast<unsigned>(step.proposal.bdf.order) << ','
          << static_cast<unsigned>(step.effective_bdf.order) << ','
          << step.attempts << ',' << (retry ? 1 : 0) << ','
          << (recovery ? 1 : 0) << ',' << (fallback ? 1 : 0) << ','
          << 1 << ',' << step.piso.final_flux_revision << ','
          << step.piso.eos_residual << ',' << model.solver.terminal.eos << ','
          << step.piso.continuity_residual << ','
          << model.solver.terminal.continuity << ','
          << step.piso.energy_residual << ','
          << model.solver.terminal.continuity << ','
          << step.piso.closed_mass_residual << ','
          << model.solver.terminal.closed_mass << ','
          << step.piso.gauge_residual << ',' << model.solver.terminal.gauge
          << ',' << extrema.pressure_min << ',' << extrema.pressure_max << ','
          << extrema.temperature_min << ',' << extrema.temperature_max << ','
          << extrema.density_min << ',' << extrema.density_max << ','
          << step.momentum_predictor_limiter.advective_cfl.out_max << ','
          << step.momentum_predictor_limiter.advective_cfl.absolute_max << ','
          << step.momentum_predictor_limiter.advective_cfl.limit << ','
          << step.piso.committed_convective_cfl_out_max << ','
          << step.piso.committed_convective_cfl_abs_max << ','
          << step.piso.committed_convective_cfl_limit << ','
          << (step.momentum_predictor_limiter.correction_metrics_applicable
                  ? 1
                  : 0)
          << ','
          << step.momentum_predictor_limiter.theta << ','
          << step.momentum_predictor_limiter.minimum_face_alpha << ','
          << step.momentum_predictor_limiter.active_correction_faces << ','
          << step.momentum_predictor_limiter.activations << ','
          << step.momentum_predictor_limiter.limited_face_fraction << ','
          << (step.momentum_predictor_limiter.limited ? 1 : 0) << ','
          << step.thermophysical_predictor.theta << ','
          << (step.thermophysical_predictor.limited ? 1 : 0) << ','
          << static_cast<unsigned>(step.piso.pressure_solve_calls) << ','
          << static_cast<unsigned>(
                 step.piso.pressure_energy_refinement_solve_calls)
          << ',' << global_resources.linear_iterations << ','
          << maximum_nanoseconds << ',' << (included ? 1 : 0) << ','
          << exclusion;
      for (std::size_t region = 0U; region < 2U; ++region) {
        health << ',' << extrema.region_count[region];
        for (std::size_t k = 0U; k < 6U; ++k) {
          const std::size_t slot = region * 6U + k;
          health << ',' << extrema.regional[slot] << ',' << extrema.region_cell[slot];
        }
      }
      health << '\n';
      for (std::size_t station = 0U;
           station < spec.station_x_over_d.size(); ++station) {
        const std::size_t base = station * 3U;
        probe << step.accepted_step << ',' << std::setprecision(17)
              << step.accepted_time << ',' << station << ','
              << spec.station_x_over_d[station] << ',' << probes[base] << ','
              << probes[base + 1U] << ',' << probes[base + 2U] << ','
              << (included ? 1 : 0) << ',' << exclusion << '\n';
      }
      okay = static_cast<bool>(force) && static_cast<bool>(health) &&
             static_cast<bool>(conservation) &&
             static_cast<bool>(probe);
    }
    if (!all_true(communicator, okay)) return 6;

    step_timer.phase(5U);
    const bool save =
        step.accepted_step % spec.checkpoint_interval == 0U ||
        step.accepted_step == target_step;
    if (save) {
      if (rank == 0) {
        force.flush();
        health.flush();
        conservation.flush();
        probe.flush();
        okay = static_cast<bool>(force) && static_cast<bool>(health) &&
               static_cast<bool>(conservation) &&
               static_cast<bool>(probe) && evidence_file.sync();
      }
      if (!all_true(communicator, okay) ||
          !consensus_u64(communicator, accumulator.sample_steps) ||
          !checkpoint(communicator, rank, driver, services, options.run_root, spec,
                      fingerprint, runtime, snapshot, accumulator)) {
        if (rank == 0) std::cerr << "checkpoint_failure\n";
        return 6;
      }
      if (rank == 0)
        std::cout << "CHECKPOINT step=" << step.accepted_step
                  << " time=" << std::setprecision(17) << step.accepted_time
                  << " samples=" << accumulator.sample_steps << '\n';
    }
    step_timer.stop();
    if (options.observe_performance) {
      // One diagnostic gather per observed step. Preserve each rank's disjoint
      // accounting; do not sum independent phase maxima as a wall-clock time.
      constexpr std::size_t width = 55U;
      std::array<std::uint64_t, width> local{};
      local[0U] = step.accepted_step;
      local[1U] = static_cast<std::uint64_t>(rank);
      for (auto ns : local_step_phases) local[2U] += ns;
      std::copy(local_step_phases.begin(), local_step_phases.end(),
                local.begin() + 3U);
      const auto& work = step.pressure_energy_performance.candidate;
      local[9U] = work.local_evaluation_nanoseconds;
      std::copy(work.local_phase_nanoseconds.begin(),
                work.local_phase_nanoseconds.end(), local.begin() + 10U);
      const auto& solves =
          step.pressure_energy_performance.solve_nanoseconds;
      std::copy(solves.begin(), solves.end(), local.begin() + 18U);
      local[21U] = work.baseline_evaluations;
      local[22U] = work.extrapolation_evaluations;
      local[23U] = work.ladder_evaluations;
      local[24U] = work.incomplete_evaluations;
      local[25U] = work.rejected_extrapolations;
      const auto& counts = step.resources;
      local[26U] = counts.reduction_collectives +
                   counts.mg_blocking_collectives +
                   counts.predictor_blocking_collectives +
                   counts.structured_control_collectives +
                   counts.ibm_control_collectives;
      local[27U] = counts.structured_control_collectives;
      local[28U] = counts.ibm_control_collectives;
      for (std::size_t kind = 0U; kind < 3U; ++kind) {
        local[29U + kind * 4U] = step.pressure_energy_performance.calls_by_kind[kind];
        for (std::size_t phase = 0U; phase < 3U; ++phase)
          local[30U + kind * 4U + phase] =
              step.pressure_energy_performance.nanoseconds_by_kind[kind][phase];
      }
      std::copy(step.pressure_energy_performance.krylov_nanoseconds.begin(),
                step.pressure_energy_performance.krylov_nanoseconds.end(), local.begin() + 41U);
      std::copy(step.pressure_energy_performance.final_audit_nanoseconds.begin(),
                step.pressure_energy_performance.final_audit_nanoseconds.end(), local.begin() + 46U);
      local[49U] = step.resources.structured_wait_nanoseconds;
      local[50U] = step.resources.structured_control_nanoseconds;
      local[51U] = step.pressure_energy_performance.dropped_loops;
      local[52U] = step.scalar_transport.remap_nanoseconds;
      local[53U] = step.scalar_transport.coupling_sweeps;
      local[54U] = step.scalar_transport.remap_iterations;
      std::vector<std::uint64_t> gathered;
      // Allocate before entering Gather, with one all-rank failure decision.
      try {
        if (rank == 0) gathered.resize(width * static_cast<std::size_t>(ranks));
      } catch (...) {
        okay = false;
      }
      if (!all_true(communicator, okay)) return 6;
      if (MPI_Gather(local.data(), static_cast<int>(width), MPI_UINT64_T,
                     gathered.data(), static_cast<int>(width), MPI_UINT64_T, 0,
                     communicator) != MPI_SUCCESS)
        return 6;
      if (rank == 0) {
        for (int source = 0; source < ranks; ++source) {
          const auto offset = static_cast<std::size_t>(source) * width;
          for (std::size_t column = 0U; column < width; ++column)
            performance << (column == 0U ? "" : ",")
                        << gathered[offset + column];
          performance << ',' << observation_source.data() << '\n';
        }
        performance.flush();
        okay = static_cast<bool>(performance);
      }
      if (!all_true(communicator, okay)) return 6;
    }
  }
  return 0;
  }();
  const bool logs_complete = complete_logs(communicator, rank,
      {{&force, &health, &conservation, &probe, &performance, &loop_performance,
        &cell_trace, &mg_performance}},
      evidence_file);
  okay = all_true(communicator, run_result == 0 && logs_complete);
  if (okay) okay = local_stage(communicator, [&] {
    if (rank != 0) return true;
    return ::chmod((options.run_root / "evidence.jsonl").c_str(), 0444) == 0 &&
           ::chmod((options.run_root / "force.csv").c_str(), 0444) == 0 &&
           ::chmod((options.run_root / "health.csv").c_str(), 0444) == 0 &&
           ::chmod((options.run_root / "conservation.csv").c_str(), 0444) == 0 &&
           ::chmod((options.run_root / "probe.csv").c_str(), 0444) == 0 &&
           sync_directory(options.run_root);
  });
  if (node_communicator != MPI_COMM_NULL)
    okay = MPI_Comm_free(&node_communicator) == MPI_SUCCESS && okay;
  const bool completed = all_true(communicator, okay);
  if (run_result != 0) return run_result;
  if (!completed) return 6;
  if (rank == 0)
    std::cout << "COMPLETED steps=" << options.steps
              << " final_step=" << target_step
              << " samples=" << accumulator.sample_steps << '\n';
  return 0;
}

bool self_test(MPI_Comm communicator) {
  const std::array<double, 4U> coordinates{{-1.5, -0.5, 0.5, 1.5}};
  Bracket exact;
  Bracket middle;
  Bracket invalid;
  bool okay = bracket({coordinates.data(), coordinates.size()}, 0.5, exact) &&
              exact.lower == 2 && exact.upper == 2 &&
              exact.upper_weight == 0.0 &&
              bracket({coordinates.data(), coordinates.size()}, 0.0,
                      middle) &&
              middle.lower == 1 && middle.upper == 2 &&
              std::abs(middle.upper_weight - 0.5) < 1.0e-15 &&
              !bracket({coordinates.data(), coordinates.size()}, 2.0,
                       invalid);
  MPI_Comm node_communicator = MPI_COMM_NULL;
  okay = okay &&
         MPI_Comm_split_type(communicator, MPI_COMM_TYPE_SHARED, 0,
                             MPI_INFO_NULL,
                             &node_communicator) == MPI_SUCCESS;
  std::uint64_t maximum_rank_rss = 0U;
  std::uint64_t maximum_node_rss = 0U;
  if (okay) {
    const Status first = collect_peak_rss(
        communicator, node_communicator, maximum_rank_rss, maximum_node_rss);
    const Status second = collect_peak_rss(
        communicator, node_communicator, maximum_rank_rss, maximum_node_rss);
    okay = first && second && maximum_rank_rss > 0U &&
           maximum_node_rss >= maximum_rank_rss;
  }
  if (node_communicator != MPI_COMM_NULL)
    okay = MPI_Comm_free(&node_communicator) == MPI_SUCCESS && okay;
  StatisticsSpec spec;
  spec.development_steps = 10U;
  spec.collection_end_step = 20U;
  spec.checkpoint_interval = 5U;
  spec.rho_ref = 2.0;
  spec.u_ref = 3.0;
  spec.diameter = 4.0;
  spec.span = 5.0;
  spec.cylinder_center_x = -1.0;
  spec.station_x_over_d = {1.0, 2.0};
  const std::uint64_t fingerprint = spec_fingerprint(spec);
  okay = okay && fingerprint != 0U &&
         0.5 * spec.rho_ref * spec.u_ref * spec.u_ref * spec.diameter *
                 spec.span ==
             180.0;

  const fs::path root = fs::temp_directory_path() /
                        ("hundun-v04-thin-runner-" +
                         std::to_string(::getpid()));
  std::error_code error;
  fs::remove_all(root, error);
  error.clear();
  okay = okay && fs::create_directory(root, error) && !error;
  const fs::path spec_path = root / "statistics.d";
  const std::string spec_text =
      std::string(kSpecMagic) +
      "\ndevelopment_steps 10\ncollection_end_step 20\n"
      "checkpoint_interval 5\nrho_ref 2\nu_ref 3\ndiameter 4\n"
      "span 5\ncylinder_center_x -1\nstation_x_over_d 1\n"
      "station_x_over_d 2\nend\n";
  okay = okay && write_exclusive(spec_path, spec_text);
  StatisticsSpec parsed;
  std::string parse_error;
  okay = okay && parse_spec(spec_path, parsed, parse_error) &&
         spec_fingerprint(parsed) == fingerprint;

  CartesianMeshSpec mesh;
  mesh.kind = GeometryKind::uniform;
  mesh.lower = {0.0, 0.0, 0.0};
  mesh.upper = {2.0, 2.0, 2.0};
  mesh.has_exact_cells = true;
  mesh.exact_cells = {2, 2, 2};
  mesh.minimum_spacing = {1.0, 1.0, 1.0};
  mesh.max_growth_ratio = 1.0;
  mesh.limits = {64U, 1U << 20U};
  CartesianGeometryPlan geometry;
  MeshPatch patch;
  okay = static_cast<bool>(CartesianGeometryCompiler::compile(
      MPI_COMM_SELF, mesh, {}, geometry, patch)) && okay;
  std::array<double, 24U> velocity{};
  ConstFieldView values{velocity.data(), {2, 2, 2}, {}, 3U, 2U, 4U, 8U};
  const SnapshotFieldView field{"U", values, {}};
  CommittedOutputSnapshot sample;
  sample.geometry = &geometry;
  sample.patch = patch;
  sample.fields = {&field, 1U};
  StatisticsSpec sample_spec;
  sample_spec.station_x_over_d = {0.0};
  RuntimeGeometry sample_geometry;
  sample_geometry.station_brackets = {{0, 0, 0.0}};
  sample_geometry.centerline_bracket = {0, 0, 0.0};
  Accumulator weighted;
  weighted.profile.resize(12U);
  weighted.centerline.resize(6U);
  std::fill_n(velocity.begin(), 8U, 1.0);
  okay = add_sample(sample_spec, sample_geometry, sample, 0.1, weighted) && okay;
  std::fill_n(velocity.begin(), 8U, 3.0);
  okay = add_sample(sample_spec, sample_geometry, sample, 0.3, weighted) && okay;
  const bool time_weighted = std::abs(weighted.profile[1] / weighted.profile[0] - 2.5) < 1e-14 &&
      std::abs(weighted.profile[3] / weighted.profile[0] - 7.0) < 1e-14 &&
      std::abs(weighted.centerline[1] / weighted.centerline[0] - 2.5) < 1e-14;
  if (!time_weighted) std::cerr << "FAIL variable-dt time-weighted statistics\n";
  okay = time_weighted && okay;

  Accumulator source;
  source.profile = {1.0, 2.0, 4.0};
  source.centerline = {3.0, 5.0};
  source.sample_steps = 7U;
  const fs::path accumulator_path = root / "state.accumulator";
  okay = okay && write_exclusive(
                       accumulator_path,
                       encode_accumulator(fingerprint, 11U, 12U, 9U, 0.25,
                                          source));
  Accumulator restored;
  restored.profile.assign(source.profile.size(), 0.0);
  restored.centerline.assign(source.centerline.size(), 0.0);
  okay = okay && decode_accumulator(accumulator_path, fingerprint, 11U, 12U,
                                    9U, 0.25, restored) &&
         restored.profile == source.profile &&
         restored.centerline == source.centerline &&
         restored.sample_steps == source.sample_steps;
  Accumulator wrong_size;
  wrong_size.profile.assign(2U, 0.0);
  wrong_size.centerline.assign(2U, 0.0);
  okay = okay && !decode_accumulator(accumulator_path, fingerprint, 11U, 12U,
                                     9U, 0.25, wrong_size);
  const fs::path evidence_path = root / "evidence.jsonl";
  EvidenceFile evidence;
  okay = okay && evidence.open_exclusive(evidence_path) &&
         evidence.append("one\n") && evidence.append("two\n") &&
         evidence.sync() && evidence.close();
  std::ifstream evidence_input(evidence_path);
  std::ostringstream evidence_text;
  evidence_text << evidence_input.rdbuf();
  okay = okay && static_cast<bool>(evidence_input) &&
         evidence_text.str() == "one\ntwo\n";
  fs::remove_all(root, error);
  return okay;
}

void usage(int rank) {
  if (rank != 0) return;
  std::cerr
      << "usage:\n"
      << "  v04_thin_domain_runner --self-test\n"
      << "  v04_thin_domain_runner --spec PATH --case-root PATH --dry-plan\n"
      << "  v04_thin_domain_runner --spec PATH --case-root PATH "
         "--run-root PATH [--restart-root PATH] --steps N "
         "[--restart-method-recovery [--restart-development-steps N]] "
         "[--visit-interval N] [--observe-performance [--observe-mg-cost] [--observe-fgmres-recovery]] "
         "[--trace-cell i,j,k (at most twice) --trace-first N --trace-last N]\n";
}

}  // namespace

int main(int argc, char** argv) {
  if (!hundun::v04::prepare_mpi_runtime_environment()) return 2;
  if (MPI_Init(&argc, &argv) != MPI_SUCCESS) return 2;
  int rank = 0;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  Options options;
  int result = 0;
  if (!parse_options(argc, argv, options)) {
    usage(rank);
    result = 2;
  } else if (options.self_test) {
    const bool local = self_test(MPI_COMM_WORLD);
    const bool passed = all_true(MPI_COMM_WORLD, local);
    if (rank == 0)
      std::cout << (passed ? "PASS" : "FAIL")
                << " v04_thin_domain_runner_self_test\n";
    result = passed ? 0 : 1;
  } else {
    result = run(MPI_COMM_WORLD, rank, options);
  }
  MPI_Finalize();
  return result;
}
