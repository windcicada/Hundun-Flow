// SPDX-License-Identifier: Apache-2.0
// Developed by WANG YUDONG | Email: wangyudong@buaa.edu.cn | Github/Wechat: windcicada | Year.M: 2026.09

#include "hundun/v04_case.hpp"

#include "app_case_detail.hpp"
#include "app_reaction_detail.hpp"
#include "app_spray_detail.hpp"
#include "physics_input_detail.hpp"
#include "yyjson.h"

#include <mpi.h>

#include <cerrno>
#include <algorithm>
#include <array>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fcntl.h>
#include <initializer_list>
#include <limits>
#include <locale>
#include <new>
#include <optional>
#include <set>
#include <sstream>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <sys/types.h>
#include <type_traits>
#include <unordered_set>
#include <unistd.h>
#include <utility>
#include <vector>

namespace hundun::v04 {
namespace {

namespace fs = std::filesystem;

constexpr std::uint8_t kLegacyWireVersion = 9U;
constexpr std::uint8_t kLegacyPressureAlgorithmWireVersion = 10U;
constexpr std::uint8_t kWireVersion = 11U;
constexpr std::uint8_t kPressureAlgorithmWireVersion = 12U;
constexpr std::uint8_t kSimpleWireVersion = 13U;
constexpr std::uint8_t kSimplePressureAlgorithmWireVersion = 14U;
constexpr std::uint8_t kReferenceAxesWireVersion = 15U;
constexpr std::uint8_t kReferenceAxesPressureAlgorithmWireVersion = 16U;
constexpr std::uint8_t kReferenceAxesSimpleWireVersion = 17U;
constexpr std::uint8_t kReferenceAxesSimplePressureAlgorithmWireVersion = 18U;
constexpr std::uint8_t kReactionWireFlag = 128U;
constexpr std::uint8_t kSprayWireFlag = 64U;
// An envelope around an unchanged base case wire, followed by explicit import
// geometry and inlet-patch extensions. Existing case wires remain unchanged.
constexpr std::uint8_t kPatchInletsWireVersion = 19U;
constexpr std::uint8_t kCflBandWireVersion = 20U;
constexpr std::uint8_t kSmagorinskyWireVersion = 21U;
constexpr std::uint8_t kSprayEvaporationWireVersion = 22U;
constexpr std::uint8_t kCflDefinitionWireVersion = 23U;
constexpr std::uint8_t kReferenceOuterWireVersion = 24U;
constexpr std::uint64_t kFnvOffset = 14695981039346656037ULL;
constexpr std::uint64_t kFnvPrime = 1099511628211ULL;
constexpr std::size_t kMaxJsonDepth = 32U;
constexpr std::size_t kMaxScalarsPerFace = 64U;
constexpr std::size_t kMaxTransportedScalars = 64U;
constexpr std::size_t kMaxStableNameBytes = 255U;

constexpr bool reference_axes_wire(std::uint8_t version) noexcept {
  return version == kReferenceAxesWireVersion ||
         version == kReferenceAxesPressureAlgorithmWireVersion ||
         version == kReferenceAxesSimpleWireVersion ||
         version == kReferenceAxesSimplePressureAlgorithmWireVersion;
}

constexpr bool transport_law_wire_compatible(std::uint8_t version,
                                             TransportLaw law) noexcept {
  return law != TransportLaw::nasa_air || reference_axes_wire(version);
}

static_assert(!transport_law_wire_compatible(kLegacyWireVersion,
                                             TransportLaw::nasa_air));
static_assert(!transport_law_wire_compatible(
    kLegacyPressureAlgorithmWireVersion, TransportLaw::nasa_air));
static_assert(!transport_law_wire_compatible(kWireVersion,
                                             TransportLaw::nasa_air));
static_assert(!transport_law_wire_compatible(
    kPressureAlgorithmWireVersion, TransportLaw::nasa_air));
static_assert(!transport_law_wire_compatible(kSimpleWireVersion,
                                             TransportLaw::nasa_air));
static_assert(!transport_law_wire_compatible(
    kSimplePressureAlgorithmWireVersion, TransportLaw::nasa_air));
static_assert(transport_law_wire_compatible(kReferenceAxesWireVersion,
                                            TransportLaw::nasa_air));
static_assert(transport_law_wire_compatible(
    kReferenceAxesPressureAlgorithmWireVersion,
    TransportLaw::nasa_air));
static_assert(transport_law_wire_compatible(kReferenceAxesSimpleWireVersion,
                                            TransportLaw::nasa_air));
static_assert(transport_law_wire_compatible(
    kReferenceAxesSimplePressureAlgorithmWireVersion,
    TransportLaw::nasa_air));

constexpr bool simple_wire(std::uint8_t version) noexcept {
  return version == kSimpleWireVersion ||
         version == kSimplePressureAlgorithmWireVersion ||
         version == kReferenceAxesSimpleWireVersion ||
         version == kReferenceAxesSimplePressureAlgorithmWireVersion;
}

constexpr bool pressure_algorithm_wire(std::uint8_t version) noexcept {
  return version == kLegacyPressureAlgorithmWireVersion ||
         version == kPressureAlgorithmWireVersion ||
         version == kSimplePressureAlgorithmWireVersion ||
         version == kReferenceAxesPressureAlgorithmWireVersion ||
         version == kReferenceAxesSimplePressureAlgorithmWireVersion;
}

bool thermophysics_compatible_with_reference_axes(
    const ThermophysicalSpec& thermophysics, bool reference_axes) noexcept {
  return reference_axes ||
         std::none_of(
             thermophysics.species.begin(), thermophysics.species.end(),
             [](const SpeciesThermophysicalSpec& species) {
               return species.transport_law == TransportLaw::nasa_air;
             });
}

constexpr std::string_view kSemanticContract =
    "HUNDUN-FLOW-v0.4-case-wire-v11|input-schema=1|units=SI|"
    "flow=single_phase_low_mach_compressible|"
    "pressure_reference=boundary_absolute|closed_mass|reacting=false|"
    "coupling=PISO|pressure_correctors=2|pressure-linear=typed|"
    "terminal-tolerances=typed|"
    "transported-scalars=typed-catalog-with-schmidt-closures|"
    "thermophysics=typed-direct-root-data|boundaries=typed-six-face|"
    "ibm-reconstruction-policy=strict_quadratic|adaptive_order|"
    "schemes=typed|time=typed";
constexpr std::string_view kSimpleSemanticContract =
    "HUNDUN-FLOW-v0.4-case-wire-v13|input-schema=1|units=SI|"
    "flow=single_phase_low_mach_compressible|"
    "pressure_reference=boundary_absolute|closed_mass|reacting=false|"
    "coupling=SIMPLE|outer_iterations=2|pressure-linear=typed|"
    "terminal-tolerances=typed|"
    "transported-scalars=typed-catalog-with-schmidt-closures|"
    "thermophysics=typed-direct-root-data|boundaries=typed-six-face|"
    "ibm-reconstruction-policy=strict_quadratic|adaptive_order|"
    "schemes=typed|time=typed";

static_assert(std::is_nothrow_move_assignable_v<ValidatedModel>,
              "ValidatedModel publication must not allocate or throw");
static_assert(sizeof(double) == sizeof(std::uint64_t) &&
                  std::numeric_limits<double>::is_iec559,
              "case wire requires IEEE-754 binary64 doubles");

enum Detail : std::uint32_t {
  detail_none = 0,
  detail_case_root = 1,
  detail_case_json = 2,
  detail_json_too_large = 3,
  detail_json_syntax = 4,
  detail_json_duplicate_key = 5,
  detail_json_schema = 6,
  detail_json_value = 7,
  detail_reference_count = 8,
  detail_reference_path = 9,
  detail_reference_missing = 10,
  detail_reference_too_large = 11,
  detail_wire = 12,
  detail_collective = 13,
};

#if defined(HUNDUN_V04_ENABLE_TEST_ACCESS)
std::atomic<detail::FileOpenObserver> g_file_open_observer{nullptr};
std::atomic<int> g_last_lowest_failing_rank{-1};
#endif

Status invalid_case(Detail detail_code) noexcept {
  return {StatusCode::invalid_case, static_cast<std::uint32_t>(detail_code)};
}

void notify_file_open(int rank) noexcept {
#if defined(HUNDUN_V04_ENABLE_TEST_ACCESS)
  const auto observer = g_file_open_observer.load(std::memory_order_relaxed);
  if (observer != nullptr) {
    observer(rank);
  }
#else
  static_cast<void>(rank);
#endif
}

void record_lowest_failing_rank(int rank) noexcept {
#if defined(HUNDUN_V04_ENABLE_TEST_ACCESS)
  g_last_lowest_failing_rank.store(rank, std::memory_order_relaxed);
#else
  static_cast<void>(rank);
#endif
}

class Hash64 {
 public:
  void bytes(const void* data, std::size_t size) noexcept {
    const auto* input = static_cast<const unsigned char*>(data);
    for (std::size_t index = 0; index < size; ++index) {
      value_ ^= static_cast<std::uint64_t>(input[index]);
      value_ *= kFnvPrime;
    }
    if (mirror_ != nullptr) mirror_->bytes(data, size);
  }

  void text(std::string_view value) noexcept {
    const std::uint64_t size = static_cast<std::uint64_t>(value.size());
    integer(size);
    bytes(value.data(), value.size());
  }

  template <class Integer>
  void integer(Integer value) noexcept {
    using Unsigned = std::make_unsigned_t<Integer>;
    Unsigned bits = static_cast<Unsigned>(value);
    for (std::size_t byte = 0; byte < sizeof(Unsigned); ++byte) {
      const unsigned char part =
          static_cast<unsigned char>((bits >> (byte * 8U)) & 0xffU);
      bytes(&part, 1U);
    }
  }

  void real(double value) noexcept {
    if (value == 0.0) {
      value = 0.0;
    }
    std::uint64_t bits = 0U;
    std::memcpy(&bits, &value, sizeof(bits));
    integer(bits);
  }

  // Both lanes consume the remaining physical inputs exactly once. The
  // second lane has already hashed its own time method at the branch point.
  void mirror_remaining(Hash64& other) noexcept { mirror_ = &other; }

  Hash64 detached() const noexcept {
    Hash64 result;
    result.value_ = value_;
    return result;
  }

  PlanFingerprint finish() const noexcept {
    return value_ == 0U ? 1U : value_;
  }

 private:
  std::uint64_t value_{kFnvOffset};
  Hash64* mirror_{};
};

class Document {
 public:
  explicit Document(yyjson_doc* document) noexcept : document_(document) {}
  ~Document() { yyjson_doc_free(document_); }
  Document(const Document&) = delete;
  Document& operator=(const Document&) = delete;

  yyjson_doc* get() const noexcept { return document_; }

 private:
  yyjson_doc* document_{};
};

class UniqueFd {
 public:
  UniqueFd() noexcept = default;
  explicit UniqueFd(int descriptor) noexcept : descriptor_(descriptor) {}
  ~UniqueFd() {
    if (descriptor_ >= 0) {
      static_cast<void>(::close(descriptor_));
    }
  }
  UniqueFd(const UniqueFd&) = delete;
  UniqueFd& operator=(const UniqueFd&) = delete;
  UniqueFd(UniqueFd&& other) noexcept
      : descriptor_(std::exchange(other.descriptor_, -1)) {}
  UniqueFd& operator=(UniqueFd&& other) noexcept {
    if (this != &other) {
      if (descriptor_ >= 0) {
        static_cast<void>(::close(descriptor_));
      }
      descriptor_ = std::exchange(other.descriptor_, -1);
    }
    return *this;
  }

  explicit operator bool() const noexcept { return descriptor_ >= 0; }
  int get() const noexcept { return descriptor_; }

 private:
  int descriptor_{-1};
};

Status open_regular_at(int root_descriptor, const fs::path& relative,
                       int rank, Detail open_failure,
                       Detail non_regular_failure, UniqueFd& out,
                       struct stat& metadata) {
  notify_file_open(rank);
  const int descriptor = ::openat(
      root_descriptor, relative.c_str(),
      O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK | O_NOCTTY);
  if (descriptor < 0) {
    return invalid_case(errno == ELOOP ? non_regular_failure : open_failure);
  }
  UniqueFd candidate(descriptor);
  if (::fstat(candidate.get(), &metadata) != 0) {
    return invalid_case(open_failure);
  }
  if (!S_ISREG(metadata.st_mode)) {
    return invalid_case(non_regular_failure);
  }
  out = std::move(candidate);
  return {};
}

Status read_bounded_text(const UniqueFd& file, const struct stat& metadata,
                         std::uint64_t byte_limit, Detail read_failure,
                         Detail too_large, std::string& out) {
  if (metadata.st_size < 0 ||
      static_cast<std::uint64_t>(metadata.st_size) > byte_limit) {
    return invalid_case(too_large);
  }

  std::array<char, 64U * 1024U> buffer{};
  out.clear();
  out.reserve(static_cast<std::size_t>(metadata.st_size));
  std::uint64_t total = 0U;
  for (;;) {
    const ssize_t count = ::read(file.get(), buffer.data(), buffer.size());
    if (count < 0) {
      if (errno == EINTR) {
        continue;
      }
      return invalid_case(read_failure);
    }
    if (count == 0) {
      return {};
    }
    const auto unsigned_count = static_cast<std::uint64_t>(count);
    if (unsigned_count > byte_limit - total) {
      return invalid_case(too_large);
    }
    total += unsigned_count;
    out.append(buffer.data(), static_cast<std::size_t>(count));
  }
}

Status hash_bounded_file(const UniqueFd& file, const struct stat& metadata,
                         Hash64& hash) {
  if (metadata.st_size < 0 ||
      static_cast<std::uint64_t>(metadata.st_size) >
          detail::kMaxReferencedFileBytes) {
    return invalid_case(detail_reference_too_large);
  }

  std::array<char, 64U * 1024U> buffer{};
  std::uint64_t total = 0U;
  for (;;) {
    const ssize_t count = ::read(file.get(), buffer.data(), buffer.size());
    if (count < 0) {
      if (errno == EINTR) {
        continue;
      }
      return invalid_case(detail_reference_missing);
    }
    if (count == 0) {
      hash.integer(total);
      return {};
    }
    const auto unsigned_count = static_cast<std::uint64_t>(count);
    if (unsigned_count > detail::kMaxReferencedFileBytes - total) {
      return invalid_case(detail_reference_too_large);
    }
    total += unsigned_count;
    hash.bytes(buffer.data(), static_cast<std::size_t>(count));
  }
}

bool has_duplicate_keys(yyjson_val* value, std::size_t depth) {
  if (value == nullptr || depth > kMaxJsonDepth) {
    return true;
  }
  if (yyjson_is_obj(value)) {
    std::unordered_set<std::string_view> keys;
    const std::size_t object_size = yyjson_obj_size(value);
    keys.reserve(object_size);
    std::size_t index = 0U;
    std::size_t maximum = 0U;
    yyjson_val* key = nullptr;
    yyjson_val* child = nullptr;
    yyjson_obj_foreach(value, index, maximum, key, child) {
      const char* key_text = yyjson_get_str(key);
      if (key_text == nullptr) {
        return true;
      }
      const std::string_view view{key_text, yyjson_get_len(key)};
      if (!keys.insert(view).second || has_duplicate_keys(child, depth + 1U)) {
        return true;
      }
    }
    return false;
  }
  if (yyjson_is_arr(value)) {
    std::size_t index = 0U;
    std::size_t maximum = 0U;
    yyjson_val* child = nullptr;
    yyjson_arr_foreach(value, index, maximum, child) {
      if (has_duplicate_keys(child, depth + 1U)) {
        return true;
      }
    }
  }
  return false;
}

bool object_has_exact_keys(yyjson_val* object,
                           std::initializer_list<std::string_view> required) {
  if (!yyjson_is_obj(object) || yyjson_obj_size(object) != required.size()) {
    return false;
  }
  for (const std::string_view key : required) {
    if (yyjson_obj_getn(object, key.data(), key.size()) == nullptr) {
      return false;
    }
  }
  return true;
}

bool root_has_case_keys(yyjson_val* root) {
  if (!yyjson_is_obj(root)) {
    return false;
  }
  constexpr std::array<std::string_view, 10U> required{
      "schema_version", "units", "mesh", "flow", "solver", "boundaries",
      "schemes", "time", "transported_scalars", "thermophysics"};
  for (const std::string_view key : required) {
    if (yyjson_obj_getn(root, key.data(), key.size()) == nullptr) {
      return false;
    }
  }
  const bool has_turbulence = yyjson_obj_get(root, "turbulence") != nullptr;
  return yyjson_obj_size(root) ==
         required.size() + (has_turbulence ? 1U : 0U) +
              (yyjson_obj_get(root, "patch_inlets") != nullptr ? 1U : 0U) +
             (yyjson_obj_get(root, "reaction") != nullptr ? 1U : 0U) +
             (yyjson_obj_get(root, "spray") != nullptr ? 1U : 0U);
}

bool parse_immersed_fluid_side(std::string_view value,
                               ImmersedFluidSide& out) noexcept {
  if (value == "outside") {
    out = ImmersedFluidSide::outside;
    return true;
  }
  if (value == "inside") {
    out = ImmersedFluidSide::inside;
    return true;
  }
  return false;
}

bool parse_ibm_reconstruction_policy(
    std::string_view value, IbmReconstructionPolicy& out) noexcept {
  if (value == "strict_quadratic") {
    out = IbmReconstructionPolicy::strict_quadratic;
    return true;
  }
  if (value == "adaptive_order") {
    out = IbmReconstructionPolicy::adaptive_order;
    return true;
  }
  return false;
}

std::optional<std::string_view> string_value(yyjson_val* object,
                                             std::string_view key) {
  yyjson_val* value = yyjson_obj_getn(object, key.data(), key.size());
  if (!yyjson_is_str(value)) {
    return std::nullopt;
  }
  return std::string_view{yyjson_get_str(value), yyjson_get_len(value)};
}

bool equals(std::optional<std::string_view> value,
            std::string_view expected) noexcept {
  return value.has_value() && *value == expected;
}

bool finite_real(yyjson_val* value, double& out) noexcept;
bool parse_real3(yyjson_val* value, Real3& out) noexcept;
bool valid_name(std::string_view value) noexcept;
bool valid_boundary(const BoundaryFaceSpec& face);
bool valid_solver(const SolverSpec& solver) noexcept;
bool valid_schemes(const SchemeSpec& schemes) noexcept;
bool valid_time(const TimeControlSpec& time) noexcept;

// Early input dialects used a vendor namespace before the format name.
bool format_name(std::string_view value, std::string_view name) noexcept {
  if (value==name) return true;
  if (value.size()<=name.size()+1) return false;
  const auto prefix=value.size()-name.size()-1;
  return value[prefix]=='_' && value.substr(prefix+1)==name &&
      std::all_of(value.begin(),value.begin()+prefix,[](unsigned char c) {
        return (c>='a' && c<='z') || (c>='A' && c<='Z');
      });
}

bool parse_geometry(std::string_view value, GeometryKind& out) noexcept {
  if (value == "uniform") {
    out = GeometryKind::uniform;
    return true;
  }
  if (value == "tensor_stretched") {
    out = GeometryKind::tensor_stretched;
    return true;
  }
  if (format_name(value,"runtime_axes_v1")) {
    out = GeometryKind::runtime_axes_v1;
    return true;
  }
  return false;
}

bool parse_turbulence(std::string_view value, TurbulenceKind& out) noexcept {
  if (value == "none") {
    out = TurbulenceKind::none;
    return true;
  }
  if (value == "wale") {
    out = TurbulenceKind::wale;
    return true;
  }
  if (value == "vreman_wall_function") {
    out = TurbulenceKind::vreman_wall_function;
    return true;
  }
  if (value == "smagorinsky") {
    out = TurbulenceKind::smagorinsky;
    return true;
  }
  if (value == "vreman") {
    out = TurbulenceKind::vreman;
    return true;
  }
  return false;
}

bool parse_time_control(std::string_view value,
                        TimeControlKind& out) noexcept {
  if (value == "fixed") {
    out = TimeControlKind::fixed;
    return true;
  }
  if (value == "adaptive_flow") {
    out = TimeControlKind::adaptive_flow;
    return true;
  }
  if (value == "adaptive_acoustic") {
    out = TimeControlKind::adaptive_acoustic;
    return true;
  }
  return false;
}

bool parse_pressure_reference(std::string_view value,
                              PressureReferenceKind& out) noexcept {
  if (value == "boundary_absolute") {
    out = PressureReferenceKind::boundary_absolute;
    return true;
  }
  if (value == "closed_mass") {
    out = PressureReferenceKind::closed_mass;
    return true;
  }
  return false;
}

bool parse_linear_algorithm(std::string_view value,
                            LinearAlgorithm &out) noexcept {
  if (value == "fgmres") {
    out = LinearAlgorithm::fgmres;
  } else if (value == "pcg") {
    out = LinearAlgorithm::pcg;
  } else if (value == "bicgstab") {
    out = LinearAlgorithm::bicgstab;
  } else {
    return false;
  }
  return true;
}

bool parse_boundary_kind(std::string_view value, BoundaryKind& out) noexcept {
  constexpr std::array<std::pair<std::string_view, BoundaryKind>, 17U> values{{
      {"none", BoundaryKind::none},
      {"velocity_inlet", BoundaryKind::velocity_inlet},
      {"mass_flow_inlet", BoundaryKind::mass_flow_inlet},
      {"static_state_inlet", BoundaryKind::static_state_inlet},
      {"total_state_inlet", BoundaryKind::total_state_inlet},
      {"pressure_outlet", BoundaryKind::pressure_outlet},
      {"zero_gradient_mass_outlet", BoundaryKind::zero_gradient_mass_outlet},
      {"nscbc_inlet", BoundaryKind::nscbc_inlet},
      {"nscbc_outlet", BoundaryKind::nscbc_outlet},
      {"no_slip_wall", BoundaryKind::no_slip_wall},
      {"moving_wall", BoundaryKind::moving_wall},
      {"slip", BoundaryKind::slip},
      {"symmetry", BoundaryKind::symmetry},
      {"periodic", BoundaryKind::periodic},
      {"adiabatic_wall", BoundaryKind::adiabatic_wall},
      {"isothermal_wall", BoundaryKind::isothermal_wall},
      {"heat_flux_wall", BoundaryKind::heat_flux_wall},
  }};
  for (const auto& candidate : values) {
    if (candidate.first == value) {
      out = candidate.second;
      return true;
    }
  }
  return false;
}

bool parse_scalar_boundary_kind(std::string_view value,
                                ScalarBoundaryKind& out) noexcept {
  if (value == "dirichlet") {
    out = ScalarBoundaryKind::dirichlet;
  } else if (value == "normal_flux") {
    out = ScalarBoundaryKind::normal_flux;
  } else if (value == "zero_gradient") {
    out = ScalarBoundaryKind::zero_gradient;
  } else if (value == "convective") {
    out = ScalarBoundaryKind::convective;
  } else {
    return false;
  }
  return true;
}

bool parse_transported_scalar_role(std::string_view value,
                                   TransportedScalarRole& out) noexcept {
  if (value == "species") {
    out = TransportedScalarRole::species;
  } else if (value == "passive_scalar") {
    out = TransportedScalarRole::passive_scalar;
  } else {
    return false;
  }
  return true;
}

bool parse_convection(std::string_view value, ConvectionScheme& out) noexcept {
  if (value == "central2") {
    out = ConvectionScheme::central2;
  } else if (value == "limited_central2") {
    out = ConvectionScheme::limited_central2;
  } else if (value == "tvd2") {
    out = ConvectionScheme::tvd2;
  } else {
    return false;
  }
  return true;
}

bool parse_diffusion(std::string_view value, DiffusionScheme& out) noexcept {
  if (value != "central2") {
    return false;
  }
  out = DiffusionScheme::central2;
  return true;
}

bool parse_time_scheme(std::string_view value, TimeScheme& out) noexcept {
  if (value == "backward_euler") {
    out = TimeScheme::backward_euler;
  } else if (value == "variable_bdf2") {
    out = TimeScheme::variable_bdf2;
  } else if (format_name(value,"cn_be")) {
    out = TimeScheme::cn_be;
  } else {
    return false;
  }
  return true;
}

bool parse_uint32(yyjson_val* value, std::uint32_t& out) noexcept {
  if (!yyjson_is_uint(value)) {
    return false;
  }
  const std::uint64_t parsed = yyjson_get_uint(value);
  if (parsed > std::numeric_limits<std::uint32_t>::max()) {
    return false;
  }
  out = static_cast<std::uint32_t>(parsed);
  return true;
}

bool parse_boundary_face(yyjson_val* value, BoundaryFaceSpec& out) {
  if (!object_has_exact_keys(
          value, {"flow_kind", "thermal_kind", "velocity", "direction",
                  "backflow_velocity", "mass_flow_rate", "pressure",
                  "temperature", "total_pressure", "total_temperature",
                  "backflow_temperature", "heat_flux", "relaxation",
                  "mach_limit", "allow_backflow", "scalars"})) {
    return false;
  }
  const auto flow = string_value(value, "flow_kind");
  const auto thermal = string_value(value, "thermal_kind");
  yyjson_val* allow_backflow = yyjson_obj_get(value, "allow_backflow");
  yyjson_val* scalars = yyjson_obj_get(value, "scalars");
  if (!flow || !thermal || !parse_boundary_kind(*flow, out.flow_kind) ||
      !parse_boundary_kind(*thermal, out.thermal_kind) ||
      !parse_real3(yyjson_obj_get(value, "velocity"), out.velocity) ||
      !parse_real3(yyjson_obj_get(value, "direction"), out.direction) ||
      !parse_real3(yyjson_obj_get(value, "backflow_velocity"),
                   out.backflow_velocity) ||
      !finite_real(yyjson_obj_get(value, "mass_flow_rate"),
                   out.mass_flow_rate) ||
      !finite_real(yyjson_obj_get(value, "pressure"), out.pressure) ||
      !finite_real(yyjson_obj_get(value, "temperature"), out.temperature) ||
      !finite_real(yyjson_obj_get(value, "total_pressure"),
                   out.total_pressure) ||
      !finite_real(yyjson_obj_get(value, "total_temperature"),
                   out.total_temperature) ||
      !finite_real(yyjson_obj_get(value, "backflow_temperature"),
                   out.backflow_temperature) ||
      !finite_real(yyjson_obj_get(value, "heat_flux"), out.heat_flux) ||
      !finite_real(yyjson_obj_get(value, "relaxation"), out.relaxation) ||
      !finite_real(yyjson_obj_get(value, "mach_limit"), out.mach_limit) ||
      !yyjson_is_bool(allow_backflow) || !yyjson_is_arr(scalars) ||
      yyjson_arr_size(scalars) > kMaxScalarsPerFace) {
    return false;
  }
  out.allow_backflow = yyjson_get_bool(allow_backflow);
  out.scalars.reserve(yyjson_arr_size(scalars));
  std::size_t index = 0U;
  std::size_t maximum = 0U;
  yyjson_val* scalar_value = nullptr;
  yyjson_arr_foreach(scalars, index, maximum, scalar_value) {
    if (!object_has_exact_keys(
            scalar_value,
            {"stable_name", "kind", "value", "backflow_kind",
             "backflow_value"})) {
      return false;
    }
    const auto name = string_value(scalar_value, "stable_name");
    const auto kind = string_value(scalar_value, "kind");
    const auto backflow_kind = string_value(scalar_value, "backflow_kind");
    ScalarBoundarySpec scalar;
    if (!name || !kind || !backflow_kind || !valid_name(*name) ||
        !parse_scalar_boundary_kind(*kind, scalar.kind) ||
        !finite_real(yyjson_obj_get(scalar_value, "value"), scalar.value) ||
        !parse_scalar_boundary_kind(*backflow_kind, scalar.backflow_kind) ||
        !finite_real(yyjson_obj_get(scalar_value, "backflow_value"),
                     scalar.backflow_value)) {
      return false;
    }
    scalar.stable_name.assign(name->data(), name->size());
    out.scalars.push_back(std::move(scalar));
  }
  return valid_boundary(out);
}

bool parse_solver_controls(yyjson_val* value, SolverSpec& out) noexcept {
  yyjson_val* pressure = yyjson_obj_get(value, "pressure_linear");
  yyjson_val* terminal = yyjson_obj_get(value, "terminal_tolerances");
  const bool has_algorithm = yyjson_obj_get(pressure, "algorithm") != nullptr;
  const bool pressure_keys =
      yyjson_is_obj(pressure) &&
      yyjson_obj_size(pressure) == 5U + (has_algorithm ? 1U : 0U) &&
      yyjson_obj_get(pressure, "absolute_tolerance") != nullptr &&
      yyjson_obj_get(pressure, "relative_tolerance") != nullptr &&
      yyjson_obj_get(pressure, "maximum_iterations") != nullptr &&
      yyjson_obj_get(pressure, "true_residual_interval") != nullptr &&
      yyjson_obj_get(pressure, "krylov_restart") != nullptr &&
      (!has_algorithm || yyjson_is_str(yyjson_obj_get(pressure, "algorithm")));
  if (!pressure_keys ||
      !object_has_exact_keys(terminal,
                             {"eos", "continuity", "closed_mass", "gauge"})) {
    return false;
  }
  if (auto* outer = yyjson_obj_get(value, "reference_outer_iterations")) {
    if (!yyjson_is_uint(outer) || yyjson_get_uint(outer) > 64U) return false;
    out.reference_outer_iterations = static_cast<std::uint32_t>(yyjson_get_uint(outer));
  }
  if (auto* stopping = yyjson_obj_get(value, "cold_stopping")) {
    out.cold_stopping.emplace();
    auto& spec = *out.cold_stopping;
    if (!object_has_exact_keys(stopping,
          {"reference_time", "momentum", "enthalpy", "species"}) ||
        !finite_real(yyjson_obj_get(stopping, "reference_time"), spec.reference_time) ||
        !finite_real(yyjson_obj_get(stopping, "momentum"), spec.momentum) ||
        !finite_real(yyjson_obj_get(stopping, "enthalpy"), spec.enthalpy) ||
        !finite_real(yyjson_obj_get(stopping, "species"), spec.species) || !spec.valid())
      return false;
  }
  const auto algorithm = string_value(pressure, "algorithm");
  if (has_algorithm &&
      (!algorithm.has_value() ||
       !parse_linear_algorithm(*algorithm, out.pressure.algorithm))) {
    return false;
  }
  out.pressure.mg_correction_scaling =
      out.pressure.algorithm != LinearAlgorithm::fgmres
          ? MgCorrectionScaling::unit_linear
          : MgCorrectionScaling::residual_minimizing;
  return finite_real(yyjson_obj_get(pressure, "absolute_tolerance"),
                     out.pressure.absolute_tolerance) &&
         finite_real(yyjson_obj_get(pressure, "relative_tolerance"),
                     out.pressure.relative_tolerance) &&
         parse_uint32(yyjson_obj_get(pressure, "maximum_iterations"),
                      out.pressure.maximum_iterations) &&
         parse_uint32(yyjson_obj_get(pressure, "true_residual_interval"),
                      out.pressure.true_residual_interval) &&
         parse_uint32(yyjson_obj_get(pressure, "krylov_restart"),
                      out.pressure.krylov_restart) &&
         finite_real(yyjson_obj_get(terminal, "eos"), out.terminal.eos) &&
         finite_real(yyjson_obj_get(terminal, "continuity"),
                     out.terminal.continuity) &&
         finite_real(yyjson_obj_get(terminal, "closed_mass"),
                     out.terminal.closed_mass) &&
         finite_real(yyjson_obj_get(terminal, "gauge"),
                     out.terminal.gauge) &&
         valid_solver(out);
}

bool parse_schemes_object(yyjson_val* value, SchemeSpec& out) noexcept {
  if (!object_has_exact_keys(
          value, {"momentum", "enthalpy", "species", "passive_scalar",
                  "diffusion", "limiter"})) {
    return false;
  }
  const auto momentum = string_value(value, "momentum");
  const auto enthalpy = string_value(value, "enthalpy");
  const auto species = string_value(value, "species");
  const auto passive = string_value(value, "passive_scalar");
  const auto diffusion = string_value(value, "diffusion");
  return momentum && enthalpy && species && passive && diffusion &&
         parse_convection(*momentum, out.momentum) &&
         parse_convection(*enthalpy, out.enthalpy) &&
         parse_convection(*species, out.species) &&
         parse_convection(*passive, out.passive_scalar) &&
         parse_diffusion(*diffusion, out.diffusion) &&
         finite_real(yyjson_obj_get(value, "limiter"), out.limiter) &&
         valid_schemes(out);
}

bool parse_time_object(yyjson_val* value, TimeControlSpec& out) noexcept {
  if (!yyjson_is_obj(value)) return false;
  const std::set<std::string_view> required{
      "control", "scheme", "initial_dt", "minimum_dt", "maximum_dt",
      "convective_cfl", "viscous_cfl", "thermal_cfl", "species_cfl", "acoustic_cfl",
      "maximum_growth", "retry_factor", "maximum_retries", "minimum_bdf_ratio", "maximum_bdf_ratio"};
  std::set<std::string_view> seen;
  std::size_t index, count; yyjson_val *key, *entry;
  yyjson_obj_foreach(value,index,count,key,entry) {
    const std::string_view name{yyjson_get_str(key),yyjson_get_len(key)};
    if (!seen.insert(name).second ||
        (!required.count(name) && name != "convective_cfl_margin" &&
         name != "convective_cfl_definition")) return false;
  }
  for (auto name : required) if (!seen.count(name)) return false;
  out.convective_cfl_margin = 0.0;
  if (auto* band = yyjson_obj_get(value,"convective_cfl_margin"))
    if (!finite_real(band,out.convective_cfl_margin)) return false;
  out.convective_cfl_definition = ConvectiveCflDefinition::outgoing_sum;
  if (yyjson_obj_get(value,"convective_cfl_definition")) {
    const auto definition=string_value(value,"convective_cfl_definition");
    if (definition == "directional_max")
      out.convective_cfl_definition=ConvectiveCflDefinition::directional_max;
    else if (definition != "outgoing_sum") return false;
  }
  const auto control = string_value(value, "control");
  const auto scheme = string_value(value, "scheme");
  return control && scheme && parse_time_control(*control, out.control) &&
         parse_time_scheme(*scheme, out.scheme) &&
         finite_real(yyjson_obj_get(value, "initial_dt"), out.initial_dt) &&
         finite_real(yyjson_obj_get(value, "minimum_dt"), out.minimum_dt) &&
         finite_real(yyjson_obj_get(value, "maximum_dt"), out.maximum_dt) &&
         finite_real(yyjson_obj_get(value, "convective_cfl"),
                     out.convective_cfl) &&
         finite_real(yyjson_obj_get(value, "viscous_cfl"), out.viscous_cfl) &&
         finite_real(yyjson_obj_get(value, "thermal_cfl"), out.thermal_cfl) &&
         finite_real(yyjson_obj_get(value, "species_cfl"), out.species_cfl) &&
         finite_real(yyjson_obj_get(value, "acoustic_cfl"), out.acoustic_cfl) &&
         finite_real(yyjson_obj_get(value, "maximum_growth"),
                     out.maximum_growth) &&
         finite_real(yyjson_obj_get(value, "retry_factor"), out.retry_factor) &&
         parse_uint32(yyjson_obj_get(value, "maximum_retries"),
                      out.maximum_retries) &&
         finite_real(yyjson_obj_get(value, "minimum_bdf_ratio"),
                     out.minimum_bdf_ratio) &&
         finite_real(yyjson_obj_get(value, "maximum_bdf_ratio"),
                     out.maximum_bdf_ratio) &&
         valid_time(out);
}

bool parse_esf(yyjson_val* value, EsfSpec& out) {
  if (!object_has_exact_keys(value, {"fields", "seed", "initial_species_offsets", "tcr"}) ||
      !parse_uint32(yyjson_obj_get(value, "fields"), out.fields)) return false;
  auto* seed = yyjson_obj_get(value, "seed");
  auto* offsets = yyjson_obj_get(value, "initial_species_offsets");
  if (!yyjson_is_uint(seed) || !yyjson_is_arr(offsets) || yyjson_arr_size(offsets) > 1024) return false;
  out.seed = yyjson_get_uint(seed);
  for (std::size_t i = 0; i < yyjson_arr_size(offsets); ++i) {
    double v{};
    if (!finite_real(yyjson_arr_get(offsets, i), v)) return false;
    out.initial_species_offsets.push_back(v);
  }
  auto* tcr = yyjson_obj_get(value, "tcr");
  const auto mode = string_value(tcr, "mode");
  if (!mode) return false;
  if (*mode == "off") return object_has_exact_keys(tcr, {"mode"}) && detail::valid_esf_spec(out);
  if (*mode == "shadow") out.tcr.mode = TcrMode::shadow;
  else if (*mode == "experimental") out.tcr.mode = TcrMode::experimental;
  else if (*mode == "validated") out.tcr.mode = TcrMode::validated;
  else return false;
  if (yyjson_obj_get(tcr, "model")) {
    const auto model = string_value(tcr, "model"), fuel = string_value(tcr, "fuel");
    const bool dyn711=model=="dyn711_v1";
    if (!(dyn711 ? object_has_exact_keys(tcr, {"mode", "model", "fuel", "weak_rate_threshold", "mixture_fraction", "oxidizer_oxygen_mass_fraction"})
                  : object_has_exact_keys(tcr, {"mode", "model", "fuel", "weak_rate_threshold"}))) return false;
    if ((!dyn711 && model != "cdphyso_dynamic_v1") || !fuel ||
        !finite_real(yyjson_obj_get(tcr, "weak_rate_threshold"), out.tcr.weak_rate_threshold)) return false;
    out.tcr.model = dyn711 ? TcrModel::dyn711_v1 : TcrModel::cdphyso_dynamic_v1;
    out.tcr.fuel = std::string(*fuel);
    if(dyn711) {
      const auto mixture=string_value(tcr,"mixture_fraction");
      if(!mixture || !finite_real(yyjson_obj_get(tcr,"oxidizer_oxygen_mass_fraction"),
          out.tcr.oxidizer_oxygen_mass_fraction))return false;
      out.tcr.mixture_fraction=std::string(*mixture);
    }
    return detail::valid_esf_spec(out);
  }
  if (!object_has_exact_keys(tcr, {"mode", "reactants", "progress_weights", "initialization_sign", "weak_rate_threshold"})) return false;
  auto* reactants = yyjson_obj_get(tcr, "reactants");
  auto* weights = yyjson_obj_get(tcr, "progress_weights");
  if (!yyjson_is_arr(reactants) || yyjson_arr_size(reactants) > 255 ||
      !yyjson_is_arr(weights) || yyjson_arr_size(weights) > 255) return false;
  for (std::size_t i = 0; i < yyjson_arr_size(reactants); ++i) {
    auto* name = yyjson_arr_get(reactants, i);
    if (!yyjson_is_str(name)) return false;
    out.tcr.reactants.emplace_back(yyjson_get_str(name), yyjson_get_len(name));
  }
  for (std::size_t i = 0; i < yyjson_arr_size(weights); ++i) {
    double v{};
    if (!finite_real(yyjson_arr_get(weights, i), v)) return false;
    out.tcr.progress_weights.push_back(v);
  }
  double sign{};
  if (!finite_real(yyjson_obj_get(tcr, "initialization_sign"), sign) ||
      sign < -1 || sign > 1 || std::trunc(sign) != sign ||
      !finite_real(yyjson_obj_get(tcr, "weak_rate_threshold"), out.tcr.weak_rate_threshold)) return false;
  out.tcr.initialization_sign = int(sign);
  return detail::valid_esf_spec(out);
}

bool parse_spray(yyjson_val *value, SpraySpec &s) {
  const bool named_breakup = yyjson_obj_get(value, "breakup") != nullptr;
  const char *breakup_key = named_breakup ? "breakup" : "tab_breakup";
  if (!object_has_exact_keys(
          value,
          {"liquid_file", "liquid_fingerprint", "seed", "maximum_local_parcels",
           "maximum_local_segments", "maximum_substep_s", "minimum_substep_s",
           "relative_tolerance", breakup_key, "injectors"}) &&
      !object_has_exact_keys(value,
          {"liquid_file", "liquid_fingerprint", "seed", "maximum_local_parcels",
           "maximum_local_segments", "maximum_substep_s", "minimum_substep_s",
           "relative_tolerance", breakup_key, "injectors", "evaporation"}))
    return false;
  if (yyjson_obj_get(value, "evaporation")) {
    const auto name = string_value(value, "evaporation");
    if (!name) return false;
    if (*name == "thick_exchange") s.evaporation = spray::EvaporationModel::thick_exchange;
    else if (*name == "abramzon_sirignano")
      s.evaporation = spray::EvaporationModel::abramzon_sirignano;
    else return false;
  }
  const auto file = string_value(value, "liquid_file");
  auto *identity = yyjson_obj_get(value, "liquid_fingerprint");
  auto *seed = yyjson_obj_get(value, "seed");
  auto *tab = yyjson_obj_get(value, breakup_key);
  auto *injectors = yyjson_obj_get(value, "injectors");
  if (!file || !yyjson_is_uint(identity) || !yyjson_is_uint(seed) ||
      (named_breakup ? !yyjson_is_str(tab) : !yyjson_is_bool(tab)) ||
      !yyjson_is_arr(injectors) ||
      yyjson_arr_size(injectors) > 64 ||
      !parse_uint32(yyjson_obj_get(value, "maximum_local_parcels"),
                    s.maximum_local_parcels) ||
      !parse_uint32(yyjson_obj_get(value, "maximum_local_segments"),
                    s.maximum_local_segments) ||
      !finite_real(yyjson_obj_get(value, "maximum_substep_s"),
                   s.maximum_substep_s) ||
      !finite_real(yyjson_obj_get(value, "minimum_substep_s"),
                   s.minimum_substep_s) ||
      !finite_real(yyjson_obj_get(value, "relative_tolerance"),
                   s.relative_tolerance))
    return false;
  s.liquid_file = std::string(*file);
  s.liquid_fingerprint = yyjson_get_uint(identity);
  s.seed = yyjson_get_uint(seed);
  if (named_breakup) {
    const auto name = string_value(value, breakup_key);
    if (name == "none") s.breakup = SprayBreakupModel::none;
    else if (name == "tab") s.breakup = SprayBreakupModel::tab;
    else if (name == "stochastic_sgs") s.breakup = SprayBreakupModel::stochastic_sgs;
    else return false;
  } else {
    s.breakup = yyjson_get_bool(tab) ? SprayBreakupModel::tab : SprayBreakupModel::none;
  }
  for (std::size_t i = 0; i < yyjson_arr_size(injectors); ++i) {
    auto *item = yyjson_arr_get(injectors, i);
    if (!object_has_exact_keys(item,
                               {"id", "origin_m", "axis", "cone_half_angle_rad",
                                "speed_m_per_s", "mass_flow_rate_kg_per_s",
                                "represented_mass_per_parcel_kg",
                                "droplet_diameter_m", "temperature_k"}))
      return false;
    auto *id = yyjson_obj_get(item, "id");
    SprayInjectionSpec v;
    if (!yyjson_is_uint(id) ||
        !parse_real3(yyjson_obj_get(item, "origin_m"), v.origin_m) ||
        !parse_real3(yyjson_obj_get(item, "axis"), v.axis) ||
        !finite_real(yyjson_obj_get(item, "cone_half_angle_rad"),
                     v.cone_half_angle_rad) ||
        !finite_real(yyjson_obj_get(item, "speed_m_per_s"), v.speed_m_per_s) ||
        !finite_real(yyjson_obj_get(item, "mass_flow_rate_kg_per_s"),
                     v.mass_flow_rate_kg_per_s) ||
        !finite_real(yyjson_obj_get(item, "represented_mass_per_parcel_kg"),
                     v.represented_mass_per_parcel_kg) ||
        !finite_real(yyjson_obj_get(item, "droplet_diameter_m"),
                     v.droplet_diameter_m) ||
        !finite_real(yyjson_obj_get(item, "temperature_k"), v.temperature_k))
      return false;
    v.id = yyjson_get_uint(id);
    s.injectors.push_back(v);
  }
  return detail::valid_spray_spec(s);
}

bool parse_reaction(yyjson_val* value, ReactionSpec& out) {
  const auto model = string_value(value, "model");
  const auto representation = string_value(value, "representation");
  const auto sha = string_value(value, "mechanism_sha256");
  const auto phase = string_value(value, "phase");
  if (!model || !representation || !sha || !phase) return false;
  if (*model == "finite_rate_mean") out.mode = ReactionMode::finite_rate_mean;
  else if (*model == "pasr_algebraic_v1") out.mode = ReactionMode::pasr_algebraic_v1;
  else if (*model == "esf_tpdf") out.mode = ReactionMode::esf_tpdf;
  else return false;
  out.mechanism_sha256.assign(sha->data(), sha->size());
  out.phase.assign(phase->data(), phase->size());
  const bool pasr = out.mode == ReactionMode::pasr_algebraic_v1;
  const bool esf = out.mode == ReactionMode::esf_tpdf;
  const std::size_t keys = esf ? 8U : pasr ? 7U : 6U;
  if (*representation == "analytic_isomer") {
    out.representation = ReactionSpec::Representation::analytic_isomer;
    if (yyjson_obj_size(value) != keys ||
        !finite_real(yyjson_obj_get(value, "rate_s"), out.analytic_rate_s) ||
        !finite_real(yyjson_obj_get(value, "cp_j_per_kg_k"), out.analytic_cp_j_per_kg_k)) return false;
  } else if (*representation == "direct_cantera") {
    out.representation = ReactionSpec::Representation::direct_cantera;
    const auto file = string_value(value, "mechanism_file");
    auto* solver = yyjson_obj_get(value, "chemistry_solver");
    if (yyjson_obj_size(value) != keys || !file ||
        !object_has_exact_keys(solver, {"relative_tolerance", "absolute_tolerance", "maximum_internal_steps"}) ||
        !finite_real(yyjson_obj_get(solver, "relative_tolerance"), out.relative_tolerance) ||
        !finite_real(yyjson_obj_get(solver, "absolute_tolerance"), out.absolute_tolerance) ||
        !parse_uint32(yyjson_obj_get(solver, "maximum_internal_steps"), out.maximum_internal_steps)) return false;
    out.mechanism_file = std::string(*file);
  } else return false;
  if (pasr || esf) {
    auto* mixing = yyjson_obj_get(value, "mixing");
    if (!object_has_exact_keys(mixing, {"c_z", "turbulent_schmidt"}) ||
        !finite_real(yyjson_obj_get(mixing, "c_z"), out.mixing_c_z) ||
        !finite_real(yyjson_obj_get(mixing, "turbulent_schmidt"), out.turbulent_schmidt)) return false;
  }
  if (esf) {
    out.esf.emplace();
    if (!parse_esf(yyjson_obj_get(value, "ensemble"), *out.esf)) return false;
  }
  return detail::valid_reaction_spec(out);
}

bool finite_real(yyjson_val* value, double& out) noexcept {
  if (!yyjson_is_num(value)) {
    return false;
  }
  out = yyjson_get_num(value);
  if (!std::isfinite(out)) {
    return false;
  }
  if (out == 0.0) {
    out = 0.0;
  }
  return true;
}

bool parse_real3(yyjson_val* value, Real3& out) noexcept {
  if (!yyjson_is_arr(value) || yyjson_arr_size(value) != 3U) {
    return false;
  }
  return finite_real(yyjson_arr_get(value, 0U), out.x) &&
         finite_real(yyjson_arr_get(value, 1U), out.y) &&
         finite_real(yyjson_arr_get(value, 2U), out.z);
}

bool parse_positive_real3(yyjson_val* value, Real3& out) noexcept {
  return parse_real3(value, out) && out.x > 0.0 && out.y > 0.0 && out.z > 0.0;
}

bool parse_optional_positive_real3(yyjson_val* value, bool& present,
                                   Real3& out) noexcept {
  if (yyjson_is_null(value)) {
    present = false;
    out = {};
    return true;
  }
  present = true;
  return parse_positive_real3(value, out);
}

bool parse_optional_cells(yyjson_val* value, bool& present,
                          Int3& out) noexcept {
  if (yyjson_is_null(value)) {
    present = false;
    out = {};
    return true;
  }
  if (!yyjson_is_arr(value) || yyjson_arr_size(value) != 3U) {
    return false;
  }
  const auto parse_component = [](yyjson_val* component,
                                  std::int32_t& parsed) noexcept {
    if (!yyjson_is_uint(component)) {
      return false;
    }
    const std::uint64_t value = yyjson_get_uint(component);
    if (value == 0U ||
        value > static_cast<std::uint64_t>(std::numeric_limits<std::int32_t>::max())) {
      return false;
    }
    parsed = static_cast<std::int32_t>(value);
    return true;
  };
  present = true;
  return parse_component(yyjson_arr_get(value, 0U), out.x) &&
         parse_component(yyjson_arr_get(value, 1U), out.y) &&
         parse_component(yyjson_arr_get(value, 2U), out.z);
}

bool ordered_domain(const Real3& lower, const Real3& upper) noexcept {
  return lower.x < upper.x && lower.y < upper.y && lower.z < upper.z &&
         std::isfinite(upper.x - lower.x) &&
         std::isfinite(upper.y - lower.y) &&
         std::isfinite(upper.z - lower.z);
}

bool componentwise_at_least(const Real3& value,
                            const Real3& minimum) noexcept {
  return value.x >= minimum.x && value.y >= minimum.y &&
         value.z >= minimum.z;
}

bool componentwise_at_most(const Real3& value,
                           const Real3& maximum) noexcept {
  return value.x <= maximum.x && value.y <= maximum.y &&
         value.z <= maximum.z;
}

bool same_real3(const Real3& left, const Real3& right) noexcept {
  return left.x == right.x && left.y == right.y && left.z == right.z;
}

bool focus_less(const FocusRegionSpec& left,
                const FocusRegionSpec& right) noexcept {
  const std::array<double, 9U> lhs{left.lower.x, left.lower.y, left.lower.z,
                                  left.upper.x, left.upper.y, left.upper.z,
                                  left.target_spacing.x,
                                  left.target_spacing.y,
                                  left.target_spacing.z};
  const std::array<double, 9U> rhs{right.lower.x, right.lower.y, right.lower.z,
                                  right.upper.x, right.upper.y, right.upper.z,
                                  right.target_spacing.x,
                                  right.target_spacing.y,
                                  right.target_spacing.z};
  return std::lexicographical_compare(lhs.begin(), lhs.end(), rhs.begin(),
                                      rhs.end());
}

bool same_focus(const FocusRegionSpec& left,
                const FocusRegionSpec& right) noexcept {
  return same_real3(left.lower, right.lower) &&
         same_real3(left.upper, right.upper) &&
         same_real3(left.target_spacing, right.target_spacing);
}

void hash_real3(Hash64& hash, const Real3& value) noexcept {
  hash.real(value.x);
  hash.real(value.y);
  hash.real(value.z);
}

bool exact_cell_count_within_limit(const CartesianMeshSpec& mesh) noexcept {
  if (!mesh.has_exact_cells) {
    return true;
  }
  if (mesh.exact_cells.x <= 0 || mesh.exact_cells.y <= 0 ||
      mesh.exact_cells.z <= 0) {
    return false;
  }
  const auto x = static_cast<std::uint64_t>(mesh.exact_cells.x);
  const auto y = static_cast<std::uint64_t>(mesh.exact_cells.y);
  const auto z = static_cast<std::uint64_t>(mesh.exact_cells.z);
  if (x == 0U || y == 0U || z == 0U ||
      x > std::numeric_limits<std::uint64_t>::max() / y) {
    return false;
  }
  const std::uint64_t xy = x * y;
  return xy <= std::numeric_limits<std::uint64_t>::max() / z &&
         xy * z <= mesh.limits.max_global_cells;
}

bool valid_canonical_mesh(const CartesianMeshSpec& mesh) noexcept {
  if (!ordered_domain(mesh.lower, mesh.upper) ||
      mesh.minimum_spacing.x <= 0.0 || mesh.minimum_spacing.y <= 0.0 ||
      mesh.minimum_spacing.z <= 0.0 ||
      !std::isfinite(mesh.max_growth_ratio) ||
      mesh.max_growth_ratio < 1.0 || mesh.limits.max_global_cells == 0U ||
      mesh.limits.max_memory_bytes_per_rank == 0U ||
      !exact_cell_count_within_limit(mesh) ||
      mesh.focus_regions.size() > detail::kMaxFocusRegions) {
    return false;
  }
  if (mesh.kind == GeometryKind::uniform) {
    if (!mesh.axes_file.empty() ||
        std::any_of(mesh.runtime_faces.begin(),
                    mesh.runtime_faces.end(),
                    [](const auto& axis) { return !axis.empty(); }) ||
        !mesh.has_exact_cells || mesh.has_base_spacing ||
        !mesh.focus_regions.empty() || mesh.max_growth_ratio != 1.0) {
      return false;
    }
    const Real3 widths{
        (mesh.upper.x - mesh.lower.x) /
            static_cast<double>(mesh.exact_cells.x),
        (mesh.upper.y - mesh.lower.y) /
            static_cast<double>(mesh.exact_cells.y),
        (mesh.upper.z - mesh.lower.z) /
            static_cast<double>(mesh.exact_cells.z)};
    return std::isfinite(widths.x) && std::isfinite(widths.y) &&
           std::isfinite(widths.z) &&
           componentwise_at_most(mesh.minimum_spacing, widths);
  }
  if ((mesh.kind != GeometryKind::tensor_stretched &&
       mesh.kind != GeometryKind::runtime_axes_v1) ||
      !mesh.has_base_spacing ||
      !componentwise_at_least(mesh.base_spacing, mesh.minimum_spacing)) {
    return false;
  }
  for (const FocusRegionSpec& focus : mesh.focus_regions) {
    if (!ordered_domain(focus.lower, focus.upper) ||
        !componentwise_at_least(focus.lower, mesh.lower) ||
        !componentwise_at_most(focus.upper, mesh.upper) ||
        focus.target_spacing.x <= 0.0 || focus.target_spacing.y <= 0.0 ||
        focus.target_spacing.z <= 0.0 ||
        !componentwise_at_least(focus.target_spacing,
                                mesh.minimum_spacing) ||
        !componentwise_at_most(focus.target_spacing, mesh.base_spacing)) {
      return false;
    }
  }
  if (!std::is_sorted(mesh.focus_regions.begin(), mesh.focus_regions.end(),
                      focus_less) ||
      std::adjacent_find(mesh.focus_regions.begin(),
                         mesh.focus_regions.end(), same_focus) !=
          mesh.focus_regions.end()) {
    return false;
  }
  if (mesh.kind == GeometryKind::tensor_stretched) {
    return mesh.axes_file.empty() &&
           std::all_of(mesh.runtime_faces.begin(),
                       mesh.runtime_faces.end(),
                       [](const auto& axis) { return axis.empty(); });
  }
  if (mesh.axes_file.empty() || !mesh.has_exact_cells) {
    return false;
  }
  const std::array<std::int32_t, 3U> cells{
      mesh.exact_cells.x, mesh.exact_cells.y, mesh.exact_cells.z};
  const std::array<double, 3U> lower{mesh.lower.x, mesh.lower.y, mesh.lower.z};
  const std::array<double, 3U> upper{mesh.upper.x, mesh.upper.y, mesh.upper.z};
  std::uint64_t face_count = 0U;
  for (std::size_t axis = 0U; axis < mesh.runtime_faces.size(); ++axis) {
    const auto& faces = mesh.runtime_faces[axis];
    if (cells[axis] <= 0 ||
        faces.size() != static_cast<std::size_t>(cells[axis]) + 1U ||
        faces.front() != lower[axis] || faces.back() != upper[axis] ||
        faces.size() > std::numeric_limits<std::uint64_t>::max() - face_count) {
      return false;
    }
    face_count += static_cast<std::uint64_t>(faces.size());
    double previous = 0.0;
    for (std::size_t index = 0U; index < faces.size(); ++index) {
      const double coordinate = faces[index];
      if (!std::isfinite(coordinate) ||
          coordinate != static_cast<double>(static_cast<float>(coordinate)) ||
          (index != 0U && !(previous < coordinate))) {
        return false;
      }
      previous = coordinate;
    }
  }
  return face_count <= mesh.limits.max_memory_bytes_per_rank / sizeof(double);
}

void hash_mesh(Hash64& hash, const CartesianMeshSpec& mesh) noexcept {
  hash.integer(static_cast<std::uint8_t>(mesh.kind));
  hash_real3(hash, mesh.lower);
  hash_real3(hash, mesh.upper);
  hash.integer(static_cast<std::uint8_t>(mesh.has_exact_cells ? 1U : 0U));
  if (mesh.has_exact_cells) {
    hash.integer(mesh.exact_cells.x);
    hash.integer(mesh.exact_cells.y);
    hash.integer(mesh.exact_cells.z);
  }
  hash.integer(static_cast<std::uint8_t>(mesh.has_base_spacing ? 1U : 0U));
  if (mesh.has_base_spacing) {
    hash_real3(hash, mesh.base_spacing);
  }
  hash_real3(hash, mesh.minimum_spacing);
  hash.real(mesh.max_growth_ratio);
  hash.integer(static_cast<std::uint16_t>(mesh.focus_regions.size()));
  for (const FocusRegionSpec& focus : mesh.focus_regions) {
    hash_real3(hash, focus.lower);
    hash_real3(hash, focus.upper);
    hash_real3(hash, focus.target_spacing);
  }
  hash.integer(mesh.limits.max_global_cells);
  hash.integer(mesh.limits.max_memory_bytes_per_rank);
  if (mesh.kind == GeometryKind::runtime_axes_v1) {
    hash.text(mesh.axes_file.generic_string());
    for (const auto& axis : mesh.runtime_faces) {
      hash.integer(static_cast<std::uint64_t>(axis.size()));
      for (const double coordinate : axis) {
        hash.real(coordinate);
      }
    }
  }
}

bool valid_name(std::string_view value) noexcept {
  if (value.empty() || value.size() > kMaxStableNameBytes) {
    return false;
  }
  for (const unsigned char character : value) {
    if (!(std::isalnum(character) != 0 || character == '_' ||
          character == '-')) {
      return false;
    }
  }
  return true;
}

bool valid_boundary(const BoundaryFaceSpec& face) {
  const auto finite3 = [](Real3 value) noexcept {
    return std::isfinite(value.x) && std::isfinite(value.y) &&
           std::isfinite(value.z);
  };
  if (static_cast<std::uint8_t>(face.flow_kind) >
          static_cast<std::uint8_t>(BoundaryKind::zero_gradient_mass_outlet) ||
      static_cast<std::uint8_t>(face.thermal_kind) >
          static_cast<std::uint8_t>(BoundaryKind::heat_flux_wall) ||
      !finite3(face.velocity) || !finite3(face.direction) ||
      !finite3(face.backflow_velocity) ||
      !std::isfinite(face.mass_flow_rate) || !std::isfinite(face.pressure) ||
      !std::isfinite(face.temperature) ||
      !std::isfinite(face.total_pressure) ||
      !std::isfinite(face.total_temperature) ||
      !std::isfinite(face.backflow_temperature) ||
      !std::isfinite(face.heat_flux) || !std::isfinite(face.relaxation) ||
      !std::isfinite(face.mach_limit) || face.relaxation < 0.0 ||
      face.mach_limit <= 0.0 || face.mach_limit >= 1.0 ||
      face.scalars.size() > kMaxScalarsPerFace) {
    return false;
  }
  std::unordered_set<std::string_view> names;
  names.reserve(face.scalars.size());
  for (const ScalarBoundarySpec& scalar : face.scalars) {
    if (!valid_name(scalar.stable_name) || !std::isfinite(scalar.value) ||
        !std::isfinite(scalar.backflow_value) ||
        static_cast<std::uint8_t>(scalar.kind) >
            static_cast<std::uint8_t>(ScalarBoundaryKind::convective) ||
        static_cast<std::uint8_t>(scalar.backflow_kind) >
            static_cast<std::uint8_t>(ScalarBoundaryKind::convective) ||
        !names.insert(scalar.stable_name).second) {
      return false;
    }
  }
  return true;
}

bool valid_transported_scalars(
    const std::vector<TransportedScalarSpec>& scalars) {
  if (scalars.size() > kMaxTransportedScalars) {
    return false;
  }
  std::unordered_set<std::string_view> names;
  names.reserve(scalars.size());
  for (const TransportedScalarSpec& scalar : scalars) {
    if (!valid_name(scalar.stable_name) || scalar.stable_name == "U" ||
        scalar.stable_name == "pi" || scalar.stable_name == "h" ||
        static_cast<std::uint8_t>(scalar.role) >
            static_cast<std::uint8_t>(
                TransportedScalarRole::passive_scalar) ||
        !std::isfinite(scalar.molecular_schmidt) ||
        !(scalar.molecular_schmidt > 0.0) ||
        !std::isfinite(scalar.turbulent_schmidt) ||
        !(scalar.turbulent_schmidt > 0.0) ||
        !names.insert(scalar.stable_name).second) {
      return false;
    }
  }
  return true;
}

void hash_transported_scalars(
    Hash64& hash,
    const std::vector<TransportedScalarSpec>& scalars) noexcept {
  hash.integer(static_cast<std::uint16_t>(scalars.size()));
  for (const TransportedScalarSpec& scalar : scalars) {
    hash.text(scalar.stable_name);
    hash.integer(static_cast<std::uint8_t>(scalar.role));
    hash.real(scalar.molecular_schmidt);
    hash.real(scalar.turbulent_schmidt);
  }
}

bool valid_schemes(const SchemeSpec& schemes) noexcept {
  return static_cast<std::uint8_t>(schemes.momentum) <=
             static_cast<std::uint8_t>(ConvectionScheme::tvd2) &&
         static_cast<std::uint8_t>(schemes.enthalpy) <=
             static_cast<std::uint8_t>(ConvectionScheme::tvd2) &&
         static_cast<std::uint8_t>(schemes.species) <=
             static_cast<std::uint8_t>(ConvectionScheme::tvd2) &&
         static_cast<std::uint8_t>(schemes.passive_scalar) <=
             static_cast<std::uint8_t>(ConvectionScheme::tvd2) &&
         schemes.diffusion == DiffusionScheme::central2 &&
         std::isfinite(schemes.limiter) && schemes.limiter >= 0.0 &&
         schemes.limiter <= 1.0;
}

bool valid_solver(const SolverSpec& solver) noexcept {
  const PressureLinearSolverSpec& pressure = solver.pressure;
  const SolverToleranceSpec& terminal = solver.terminal;
  const bool finite = std::isfinite(pressure.absolute_tolerance) &&
                      std::isfinite(pressure.relative_tolerance) &&
                      std::isfinite(terminal.eos) &&
                      std::isfinite(terminal.continuity) &&
                      std::isfinite(terminal.closed_mass) &&
                      std::isfinite(terminal.gauge);
  const bool valid_algorithm = pressure.algorithm == LinearAlgorithm::fgmres ||
                               pressure.algorithm == LinearAlgorithm::bicgstab ||
                               pressure.algorithm == LinearAlgorithm::pcg;
  const bool valid_scaling =
      pressure.mg_correction_scaling ==
          MgCorrectionScaling::residual_minimizing ||
      pressure.mg_correction_scaling == MgCorrectionScaling::unit_linear;
  const bool valid_pair =
      (pressure.algorithm == LinearAlgorithm::fgmres &&
       pressure.mg_correction_scaling ==
           MgCorrectionScaling::residual_minimizing) ||
      ((pressure.algorithm == LinearAlgorithm::bicgstab || pressure.algorithm == LinearAlgorithm::pcg) &&
       pressure.mg_correction_scaling == MgCorrectionScaling::unit_linear);
  const bool valid_restart =
      pressure.algorithm == LinearAlgorithm::fgmres
          ? pressure.krylov_restart >= 2U && pressure.krylov_restart <= 64U
          : pressure.krylov_restart == 0U;
  const bool valid_coupling = solver.coupling == CouplingKind::piso ||
                              solver.coupling == CouplingKind::simple ||
                              solver.coupling == CouplingKind::outer_corrected;
  return solver.reference_outer_iterations <= 64U &&
         (!solver.cold_stopping || solver.cold_stopping->valid()) &&
         finite && valid_coupling && valid_algorithm && valid_scaling &&
         valid_pair && valid_restart && pressure.absolute_tolerance > 0.0 &&
         pressure.absolute_tolerance < 1.0 &&
         pressure.relative_tolerance > 0.0 &&
         pressure.relative_tolerance < 1.0 &&
         pressure.maximum_iterations > 0U &&
         pressure.maximum_iterations <= 1000000U &&
         pressure.true_residual_interval > 0U &&
         pressure.true_residual_interval <= pressure.maximum_iterations &&
         terminal.eos > 0.0 && terminal.eos < 1.0 &&
         terminal.continuity > 0.0 && terminal.continuity < 1.0 &&
         terminal.closed_mass > 0.0 && terminal.closed_mass < 1.0 &&
         terminal.gauge > 0.0 && terminal.gauge < 1.0 &&
         pressure.relative_tolerance <=
             std::min(terminal.continuity, terminal.gauge);
}

bool valid_time(const TimeControlSpec& time) noexcept {
  const bool finite_values =
      std::isfinite(time.initial_dt) && std::isfinite(time.minimum_dt) &&
      std::isfinite(time.maximum_dt) &&
      std::isfinite(time.convective_cfl) &&
      std::isfinite(time.convective_cfl_margin) &&
      std::isfinite(time.convective_cfl_limit()) &&
      std::isfinite(time.viscous_cfl) && std::isfinite(time.thermal_cfl) &&
      std::isfinite(time.species_cfl) && std::isfinite(time.acoustic_cfl) &&
      std::isfinite(time.maximum_growth) &&
      std::isfinite(time.retry_factor) &&
      std::isfinite(time.minimum_bdf_ratio) &&
      std::isfinite(time.maximum_bdf_ratio);
  return valid_cfl_definition(time.convective_cfl_definition) && finite_values && time.initial_dt > 0.0 && time.minimum_dt > 0.0 &&
         time.maximum_dt >= time.minimum_dt &&
         time.initial_dt >= time.minimum_dt &&
         time.initial_dt <= time.maximum_dt && time.convective_cfl > 0.0 &&
         time.convective_cfl_margin >= 0.0 &&
         time.convective_cfl_margin < time.convective_cfl &&
         time.viscous_cfl > 0.0 && time.thermal_cfl > 0.0 &&
         time.species_cfl > 0.0 && time.acoustic_cfl > 0.0 &&
         time.maximum_growth >= 1.0 && time.retry_factor > 0.0 &&
         time.retry_factor < 1.0 && time.maximum_retries > 0U &&
         time.minimum_bdf_ratio > 0.0 &&
         time.maximum_bdf_ratio >= time.minimum_bdf_ratio &&
         static_cast<std::uint8_t>(time.control) <=
             static_cast<std::uint8_t>(TimeControlKind::adaptive_acoustic) &&
         static_cast<std::uint8_t>(time.scheme) <=
             static_cast<std::uint8_t>(TimeScheme::cn_be);
}

void hash_boundary(Hash64& hash, const BoundaryFaceSpec& face) noexcept {
  hash.integer(static_cast<std::uint8_t>(face.flow_kind));
  hash.integer(static_cast<std::uint8_t>(face.thermal_kind));
  hash_real3(hash, face.velocity);
  hash_real3(hash, face.direction);
  hash_real3(hash, face.backflow_velocity);
  hash.real(face.mass_flow_rate);
  hash.real(face.pressure);
  hash.real(face.temperature);
  hash.real(face.total_pressure);
  hash.real(face.total_temperature);
  hash.real(face.backflow_temperature);
  hash.real(face.heat_flux);
  hash.real(face.relaxation);
  hash.real(face.mach_limit);
  hash.integer(static_cast<std::uint8_t>(face.allow_backflow ? 1U : 0U));
  hash.integer(static_cast<std::uint16_t>(face.scalars.size()));
  for (const ScalarBoundarySpec& scalar : face.scalars) {
    hash.text(scalar.stable_name);
    hash.integer(static_cast<std::uint8_t>(scalar.kind));
    hash.real(scalar.value);
    hash.integer(static_cast<std::uint8_t>(scalar.backflow_kind));
    hash.real(scalar.backflow_value);
  }
}

void hash_schemes(Hash64& hash, const SchemeSpec& value) noexcept {
  hash.integer(static_cast<std::uint8_t>(value.momentum));
  hash.integer(static_cast<std::uint8_t>(value.enthalpy));
  hash.integer(static_cast<std::uint8_t>(value.species));
  hash.integer(static_cast<std::uint8_t>(value.passive_scalar));
  hash.integer(static_cast<std::uint8_t>(value.diffusion));
  hash.real(value.limiter);
}

void hash_solver(Hash64& hash, const SolverSpec& value) noexcept {
  hash.real(value.pressure.absolute_tolerance);
  hash.real(value.pressure.relative_tolerance);
  hash.integer(value.pressure.maximum_iterations);
  hash.integer(value.pressure.true_residual_interval);
  hash.integer(value.pressure.krylov_restart);
  if (value.pressure.algorithm != LinearAlgorithm::fgmres ||
      value.pressure.mg_correction_scaling !=
          MgCorrectionScaling::residual_minimizing) {
    hash.integer(static_cast<std::uint8_t>(value.pressure.algorithm));
    hash.integer(
        static_cast<std::uint8_t>(value.pressure.mg_correction_scaling));
  }
  hash.real(value.terminal.eos);
  hash.real(value.terminal.continuity);
  hash.real(value.terminal.closed_mass);
  hash.real(value.terminal.gauge);
}

void hash_time(Hash64& hash, const TimeControlSpec& value) noexcept {
  if (value.convective_cfl_definition != ConvectiveCflDefinition::outgoing_sum) {
    hash.integer(UINT64_C(0x43464c4445463031));
    hash.integer(static_cast<std::uint8_t>(value.convective_cfl_definition));
  }
  hash.integer(static_cast<std::uint8_t>(value.control));
  hash.integer(static_cast<std::uint8_t>(value.scheme));
  hash.real(value.initial_dt);
  hash.real(value.minimum_dt);
  hash.real(value.maximum_dt);
  hash.real(value.convective_cfl);
  hash.real(value.viscous_cfl);
  hash.real(value.thermal_cfl);
  hash.real(value.species_cfl);
  hash.real(value.acoustic_cfl);
  hash.real(value.maximum_growth);
  hash.real(value.retry_factor);
  hash.integer(value.maximum_retries);
  hash.real(value.minimum_bdf_ratio);
  hash.real(value.maximum_bdf_ratio);
  if (value.convective_cfl_margin > 0.0) {
    hash.integer(UINT64_C(0x43464c42414e4431));
    hash.real(value.convective_cfl_margin);
  }
}

bool valid_direct_name(std::string_view text, std::string_view extension,
                       fs::path& out) {
  if (text.empty() || text.size() > detail::kMaxRelativePathBytes ||
      text.find('\\') != std::string_view::npos ||
      text.find('\0') != std::string_view::npos) {
    return false;
  }
  fs::path candidate{std::string(text)};
  if (candidate.is_absolute() || candidate.has_root_path() ||
      !candidate.parent_path().empty() || candidate.filename() != candidate ||
      candidate == "." || candidate == ".." ||
      candidate.extension().generic_string() != extension) {
    return false;
  }
  out = std::move(candidate);
  return true;
}

Status open_direct_file(int root_descriptor, std::string_view name,
                        std::string_view extension, int rank,
                        fs::path& relative, UniqueFd& descriptor,
                        struct stat& metadata) {
  if (!valid_direct_name(name, extension, relative)) {
    return invalid_case(detail_reference_path);
  }
  return open_regular_at(root_descriptor, relative, rank,
                         detail_reference_missing, detail_reference_path,
                         descriptor, metadata);
}

double reference_binary32_value(double value) noexcept {
  // The runtime axes are float32 authorities.  The volatile store makes the
  // narrowing observable even when LTO can see an earlier equivalent cast.
  volatile const float narrowed = static_cast<float>(value);
  return static_cast<double>(narrowed);
}

Status parse_reference_runtime_axes(
    std::string_view text, const CartesianMeshSpec& declared,
    std::array<std::vector<double>, 3U>& out) {
  std::istringstream input{std::string(text)};
  input.imbue(std::locale::classic());
  std::string token;
  std::int64_t version = 0;
  std::array<std::int64_t, 3U> cells{};
  if (!(input >> token) || !format_name(token,"RUNTIME_AXES") ||
      !(input >> version) || version != 1 || !(input >> token) ||
      token != "grid" || !(input >> cells[0] >> cells[1] >> cells[2]) ||
      !declared.has_exact_cells) {
    return invalid_case(detail_json_value);
  }
  const std::array<std::int32_t, 3U> declared_cells{
      declared.exact_cells.x, declared.exact_cells.y,
      declared.exact_cells.z};
  std::uint64_t global_cells = 1U;
  std::uint64_t total_faces = 0U;
  for (std::size_t axis = 0U; axis < cells.size(); ++axis) {
    if (cells[axis] <= 0 ||
        cells[axis] >= std::numeric_limits<std::int32_t>::max() ||
        cells[axis] != declared_cells[axis]) {
      return invalid_case(detail_json_value);
    }
    const auto count = static_cast<std::uint64_t>(cells[axis]);
    if (global_cells > declared.limits.max_global_cells / count ||
        count + 1U > std::numeric_limits<std::uint64_t>::max() - total_faces) {
      return invalid_case(detail_json_value);
    }
    global_cells *= count;
    total_faces += count + 1U;
  }
  if (global_cells > declared.limits.max_global_cells ||
      total_faces >
          declared.limits.max_memory_bytes_per_rank / sizeof(double)) {
    return invalid_case(detail_json_value);
  }

  constexpr std::array<std::string_view, 3U> names{"x", "y", "z"};
  for (std::size_t axis = 0U; axis < names.size(); ++axis) {
    std::int64_t count = 0;
    if (!(input >> token) || token != names[axis] || !(input >> count) ||
        count != cells[axis] + 1) {
      return invalid_case(detail_json_value);
    }
    out[axis].resize(static_cast<std::size_t>(count));
    double previous = 0.0;
    for (std::size_t index = 0U; index < out[axis].size(); ++index) {
      double coordinate = 0.0;
      if (!(input >> coordinate)) {
        return invalid_case(detail_json_value);
      }
      coordinate = reference_binary32_value(coordinate);
      if (!std::isfinite(coordinate) ||
          (index != 0U && !(previous < coordinate))) {
        return invalid_case(detail_json_value);
      }
      out[axis][index] = coordinate;
      previous = coordinate;
    }
  }
  if (input >> token) {
    return invalid_case(detail_json_value);
  }
  const std::array<double, 3U> declared_lower{
      reference_binary32_value(declared.lower.x),
      reference_binary32_value(declared.lower.y),
      reference_binary32_value(declared.lower.z)};
  const std::array<double, 3U> declared_upper{
      reference_binary32_value(declared.upper.x),
      reference_binary32_value(declared.upper.y),
      reference_binary32_value(declared.upper.z)};
  for (std::size_t axis = 0U; axis < out.size(); ++axis) {
    if (!std::isfinite(declared_lower[axis]) ||
        !std::isfinite(declared_upper[axis]) ||
        out[axis].front() != declared_lower[axis] ||
        out[axis].back() != declared_upper[axis]) {
      return invalid_case(detail_json_value);
    }
  }
  return {};
}

class WireWriter {
 public:
  void byte(std::uint8_t value) { bytes_.push_back(value); }

  void u16(std::uint16_t value) {
    byte(static_cast<std::uint8_t>(value & 0xffU));
    byte(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
  }

  void u32(std::uint32_t value) {
    for (unsigned int shift = 0U; shift < 32U; shift += 8U) {
      byte(static_cast<std::uint8_t>((value >> shift) & 0xffU));
    }
  }

  void u64(std::uint64_t value) {
    for (unsigned int shift = 0U; shift < 64U; shift += 8U) {
      byte(static_cast<std::uint8_t>((value >> shift) & 0xffU));
    }
  }

  void i32(std::int32_t value) {
    u32(static_cast<std::uint32_t>(value));
  }

  void real(double value) {
    if (value == 0.0) {
      value = 0.0;
    }
    std::uint64_t bits = 0U;
    std::memcpy(&bits, &value, sizeof(bits));
    u64(bits);
  }

  void real3(const Real3& value) {
    real(value.x);
    real(value.y);
    real(value.z);
  }

  bool text(std::string_view value) {
    if (value.size() > std::numeric_limits<std::uint16_t>::max()) {
      return false;
    }
    u16(static_cast<std::uint16_t>(value.size()));
    bytes_.insert(bytes_.end(), value.begin(), value.end());
    return bytes_.size() <= detail::kMaxWireBytes;
  }

  std::vector<std::uint8_t> take() && { return std::move(bytes_); }

 private:
  std::vector<std::uint8_t> bytes_;
};

class WireReader {
 public:
  explicit WireReader(const std::vector<std::uint8_t>& bytes) noexcept
      : bytes_(bytes) {}

  bool byte(std::uint8_t& out) noexcept {
    if (position_ >= bytes_.size()) {
      return false;
    }
    out = bytes_[position_++];
    return true;
  }

  bool u16(std::uint16_t& out) noexcept {
    std::uint8_t low = 0U;
    std::uint8_t high = 0U;
    if (!byte(low) || !byte(high)) {
      return false;
    }
    out = static_cast<std::uint16_t>(low) |
          static_cast<std::uint16_t>(static_cast<std::uint16_t>(high) << 8U);
    return true;
  }

  bool u32(std::uint32_t& out) noexcept {
    out = 0U;
    for (unsigned int shift = 0U; shift < 32U; shift += 8U) {
      std::uint8_t part = 0U;
      if (!byte(part)) {
        return false;
      }
      out |= static_cast<std::uint32_t>(part) << shift;
    }
    return true;
  }

  bool u64(std::uint64_t& out) noexcept {
    out = 0U;
    for (unsigned int shift = 0U; shift < 64U; shift += 8U) {
      std::uint8_t part = 0U;
      if (!byte(part)) {
        return false;
      }
      out |= static_cast<std::uint64_t>(part) << shift;
    }
    return true;
  }

  bool i32(std::int32_t& out) noexcept {
    std::uint32_t bits = 0U;
    if (!u32(bits) ||
        bits > static_cast<std::uint32_t>(
                   std::numeric_limits<std::int32_t>::max())) {
      return false;
    }
    out = static_cast<std::int32_t>(bits);
    return true;
  }

  bool real(double& out) noexcept {
    std::uint64_t bits = 0U;
    if (!u64(bits)) {
      return false;
    }
    std::memcpy(&out, &bits, sizeof(out));
    if (!std::isfinite(out)) {
      return false;
    }
    if (out == 0.0) {
      out = 0.0;
    }
    return true;
  }

  bool real3(Real3& out) noexcept {
    return real(out.x) && real(out.y) && real(out.z);
  }

  bool text(std::string& out) {
    std::uint16_t size = 0U;
    if (!u16(size) || size > detail::kMaxRelativePathBytes ||
        position_ + size > bytes_.size()) {
      return false;
    }
    out.assign(reinterpret_cast<const char*>(bytes_.data() + position_), size);
    position_ += size;
    return true;
  }

  bool finished() const noexcept { return position_ == bytes_.size(); }

 private:
  const std::vector<std::uint8_t>& bytes_;
  std::size_t position_{};
};

void write_boundary(WireWriter& writer, const BoundaryFaceSpec& face) {
  writer.byte(static_cast<std::uint8_t>(face.flow_kind));
  writer.byte(static_cast<std::uint8_t>(face.thermal_kind));
  writer.real3(face.velocity);
  writer.real3(face.direction);
  writer.real3(face.backflow_velocity);
  writer.real(face.mass_flow_rate);
  writer.real(face.pressure);
  writer.real(face.temperature);
  writer.real(face.total_pressure);
  writer.real(face.total_temperature);
  writer.real(face.backflow_temperature);
  writer.real(face.heat_flux);
  writer.real(face.relaxation);
  writer.real(face.mach_limit);
  writer.byte(face.allow_backflow ? 1U : 0U);
  writer.u16(static_cast<std::uint16_t>(face.scalars.size()));
  for (const ScalarBoundarySpec& scalar : face.scalars) {
    static_cast<void>(writer.text(scalar.stable_name));
    writer.byte(static_cast<std::uint8_t>(scalar.kind));
    writer.real(scalar.value);
    writer.byte(static_cast<std::uint8_t>(scalar.backflow_kind));
    writer.real(scalar.backflow_value);
  }
}

void write_transported_scalars(
    WireWriter& writer,
    const std::vector<TransportedScalarSpec>& scalars) {
  writer.u16(static_cast<std::uint16_t>(scalars.size()));
  for (const TransportedScalarSpec& scalar : scalars) {
    static_cast<void>(writer.text(scalar.stable_name));
    writer.byte(static_cast<std::uint8_t>(scalar.role));
    writer.real(scalar.molecular_schmidt);
    writer.real(scalar.turbulent_schmidt);
  }
}

bool read_transported_scalars(
    WireReader& reader,
    std::vector<TransportedScalarSpec>& scalars) {
  std::uint16_t count = 0U;
  if (!reader.u16(count) || count > kMaxTransportedScalars) {
    return false;
  }
  scalars.reserve(count);
  for (std::uint16_t index = 0U; index < count; ++index) {
    TransportedScalarSpec scalar;
    std::uint8_t role = 0U;
    if (!reader.text(scalar.stable_name) || !reader.byte(role) ||
        role > static_cast<std::uint8_t>(
                   TransportedScalarRole::passive_scalar) ||
        !reader.real(scalar.molecular_schmidt) ||
        !reader.real(scalar.turbulent_schmidt)) {
      return false;
    }
    scalar.role = static_cast<TransportedScalarRole>(role);
    scalars.push_back(std::move(scalar));
  }
  return valid_transported_scalars(scalars);
}

bool read_boundary(WireReader& reader, BoundaryFaceSpec& face) {
  std::uint8_t flow = 0U;
  std::uint8_t thermal = 0U;
  std::uint8_t allow_backflow = 0U;
  std::uint16_t scalar_count = 0U;
  if (!reader.byte(flow) ||
      flow > static_cast<std::uint8_t>(BoundaryKind::zero_gradient_mass_outlet) ||
      !reader.byte(thermal) ||
      thermal > static_cast<std::uint8_t>(BoundaryKind::heat_flux_wall) ||
      !reader.real3(face.velocity) || !reader.real3(face.direction) ||
      !reader.real3(face.backflow_velocity) ||
      !reader.real(face.mass_flow_rate) || !reader.real(face.pressure) ||
      !reader.real(face.temperature) || !reader.real(face.total_pressure) ||
      !reader.real(face.total_temperature) ||
      !reader.real(face.backflow_temperature) || !reader.real(face.heat_flux) ||
      !reader.real(face.relaxation) || !reader.real(face.mach_limit) ||
      !reader.byte(allow_backflow) || allow_backflow > 1U ||
      !reader.u16(scalar_count) || scalar_count > kMaxScalarsPerFace) {
    return false;
  }
  face.flow_kind = static_cast<BoundaryKind>(flow);
  face.thermal_kind = static_cast<BoundaryKind>(thermal);
  face.allow_backflow = allow_backflow != 0U;
  face.scalars.reserve(scalar_count);
  for (std::uint16_t index = 0U; index < scalar_count; ++index) {
    ScalarBoundarySpec scalar;
    std::uint8_t kind = 0U;
    std::uint8_t backflow_kind = 0U;
    if (!reader.text(scalar.stable_name) || !reader.byte(kind) ||
        kind > static_cast<std::uint8_t>(ScalarBoundaryKind::convective) ||
        !reader.real(scalar.value) || !reader.byte(backflow_kind) ||
        backflow_kind >
            static_cast<std::uint8_t>(ScalarBoundaryKind::convective) ||
        !reader.real(scalar.backflow_value)) {
      return false;
    }
    scalar.kind = static_cast<ScalarBoundaryKind>(kind);
    scalar.backflow_kind =
        static_cast<ScalarBoundaryKind>(backflow_kind);
    face.scalars.push_back(std::move(scalar));
  }
  return valid_boundary(face);
}

bool valid_patch_inlets(const ValidatedModel& model) {
  if (!model.patch_inlets) return true;
  const PatchInletsSpec& inlets = *model.patch_inlets;
  fs::path path;
  if (!model.mesh.has_exact_cells ||
      !valid_direct_name(inlets.labels_file.generic_string(), ".d", path) ||
      inlets.labels_fingerprint == 0U ||
      inlets.patches.empty() || inlets.patches.size() > 256U)
    return false;
  std::set<std::int32_t> labels;
  for (const PatchInletSpec& patch : inlets.patches) {
    const BoundaryFaceSpec& inlet = patch.boundary;
    if (patch.label <= 0 || !labels.insert(patch.label).second ||
        patch.face >= 6U || !valid_boundary(inlet) ||
        inlet.flow_kind != BoundaryKind::mass_flow_inlet ||
        !(inlet.mass_flow_rate > 0.0) || !(inlet.temperature > 0.0) ||
        inlet.allow_backflow ||
        (patch.immersed && !model.immersed_boundary) ||
        (!patch.immersed &&
         model.boundaries[patch.face].flow_kind !=
             BoundaryKind::mass_flow_inlet) ||
        inlet.scalars.size() != model.transported_scalars.size())
      return false;
    const double normal_component = patch.face < 2U ? inlet.direction.x :
        (patch.face < 4U ? inlet.direction.y : inlet.direction.z);
    if (!((patch.face % 2U == 0U ? normal_component : -normal_component) > 0.0))
      return false;
    double species_sum = 0.0;
    for (const auto& catalog : model.transported_scalars) {
      const auto found = std::find_if(inlet.scalars.begin(), inlet.scalars.end(),
          [&](const ScalarBoundarySpec& scalar) {
            return scalar.stable_name == catalog.stable_name;
          });
      if (found == inlet.scalars.end() ||
          found->kind != ScalarBoundaryKind::dirichlet)
        return false;
      if (catalog.role == TransportedScalarRole::species) {
        if (found->value < 0.0 || found->value > 1.0) return false;
        species_sum += found->value;
      }
    }
    if (species_sum > 1.0) return false;
  }
  return true;
}

bool parse_patch_inlets(yyjson_val* value, PatchInletsSpec& out) {
  if (!object_has_exact_keys(value, {"labels_file", "patches"})) return false;
  const auto path = string_value(value, "labels_file");
  yyjson_val* patches = yyjson_obj_get(value, "patches");
  if (!path || !valid_direct_name(*path, ".d", out.labels_file) ||
      !yyjson_is_arr(patches) || yyjson_arr_size(patches) == 0U ||
      yyjson_arr_size(patches) > 256U)
    return false;
  constexpr std::array<std::string_view, 6U> names{
      "x_min", "x_max", "y_min", "y_max", "z_min", "z_max"};
  for (std::size_t index = 0; index < yyjson_arr_size(patches); ++index) {
    yyjson_val* item = yyjson_arr_get(patches, index);
    if (!object_has_exact_keys(item, {"label", "face", "immersed", "boundary"}))
      return false;
    const auto face = string_value(item, "face");
    yyjson_val* immersed = yyjson_obj_get(item, "immersed");
    std::uint32_t label = 0;
    PatchInletSpec patch;
    if (!parse_uint32(yyjson_obj_get(item, "label"), label) || label == 0U ||
        label > INT32_MAX || !face || !yyjson_is_bool(immersed) ||
        !parse_boundary_face(yyjson_obj_get(item, "boundary"), patch.boundary))
      return false;
    const auto found = std::find(names.begin(), names.end(), *face);
    if (found == names.end()) return false;
    patch.label = static_cast<std::int32_t>(label);
    patch.face = static_cast<std::uint8_t>(found - names.begin());
    patch.immersed = yyjson_get_bool(immersed);
    out.patches.push_back(std::move(patch));
  }
  std::sort(out.patches.begin(), out.patches.end(),
      [](const PatchInletSpec& a, const PatchInletSpec& b) {
        return a.label < b.label;
      });
  return true;
}

void write_patch_inlets(WireWriter& writer, const PatchInletsSpec& value) {
  writer.text(value.labels_file.generic_string());
  writer.u64(value.labels_fingerprint);
  writer.u16(static_cast<std::uint16_t>(value.patches.size()));
  for (const PatchInletSpec& patch : value.patches) {
    writer.i32(patch.label);
    writer.byte(patch.face);
    writer.byte(patch.immersed ? 1U : 0U);
    write_boundary(writer, patch.boundary);
  }
}

bool read_patch_inlets(WireReader& reader, PatchInletsSpec& value) {
  std::string path;
  std::uint16_t count = 0U;
  if (!reader.text(path) || !valid_direct_name(path, ".d", value.labels_file) ||
      !reader.u64(value.labels_fingerprint) ||
      !reader.u16(count) || count == 0U || count > 256U)
    return false;
  for (std::uint16_t index = 0U; index < count; ++index) {
    PatchInletSpec patch;
    std::uint8_t immersed = 0U;
    if (!reader.i32(patch.label) || !reader.byte(patch.face) ||
        !reader.byte(immersed) || immersed > 1U ||
        !read_boundary(reader, patch.boundary))
      return false;
    patch.immersed = immersed != 0U;
    value.patches.push_back(std::move(patch));
  }
  return true;
}

void write_solver(WireWriter &writer, const SolverSpec &value, bool extended) {
  writer.real(value.pressure.absolute_tolerance);
  writer.real(value.pressure.relative_tolerance);
  writer.u32(value.pressure.maximum_iterations);
  writer.u32(value.pressure.true_residual_interval);
  if (extended) {
    writer.byte(static_cast<std::uint8_t>(value.pressure.algorithm));
    writer.byte(
        static_cast<std::uint8_t>(value.pressure.mg_correction_scaling));
  }
  writer.u32(value.pressure.krylov_restart);
  writer.real(value.terminal.eos);
  writer.real(value.terminal.continuity);
  writer.real(value.terminal.closed_mass);
  writer.real(value.terminal.gauge);
}

bool read_cold_stopping(WireReader& reader, ValidatedModel& model) noexcept {
  if (model.time.scheme != TimeScheme::cn_be) return true;
  std::uint8_t present{};
  if (!reader.byte(present) || present > 1U) return false;
  if (present == 0U) return true;
  std::uint64_t tag{};
  ColdStoppingSpec stopping;
  if (!reader.u64(tag) || tag != UINT64_C(0x434e424553544f31) ||
      !reader.real(stopping.reference_time) || !reader.real(stopping.momentum) ||
      !reader.real(stopping.enthalpy) || !reader.real(stopping.species) ||
      !stopping.valid()) return false;
  model.solver.cold_stopping = stopping;
  return true;
}

bool read_cfl_band(WireReader& reader, TimeControlSpec& time) noexcept {
  std::uint64_t tag{};
  return reader.u64(tag) && tag == UINT64_C(0x43464c42414e4431) &&
      reader.real(time.convective_cfl_margin) &&
      time.convective_cfl_margin > 0.0 && valid_time(time);
}

bool read_solver(WireReader &reader, SolverSpec &value,
                 bool extended) noexcept {
  std::uint8_t algorithm = 0U;
  std::uint8_t scaling = 0U;
  return reader.real(value.pressure.absolute_tolerance) &&
         reader.real(value.pressure.relative_tolerance) &&
         reader.u32(value.pressure.maximum_iterations) &&
         reader.u32(value.pressure.true_residual_interval) &&
         (!extended ||
          (reader.byte(algorithm) &&
           algorithm <= static_cast<std::uint8_t>(LinearAlgorithm::bicgstab) &&
           reader.byte(scaling) &&
           scaling <=
               static_cast<std::uint8_t>(MgCorrectionScaling::unit_linear) &&
           (value.pressure.algorithm = static_cast<LinearAlgorithm>(algorithm),
            value.pressure.mg_correction_scaling =
                static_cast<MgCorrectionScaling>(scaling),
            true))) &&
         reader.u32(value.pressure.krylov_restart) &&
         reader.real(value.terminal.eos) &&
         reader.real(value.terminal.continuity) &&
         reader.real(value.terminal.closed_mass) &&
         reader.real(value.terminal.gauge) && valid_solver(value);
}

void write_schemes(WireWriter& writer, const SchemeSpec& value) {
  writer.byte(static_cast<std::uint8_t>(value.momentum));
  writer.byte(static_cast<std::uint8_t>(value.enthalpy));
  writer.byte(static_cast<std::uint8_t>(value.species));
  writer.byte(static_cast<std::uint8_t>(value.passive_scalar));
  writer.byte(static_cast<std::uint8_t>(value.diffusion));
  writer.real(value.limiter);
}

bool read_schemes(WireReader& reader, SchemeSpec& value) noexcept {
  std::uint8_t momentum = 0U;
  std::uint8_t enthalpy = 0U;
  std::uint8_t species = 0U;
  std::uint8_t passive = 0U;
  std::uint8_t diffusion = 0U;
  if (!reader.byte(momentum) ||
      momentum > static_cast<std::uint8_t>(ConvectionScheme::tvd2) ||
      !reader.byte(enthalpy) ||
      enthalpy > static_cast<std::uint8_t>(ConvectionScheme::tvd2) ||
      !reader.byte(species) ||
      species > static_cast<std::uint8_t>(ConvectionScheme::tvd2) ||
      !reader.byte(passive) ||
      passive > static_cast<std::uint8_t>(ConvectionScheme::tvd2) ||
      !reader.byte(diffusion) ||
      diffusion != static_cast<std::uint8_t>(DiffusionScheme::central2) ||
      !reader.real(value.limiter)) {
    return false;
  }
  value.momentum = static_cast<ConvectionScheme>(momentum);
  value.enthalpy = static_cast<ConvectionScheme>(enthalpy);
  value.species = static_cast<ConvectionScheme>(species);
  value.passive_scalar = static_cast<ConvectionScheme>(passive);
  value.diffusion = static_cast<DiffusionScheme>(diffusion);
  return valid_schemes(value);
}

void write_time(WireWriter& writer, const TimeControlSpec& value) {
  writer.byte(static_cast<std::uint8_t>(value.control));
  writer.byte(static_cast<std::uint8_t>(value.scheme));
  writer.real(value.initial_dt);
  writer.real(value.minimum_dt);
  writer.real(value.maximum_dt);
  writer.real(value.convective_cfl);
  writer.real(value.viscous_cfl);
  writer.real(value.thermal_cfl);
  writer.real(value.species_cfl);
  writer.real(value.acoustic_cfl);
  writer.real(value.maximum_growth);
  writer.real(value.retry_factor);
  writer.u32(value.maximum_retries);
  writer.real(value.minimum_bdf_ratio);
  writer.real(value.maximum_bdf_ratio);
}

void write_thermophysics(WireWriter& writer,
                         const ThermophysicalSpec& value) {
  static_cast<void>(writer.text(value.data_file.generic_string()));
  writer.real(value.minimum_temperature);
  writer.real(value.maximum_temperature);
  writer.real(value.temperature_relative_tolerance);
  writer.u32(value.maximum_temperature_iterations);
  writer.real(value.closed_mass_relative_tolerance);
  writer.u32(value.maximum_closed_mass_iterations);
  writer.real(value.maximum_closed_mass_relative_step);
  writer.u16(static_cast<std::uint16_t>(value.species.size()));
  for (const SpeciesThermophysicalSpec& species : value.species) {
    static_cast<void>(writer.text(species.stable_name));
    writer.real(species.molecular_weight);
    writer.real(species.temperature_switch);
    for (const double coefficient : species.nasa7_low) {
      writer.real(coefficient);
    }
    for (const double coefficient : species.nasa7_high) {
      writer.real(coefficient);
    }
    writer.byte(static_cast<std::uint8_t>(species.transport_law));
    writer.real(species.viscosity_reference);
    writer.real(species.transport_reference_temperature);
    writer.real(species.sutherland_temperature);
    writer.real(species.prandtl);
    writer.real(species.conductivity);
    if (species.transport_law == TransportLaw::perry) {
      writer.real(species.critical_temperature);
      writer.real(species.critical_pressure);
    }
  }
}

bool read_thermophysics(WireReader& reader, std::uint8_t wire_version,
                        ThermophysicalSpec& value) {
  std::string path;
  std::uint16_t species_count = 0U;
  if (!reader.text(path) ||
      !valid_direct_name(path, ".d", value.data_file) ||
      !reader.real(value.minimum_temperature) ||
      !reader.real(value.maximum_temperature) ||
      !reader.real(value.temperature_relative_tolerance) ||
      !reader.u32(value.maximum_temperature_iterations) ||
      !reader.real(value.closed_mass_relative_tolerance) ||
      !reader.u32(value.maximum_closed_mass_iterations) ||
      !reader.real(value.maximum_closed_mass_relative_step) ||
      !reader.u16(species_count) || species_count == 0U ||
      species_count > 65U) {
    return false;
  }
  value.species.reserve(species_count);
  for (std::uint16_t index = 0U; index < species_count; ++index) {
    SpeciesThermophysicalSpec species;
    std::uint8_t law = 0U;
    if (!reader.text(species.stable_name) ||
        !reader.real(species.molecular_weight) ||
        !reader.real(species.temperature_switch)) {
      return false;
    }
    for (double& coefficient : species.nasa7_low) {
      if (!reader.real(coefficient)) {
        return false;
      }
    }
    for (double& coefficient : species.nasa7_high) {
      if (!reader.real(coefficient)) {
        return false;
      }
    }
    if (!reader.byte(law) ||
        law > static_cast<std::uint8_t>(TransportLaw::kerosene_vapor) ||
        !transport_law_wire_compatible(wire_version,
                                       static_cast<TransportLaw>(law)) ||
        !reader.real(species.viscosity_reference) ||
        !reader.real(species.transport_reference_temperature) ||
        !reader.real(species.sutherland_temperature) ||
        !reader.real(species.prandtl) ||
        !reader.real(species.conductivity)) {
      return false;
    }
    species.transport_law = static_cast<TransportLaw>(law);
    if (species.transport_law == TransportLaw::perry &&
        (!reader.real(species.critical_temperature) || !reader.real(species.critical_pressure)))
      return false;
    value.species.push_back(std::move(species));
  }
  return detail::valid_thermophysical_spec(value);
}

bool read_time(WireReader& reader, TimeControlSpec& value) noexcept {
  // The base wire predates the optional tagged CFL band extension.
  value.convective_cfl_margin = 0.0;
  std::uint8_t control = 0U;
  std::uint8_t scheme = 0U;
  if (!reader.byte(control) ||
      control > static_cast<std::uint8_t>(TimeControlKind::adaptive_acoustic) ||
      !reader.byte(scheme) ||
      scheme > static_cast<std::uint8_t>(TimeScheme::cn_be) ||
      !reader.real(value.initial_dt) || !reader.real(value.minimum_dt) ||
      !reader.real(value.maximum_dt) || !reader.real(value.convective_cfl) ||
      !reader.real(value.viscous_cfl) || !reader.real(value.thermal_cfl) ||
      !reader.real(value.species_cfl) || !reader.real(value.acoustic_cfl) ||
      !reader.real(value.maximum_growth) || !reader.real(value.retry_factor) ||
      !reader.u32(value.maximum_retries) ||
      !reader.real(value.minimum_bdf_ratio) ||
      !reader.real(value.maximum_bdf_ratio)) {
    return false;
  }
  value.control = static_cast<TimeControlKind>(control);
  value.scheme = static_cast<TimeScheme>(scheme);
  return valid_time(value);
}

bool unique_reference_paths(const ValidatedModel& model) {
  try {
    std::set<std::string> paths;
    const auto insert = [&](const fs::path& path) {
      const std::string name = path.generic_string();
      return !name.empty() && paths.insert(name).second;
    };
    if (!insert(model.thermophysics.data_file)) {
      return false;
    }
    if (model.mesh.kind == GeometryKind::runtime_axes_v1 &&
        !insert(model.mesh.axes_file)) {
      return false;
    }
    if (model.patch_inlets && !insert(model.patch_inlets->labels_file))
      return false;
    if (model.immersed_boundary && model.immersed_boundary->marker_file &&
        !insert(*model.immersed_boundary->marker_file))
      return false;
    for (const fs::path& path : model.data_files) {
      if (!insert(path)) {
        return false;
      }
    }
    return (!model.spray || insert(model.spray->liquid_file)) &&
           (model.reaction.representation !=
                ReactionSpec::Representation::direct_cantera ||
            insert(model.reaction.mechanism_file)) &&
           (!model.immersed_boundary.has_value() ||
            insert(model.immersed_boundary->stl_file));
  } catch (...) {
    return false;
  }
}

Status serialize_model(const ValidatedModel& model,
                       std::vector<std::uint8_t>& out) {
  try {
    const bool marker_geometry = model.immersed_boundary &&
        model.immersed_boundary->marker_file.has_value();
    if (marker_geometry) {
      fs::path marker_path;
      if (!model.mesh.has_exact_cells ||
          model.immersed_boundary->marker_fingerprint == 0U ||
          !valid_direct_name(model.immersed_boundary->marker_file->generic_string(),
                             ".d", marker_path))
        return invalid_case(detail_wire);
    } else if (model.immersed_boundary &&
               model.immersed_boundary->marker_fingerprint != 0U) {
      return invalid_case(detail_wire);
    }
    if ((model.thermophysics.fixed_pressure_pa > 0 &&
         model.pressure_reference != PressureReferenceKind::boundary_absolute) ||
        !detail::valid_reaction_spec(model.reaction) ||
        (model.spray && !detail::valid_spray_spec(*model.spray)) ||
        !valid_canonical_mesh(model.mesh) ||
        static_cast<std::uint8_t>(model.pressure_reference) >
            static_cast<std::uint8_t>(PressureReferenceKind::closed_mass) ||
        !valid_solver(model.solver) || !valid_schemes(model.schemes) ||
        !valid_time(model.time) ||
        (model.solver.coupling == CouplingKind::outer_corrected &&
         model.time.scheme != TimeScheme::cn_be) ||
        ((model.solver.cold_stopping || model.solver.reference_outer_iterations != 0U) &&
         model.time.scheme != TimeScheme::cn_be) ||
        (model.time.scheme == TimeScheme::cn_be
             ? model.legacy_time_fingerprint == 0U ||
                   model.legacy_time_fingerprint == model.fingerprint
             : model.legacy_time_fingerprint != 0U) ||
        !valid_patch_inlets(model) ||
        !valid_transported_scalars(model.transported_scalars) ||
        model.mesh.focus_regions.size() > detail::kMaxFocusRegions ||
        model.mesh.focus_regions.size() >
            std::numeric_limits<std::uint16_t>::max() ||
        model.data_files.size() > detail::kMaxReferencedFiles ||
        model.data_files.size() + (model.spray ? 1U : 0U) +
                (model.reaction.representation ==
                         ReactionSpec::Representation::direct_cantera
                     ? 1U
                     : 0U) +
                (marker_geometry ? 1U : 0U) +
                (model.patch_inlets ? 1U : 0U) +
                (model.immersed_boundary.has_value() ? 1U : 0U) +
                (model.mesh.kind == GeometryKind::runtime_axes_v1 ? 2U
                                                                        : 1U) >
            detail::kMaxReferencedFiles ||
        model.data_files.size() > std::numeric_limits<std::uint16_t>::max() ||
        (model.immersed_boundary.has_value() &&
         model.immersed_boundary->reconstruction_policy >
             IbmReconstructionPolicy::adaptive_order) ||
        !unique_reference_paths(model)) {
      return invalid_case(detail_wire);
    }
    fs::path thermophysical_path;
    if (!valid_direct_name(model.thermophysics.data_file.generic_string(),
                           ".d", thermophysical_path) ||
        !detail::valid_thermophysical_spec(model.thermophysics) ||
        detail::thermophysical_spec_fingerprint(model.thermophysics) == 0U ||
        !thermophysics_compatible_with_reference_axes(
            model.thermophysics,
            model.mesh.kind == GeometryKind::runtime_axes_v1)) {
      return invalid_case(detail_wire);
    }
    if (model.mesh.kind == GeometryKind::runtime_axes_v1) {
      fs::path axes_path;
      if (!valid_direct_name(model.mesh.axes_file.generic_string(), ".dat",
                             axes_path)) {
        return invalid_case(detail_wire);
      }
    }
    for (const BoundaryFaceSpec& face : model.boundaries) {
      if (!valid_boundary(face)) {
        return invalid_case(detail_wire);
      }
    }
    const bool extended_solver =
        model.solver.pressure.algorithm != LinearAlgorithm::fgmres ||
        model.solver.pressure.mg_correction_scaling !=
            MgCorrectionScaling::residual_minimizing;
    WireWriter writer;
    if (model.solver.reference_outer_iterations != 0U) {
      writer.byte(kReferenceOuterWireVersion);
      writer.u32(model.solver.reference_outer_iterations);
    }
    if (model.time.convective_cfl_definition != ConvectiveCflDefinition::outgoing_sum) {
      writer.byte(kCflDefinitionWireVersion);
      writer.byte(static_cast<std::uint8_t>(model.time.convective_cfl_definition));
    }
    if (model.spray && model.spray->evaporation != spray::EvaporationModel::abramzon_sirignano) {
      writer.byte(kSprayEvaporationWireVersion);
      writer.byte(static_cast<std::uint8_t>(model.spray->evaporation));
    }
    if (model.turbulence == TurbulenceKind::smagorinsky) {
      if (!std::isfinite(model.smagorinsky_coefficient) || model.smagorinsky_coefficient < 0.0)
        return invalid_case(detail_wire);
      writer.byte(kSmagorinskyWireVersion);
      writer.real(model.smagorinsky_coefficient);
    }
    if (model.time.convective_cfl_margin > 0.0) writer.byte(kCflBandWireVersion);
    const bool simple = model.solver.coupling == CouplingKind::simple;
    const bool reference_axes =
        model.mesh.kind == GeometryKind::runtime_axes_v1;
    const bool extensions = model.patch_inlets || marker_geometry;
    if (extensions) writer.byte(kPatchInletsWireVersion);
    writer.byte(
        (model.spray ? kSprayWireFlag : 0U) |
        (model.reaction.mode != ReactionMode::none ? kReactionWireFlag : 0U) |
        (reference_axes
             ? (simple
                    ? (extended_solver
                           ? kReferenceAxesSimplePressureAlgorithmWireVersion
                           : kReferenceAxesSimpleWireVersion)
                    : (extended_solver ? kReferenceAxesPressureAlgorithmWireVersion
                                       : kReferenceAxesWireVersion))
             : (simple ? (extended_solver ? kSimplePressureAlgorithmWireVersion
                                          : kSimpleWireVersion)
                       : (extended_solver ? kPressureAlgorithmWireVersion
                                          : kWireVersion))));
    writer.byte(static_cast<std::uint8_t>(model.mesh.kind));
    writer.byte(static_cast<std::uint8_t>(model.turbulence));
    writer.byte(static_cast<std::uint8_t>(model.pressure_reference) |
        (model.thermophysics.fixed_pressure_pa > 0 ? 0x10 : 0));
    if (model.thermophysics.fixed_pressure_pa > 0) writer.real(model.thermophysics.fixed_pressure_pa);
    writer.real3(model.mesh.lower);
    writer.real3(model.mesh.upper);
    writer.byte(model.mesh.has_exact_cells ? 1U : 0U);
    if (model.mesh.has_exact_cells) {
      writer.i32(model.mesh.exact_cells.x);
      writer.i32(model.mesh.exact_cells.y);
      writer.i32(model.mesh.exact_cells.z);
    }
    writer.byte(model.mesh.has_base_spacing ? 1U : 0U);
    if (model.mesh.has_base_spacing) {
      writer.real3(model.mesh.base_spacing);
    }
    writer.real3(model.mesh.minimum_spacing);
    writer.real(model.mesh.max_growth_ratio);
    writer.u16(static_cast<std::uint16_t>(model.mesh.focus_regions.size()));
    for (const FocusRegionSpec& focus : model.mesh.focus_regions) {
      writer.real3(focus.lower);
      writer.real3(focus.upper);
      writer.real3(focus.target_spacing);
    }
    writer.u64(model.mesh.limits.max_global_cells);
    writer.u64(model.mesh.limits.max_memory_bytes_per_rank);
    if (reference_axes) {
      if (!writer.text(model.mesh.axes_file.generic_string())) {
        return invalid_case(detail_wire);
      }
      for (const auto& axis : model.mesh.runtime_faces) {
        writer.u64(static_cast<std::uint64_t>(axis.size()));
        for (const double coordinate : axis) {
          writer.real(coordinate);
        }
      }
    }
    for (const BoundaryFaceSpec& face : model.boundaries) {
      write_boundary(writer, face);
    }
    write_transported_scalars(writer, model.transported_scalars);
    write_solver(writer, model.solver, extended_solver);
    write_schemes(writer, model.schemes);
    write_time(writer, model.time);
    write_thermophysics(writer, model.thermophysics);
    writer.u16(static_cast<std::uint16_t>(model.data_files.size()));
    writer.byte(model.immersed_boundary.has_value() ? 1U : 0U);
    writer.byte(model.immersed_boundary.has_value()
                    ? static_cast<std::uint8_t>(
                          model.immersed_boundary->fluid_side)
                    : 0U);
    writer.byte(model.immersed_boundary.has_value()
                    ? static_cast<std::uint8_t>(
                          model.immersed_boundary->reconstruction_policy)
                    : 0U);
    for (const fs::path& path : model.data_files) {
      if (!writer.text(path.generic_string())) {
        return invalid_case(detail_wire);
      }
    }
    if (model.immersed_boundary.has_value() &&
        !writer.text(model.immersed_boundary->stl_file.generic_string())) {
      return invalid_case(detail_wire);
    }
    if (model.reaction.mode != ReactionMode::none) {
      const auto& r = model.reaction;
      writer.byte(static_cast<std::uint8_t>(r.mode));
      writer.byte(static_cast<std::uint8_t>(r.representation));
      if (!writer.text(r.mechanism_sha256) || !writer.text(r.phase) ||
          !writer.text(r.mechanism_file.generic_string())) return invalid_case(detail_wire);
      writer.real(r.analytic_rate_s); writer.real(r.analytic_cp_j_per_kg_k);
      writer.real(r.relative_tolerance); writer.real(r.absolute_tolerance);
      writer.u32(r.maximum_internal_steps);
      writer.real(r.mixing_c_z); writer.real(r.turbulent_schmidt);
      if (r.esf) {
        const auto& e = *r.esf;
        writer.u32(e.fields); writer.u64(e.seed);
        writer.u32(static_cast<std::uint32_t>(e.initial_species_offsets.size()));
        for (double v : e.initial_species_offsets) writer.real(v);
        writer.byte(static_cast<std::uint8_t>(e.tcr.mode) |
                    (e.tcr.model == TcrModel::cdphyso_dynamic_v1 ? 0x10 :
                     e.tcr.model == TcrModel::dyn711_v1 ? 0x20 : 0));
        writer.u32(static_cast<std::uint32_t>(e.tcr.reactants.size()));
        for (const auto& name : e.tcr.reactants)
          if (!writer.text(name)) return invalid_case(detail_wire);
        writer.u32(static_cast<std::uint32_t>(e.tcr.progress_weights.size()));
        for (double v : e.tcr.progress_weights) writer.real(v);
        writer.u32(static_cast<std::uint32_t>(e.tcr.initialization_sign + 1));
        writer.real(e.tcr.weak_rate_threshold);
        if (dynamic_tcr_model(e.tcr.model) && !writer.text(e.tcr.fuel))
          return invalid_case(detail_wire);
        if (e.tcr.model == TcrModel::dyn711_v1) {
          if(!writer.text(e.tcr.mixture_fraction))return invalid_case(detail_wire);
          writer.real(e.tcr.oxidizer_oxygen_mass_fraction);
        }
      }
    }
    if (model.spray && !detail::write_spray(writer, *model.spray))
      return invalid_case(detail_wire);
    if (extensions) {
      writer.byte(marker_geometry ? 1U : 0U);
      if (marker_geometry) {
        writer.text(model.immersed_boundary->marker_file->generic_string());
        writer.u64(model.immersed_boundary->marker_fingerprint);
      }
      writer.byte(model.patch_inlets ? 1U : 0U);
      if (model.patch_inlets) write_patch_inlets(writer, *model.patch_inlets);
    }
    writer.u64(model.fingerprint);
    if (model.time.scheme == TimeScheme::cn_be)
      writer.u64(model.legacy_time_fingerprint);
    if (model.time.scheme == TimeScheme::cn_be)
      writer.byte(model.solver.cold_stopping ? 1U : 0U);
    if (model.solver.cold_stopping) {
      const auto& stopping = *model.solver.cold_stopping;
      writer.u64(UINT64_C(0x434e424553544f31));
      writer.real(stopping.reference_time);
      writer.real(stopping.momentum);
      writer.real(stopping.enthalpy);
      writer.real(stopping.species);
    }
    if (model.time.convective_cfl_margin > 0.0) {
      writer.u64(UINT64_C(0x43464c42414e4431));
      writer.real(model.time.convective_cfl_margin);
    }
    std::vector<std::uint8_t> candidate = std::move(writer).take();
    if (candidate.empty() || candidate.size() > detail::kMaxWireBytes) {
      return invalid_case(detail_wire);
    }
    out = std::move(candidate);
    return {};
  } catch (...) {
    return {StatusCode::allocation_failure, detail_wire};
  }
}

Status deserialize_model(const std::vector<std::uint8_t>& bytes,
                         ValidatedModel& out) {
  try {
    WireReader reader(bytes);
    std::uint8_t version = 0U;
    std::uint8_t geometry = 0U;
    std::uint8_t turbulence = 0U;
    std::uint8_t pressure_reference = 0U;
    std::uint8_t has_exact_cells = 0U;
    std::uint8_t has_base_spacing = 0U;
    std::uint16_t focus_count = 0U;
    std::uint16_t data_count = 0U;
    std::uint8_t has_stl = 0U;
    std::uint8_t fluid_side = 0U;
    std::uint8_t reconstruction_policy = 0U;
    if (!reader.byte(version)) return invalid_case(detail_wire);
    std::uint32_t reference_outer_iterations{};
    if (version == kReferenceOuterWireVersion &&
        (!reader.u32(reference_outer_iterations) || reference_outer_iterations == 0U ||
         reference_outer_iterations > 64U || !reader.byte(version)))
      return invalid_case(detail_wire);
    std::uint8_t cfl_definition=0;
    if (version==kCflDefinitionWireVersion &&
        (!reader.byte(cfl_definition) || cfl_definition!=1 || !reader.byte(version)))
      return invalid_case(detail_wire);
    const bool evaporation_wire = version == kSprayEvaporationWireVersion;
    std::uint8_t evaporation = 0;
    if (evaporation_wire &&
        (!reader.byte(evaporation) ||
         evaporation != static_cast<std::uint8_t>(spray::EvaporationModel::thick_exchange) ||
         !reader.byte(version))) return invalid_case(detail_wire);
    const bool smagorinsky_wire = version == kSmagorinskyWireVersion;
    double smagorinsky_coefficient = 0.17;
    if (smagorinsky_wire &&
        (!reader.real(smagorinsky_coefficient) || !std::isfinite(smagorinsky_coefficient) ||
         smagorinsky_coefficient < 0.0 || !reader.byte(version)))
      return invalid_case(detail_wire);
    const bool cfl_band_wire = version == kCflBandWireVersion;
    if (cfl_band_wire && !reader.byte(version)) return invalid_case(detail_wire);
    const bool patch_wire = version == kPatchInletsWireVersion;
    if (patch_wire && !reader.byte(version)) return invalid_case(detail_wire);
    const bool has_reaction = (version & kReactionWireFlag) != 0U;
    const bool has_spray = (version & kSprayWireFlag) != 0U;
    if (evaporation_wire && !has_spray) return invalid_case(detail_wire);
    version &= ~(kReactionWireFlag | kSprayWireFlag);
    if ((version != kLegacyWireVersion &&
         version != kLegacyPressureAlgorithmWireVersion &&
         version != kWireVersion &&
         version != kPressureAlgorithmWireVersion &&
         version != kSimpleWireVersion &&
         version != kSimplePressureAlgorithmWireVersion &&
         version != kReferenceAxesWireVersion &&
         version != kReferenceAxesPressureAlgorithmWireVersion &&
         version != kReferenceAxesSimpleWireVersion &&
         version != kReferenceAxesSimplePressureAlgorithmWireVersion) ||
        !reader.byte(geometry) ||
        geometry >
            static_cast<std::uint8_t>(GeometryKind::runtime_axes_v1) ||
        (reference_axes_wire(version) !=
         (geometry == static_cast<std::uint8_t>(
                          GeometryKind::runtime_axes_v1))) ||
        !reader.byte(turbulence) ||
        turbulence >
            static_cast<std::uint8_t>(TurbulenceKind::smagorinsky) ||
        !reader.byte(pressure_reference) ||
        (pressure_reference & ~0x10) >
            static_cast<std::uint8_t>(PressureReferenceKind::closed_mass)) {
      return invalid_case(detail_wire);
    }

    ValidatedModel model;
    model.time.convective_cfl_definition=static_cast<ConvectiveCflDefinition>(cfl_definition);
    model.solver.coupling = simple_wire(version) ? CouplingKind::simple
                                                  : CouplingKind::piso;
    model.mesh.kind = static_cast<GeometryKind>(geometry);
    model.turbulence = static_cast<TurbulenceKind>(turbulence);
    if (smagorinsky_wire != (model.turbulence == TurbulenceKind::smagorinsky))
      return invalid_case(detail_wire);
    model.smagorinsky_coefficient = smagorinsky_coefficient;
    model.pressure_reference =
        static_cast<PressureReferenceKind>(pressure_reference & ~0x10);
    if ((pressure_reference & 0x10) &&
        (!reader.real(model.thermophysics.fixed_pressure_pa) ||
         !std::isfinite(model.thermophysics.fixed_pressure_pa) ||
         model.thermophysics.fixed_pressure_pa <= 0)) return invalid_case(detail_wire);
    if (!reader.real3(model.mesh.lower) || !reader.real3(model.mesh.upper) ||
        !ordered_domain(model.mesh.lower, model.mesh.upper) ||
        !reader.byte(has_exact_cells) || has_exact_cells > 1U) {
      return invalid_case(detail_wire);
    }
    model.mesh.has_exact_cells = has_exact_cells != 0U;
    if (model.mesh.has_exact_cells &&
        (!reader.i32(model.mesh.exact_cells.x) ||
         !reader.i32(model.mesh.exact_cells.y) ||
         !reader.i32(model.mesh.exact_cells.z) ||
         model.mesh.exact_cells.x <= 0 || model.mesh.exact_cells.y <= 0 ||
         model.mesh.exact_cells.z <= 0)) {
      return invalid_case(detail_wire);
    }
    if (!reader.byte(has_base_spacing) || has_base_spacing > 1U) {
      return invalid_case(detail_wire);
    }
    model.mesh.has_base_spacing = has_base_spacing != 0U;
    if (model.mesh.has_base_spacing &&
        (!reader.real3(model.mesh.base_spacing) ||
         model.mesh.base_spacing.x <= 0.0 || model.mesh.base_spacing.y <= 0.0 ||
         model.mesh.base_spacing.z <= 0.0)) {
      return invalid_case(detail_wire);
    }
    if (!reader.real3(model.mesh.minimum_spacing) ||
        model.mesh.minimum_spacing.x <= 0.0 ||
        model.mesh.minimum_spacing.y <= 0.0 ||
        model.mesh.minimum_spacing.z <= 0.0 ||
        !reader.real(model.mesh.max_growth_ratio) ||
        model.mesh.max_growth_ratio < 1.0 || !reader.u16(focus_count) ||
        focus_count > detail::kMaxFocusRegions) {
      return invalid_case(detail_wire);
    }
    model.mesh.focus_regions.reserve(focus_count);
    for (std::uint16_t index = 0U; index < focus_count; ++index) {
      FocusRegionSpec focus;
      if (!reader.real3(focus.lower) || !reader.real3(focus.upper) ||
          !reader.real3(focus.target_spacing) ||
          !ordered_domain(focus.lower, focus.upper) ||
          !componentwise_at_least(focus.lower, model.mesh.lower) ||
          !componentwise_at_most(focus.upper, model.mesh.upper) ||
          focus.target_spacing.x <= 0.0 || focus.target_spacing.y <= 0.0 ||
          focus.target_spacing.z <= 0.0 ||
          !componentwise_at_least(focus.target_spacing,
                                  model.mesh.minimum_spacing) ||
          (model.mesh.has_base_spacing &&
           !componentwise_at_most(focus.target_spacing,
                                  model.mesh.base_spacing))) {
        return invalid_case(detail_wire);
      }
      model.mesh.focus_regions.push_back(focus);
    }
    if (!std::is_sorted(model.mesh.focus_regions.begin(),
                        model.mesh.focus_regions.end(), focus_less) ||
        std::adjacent_find(model.mesh.focus_regions.begin(),
                           model.mesh.focus_regions.end(), same_focus) !=
            model.mesh.focus_regions.end() ||
        !reader.u64(model.mesh.limits.max_global_cells) ||
        !reader.u64(model.mesh.limits.max_memory_bytes_per_rank) ||
        model.mesh.limits.max_global_cells == 0U ||
        model.mesh.limits.max_memory_bytes_per_rank == 0U) {
      return invalid_case(detail_wire);
    }
    if (reference_axes_wire(version)) {
      std::string path;
      fs::path parsed;
      if (!reader.text(path) || !valid_direct_name(path, ".dat", parsed)) {
        return invalid_case(detail_wire);
      }
      model.mesh.axes_file = std::move(parsed);
      const std::array<std::int32_t, 3U> cells{
          model.mesh.exact_cells.x, model.mesh.exact_cells.y,
          model.mesh.exact_cells.z};
      for (std::size_t axis = 0U;
           axis < model.mesh.runtime_faces.size(); ++axis) {
        std::uint64_t count = 0U;
        if (cells[axis] <= 0 || !reader.u64(count) ||
            count != static_cast<std::uint64_t>(cells[axis]) + 1U ||
            count > detail::kMaxWireBytes / sizeof(double)) {
          return invalid_case(detail_wire);
        }
        auto& faces = model.mesh.runtime_faces[axis];
        faces.resize(static_cast<std::size_t>(count));
        for (double& coordinate : faces) {
          if (!reader.real(coordinate)) {
            return invalid_case(detail_wire);
          }
        }
      }
    }
    for (BoundaryFaceSpec& face : model.boundaries) {
      if (!read_boundary(reader, face)) {
        return invalid_case(detail_wire);
      }
    }
    if (!read_transported_scalars(reader, model.transported_scalars) ||
        !read_solver(reader, model.solver,
                     pressure_algorithm_wire(version)) ||
        !read_schemes(reader, model.schemes) ||
        !read_time(reader, model.time) ||
        !read_thermophysics(reader, version, model.thermophysics) ||
        !reader.u16(data_count) || data_count > detail::kMaxReferencedFiles ||
        !reader.byte(has_stl) || has_stl > 1U || !reader.byte(fluid_side) ||
        fluid_side > static_cast<std::uint8_t>(ImmersedFluidSide::inside) ||
        ((version != kLegacyWireVersion &&
          version != kLegacyPressureAlgorithmWireVersion) &&
         (!reader.byte(reconstruction_policy) ||
          reconstruction_policy > static_cast<std::uint8_t>(
                                      IbmReconstructionPolicy::adaptive_order))) ||
        (has_stl == 0U && fluid_side != 0U) ||
        (has_stl == 0U && reconstruction_policy != 0U) ||
        static_cast<std::size_t>(data_count) +
                (has_stl != 0U ? 1U : 0U) +
                (reference_axes_wire(version) ? 2U : 1U) >
            detail::kMaxReferencedFiles) {
      return invalid_case(detail_wire);
    }
    if (!valid_canonical_mesh(model.mesh)) {
      return invalid_case(detail_wire);
    }
    model.data_files.reserve(data_count);
    for (std::uint16_t index = 0U; index < data_count; ++index) {
      std::string path;
      if (!reader.text(path)) {
        return invalid_case(detail_wire);
      }
      fs::path parsed;
      if (!valid_direct_name(path, ".d", parsed)) {
        return invalid_case(detail_wire);
      }
      model.data_files.push_back(std::move(parsed));
    }
    if (has_stl != 0U) {
      std::string path;
      fs::path parsed;
      if (!reader.text(path) || !valid_direct_name(path, ".stl", parsed)) {
        return invalid_case(detail_wire);
      }
      model.immersed_boundary = ImmersedBoundarySpec{
          std::move(parsed), static_cast<ImmersedFluidSide>(fluid_side),
          static_cast<IbmReconstructionPolicy>(reconstruction_policy)};
    }
    if (has_reaction) {
      auto& r = model.reaction;
      std::uint8_t mode{}, representation{};
      std::string mechanism_file;
      if (!reader.byte(mode) || !reader.byte(representation) ||
          !reader.text(r.mechanism_sha256) || !reader.text(r.phase) || !reader.text(mechanism_file) ||
          !reader.real(r.analytic_rate_s) || !reader.real(r.analytic_cp_j_per_kg_k) ||
          !reader.real(r.relative_tolerance) || !reader.real(r.absolute_tolerance) ||
          !reader.u32(r.maximum_internal_steps) || !reader.real(r.mixing_c_z) ||
          !reader.real(r.turbulent_schmidt)) return invalid_case(detail_wire);
      r.mode = static_cast<ReactionMode>(mode);
      r.representation = static_cast<ReactionSpec::Representation>(representation);
      r.mechanism_file = std::move(mechanism_file);
      if (r.mode == ReactionMode::esf_tpdf) {
        r.esf.emplace(); auto& e = *r.esf;
        std::uint32_t count{}, sign{}; std::uint8_t tcr_mode{};
        if (!reader.u32(e.fields) || !reader.u64(e.seed) || !reader.u32(count) || count > 1024) return invalid_case(detail_wire);
        e.initial_species_offsets.resize(count);
        for (double& v : e.initial_species_offsets) if (!reader.real(v)) return invalid_case(detail_wire);
        if (!reader.byte(tcr_mode) || !reader.u32(count) || count > 255) return invalid_case(detail_wire);
        if((tcr_mode & 0x30)==0x30)return invalid_case(detail_wire);
        e.tcr.model = (tcr_mode & 0x20) ? TcrModel::dyn711_v1 :
            (tcr_mode & 0x10) ? TcrModel::cdphyso_dynamic_v1 : TcrModel::reactant_root_v1;
        e.tcr.mode = static_cast<TcrMode>(tcr_mode & ~0x30);
        e.tcr.reactants.resize(count);
        for (auto& name : e.tcr.reactants) if (!reader.text(name)) return invalid_case(detail_wire);
        if (!reader.u32(count) || count > 255) return invalid_case(detail_wire);
        e.tcr.progress_weights.resize(count);
        for (double& v : e.tcr.progress_weights) if (!reader.real(v)) return invalid_case(detail_wire);
        if (!reader.u32(sign) || sign > 2 || !reader.real(e.tcr.weak_rate_threshold)) return invalid_case(detail_wire);
        e.tcr.initialization_sign = int(sign) - 1;
        if (dynamic_tcr_model(e.tcr.model) && !reader.text(e.tcr.fuel))
          return invalid_case(detail_wire);
        if (e.tcr.model == TcrModel::dyn711_v1 &&
            (!reader.text(e.tcr.mixture_fraction) || !reader.real(e.tcr.oxidizer_oxygen_mass_fraction)))
          return invalid_case(detail_wire);
      }
      if (r.mode == ReactionMode::none || !detail::valid_reaction_spec(r) ||
          std::size_t(data_count) + (has_stl ? 1U : 0U) + (reference_axes_wire(version) ? 2U : 1U) +
          (r.representation == ReactionSpec::Representation::direct_cantera ? 1U : 0U) > detail::kMaxReferencedFiles)
        return invalid_case(detail_wire);
    }
    if (has_spray) {
      model.spray.emplace();
      if (!detail::read_spray(reader, *model.spray))
        return invalid_case(detail_wire);
      model.spray->evaporation = static_cast<spray::EvaporationModel>(evaporation);
    }
    if (patch_wire) {
      std::uint8_t marker_geometry = 0U;
      std::uint8_t has_inlets = 0U;
      if (!reader.byte(marker_geometry) || marker_geometry > 1U)
        return invalid_case(detail_wire);
      if (marker_geometry != 0U) {
        std::string path;
        fs::path parsed;
        if (!model.immersed_boundary || !model.mesh.has_exact_cells ||
            !reader.text(path) || !valid_direct_name(path, ".d", parsed) ||
            !reader.u64(model.immersed_boundary->marker_fingerprint) ||
            model.immersed_boundary->marker_fingerprint == 0U)
          return invalid_case(detail_wire);
        model.immersed_boundary->marker_file = std::move(parsed);
      }
      if (!reader.byte(has_inlets) || has_inlets > 1U ||
          (marker_geometry == 0U && has_inlets == 0U))
        return invalid_case(detail_wire);
      if (has_inlets != 0U) {
        model.patch_inlets.emplace();
        if (!read_patch_inlets(reader, *model.patch_inlets) ||
            !valid_patch_inlets(model))
          return invalid_case(detail_wire);
      }
      if (static_cast<std::size_t>(data_count) + marker_geometry + has_inlets +
          (has_stl != 0U ? 1U : 0U) + (reference_axes_wire(version) ? 2U : 1U) >
          detail::kMaxReferencedFiles)
        return invalid_case(detail_wire);
    }
    if (!reader.u64(model.fingerprint) || model.fingerprint == 0U ||
        (model.time.scheme == TimeScheme::cn_be &&
         (!reader.u64(model.legacy_time_fingerprint) ||
          model.legacy_time_fingerprint == 0U ||
          model.legacy_time_fingerprint == model.fingerprint)) ||
        !read_cold_stopping(reader, model) ||
        (cfl_band_wire && !read_cfl_band(reader, model.time)) ||
        !unique_reference_paths(model) ||
        model.data_files.size() + (model.spray ? 1U : 0U) +
                (model.patch_inlets ? 1U : 0U) +
                (model.immersed_boundary && model.immersed_boundary->marker_file ? 1U : 0U) +
                (model.reaction.representation ==
                         ReactionSpec::Representation::direct_cantera
                     ? 1U
                     : 0U) +
                (model.immersed_boundary ? 1U : 0U) +
                (reference_axes_wire(version) ? 2U : 1U) >
            detail::kMaxReferencedFiles ||
        !reader.finished()) {
      return invalid_case(detail_wire);
    }
    model.solver.reference_outer_iterations = reference_outer_iterations;
    if (reference_outer_iterations != 0U && model.time.scheme != TimeScheme::cn_be)
      return invalid_case(detail_wire);
    model.solver.coupling = effective_coupling(model.time.scheme, model.solver.coupling);
    out = std::move(model);
    return {};
  } catch (...) {
    return {StatusCode::allocation_failure, detail_wire};
  }
}

Status compile_on_root(const fs::path& case_root, int rank,
                       ValidatedModel& model,
                       std::vector<std::uint8_t>& payload,
                       PlanFingerprint* transport_base = nullptr,
                       const std::array<BoundaryFaceSpec, 6U>* fingerprint_boundaries = nullptr,
                       const SolverSpec* fingerprint_solver = nullptr,
                       const ReactionSpec* fingerprint_reaction = nullptr) {
  try {
    std::error_code error;
    const fs::path canonical_root = fs::canonical(case_root, error);
    if (error) {
      return invalid_case(detail_case_root);
    }
    UniqueFd root_descriptor(::open(canonical_root.c_str(),
                                    O_RDONLY | O_CLOEXEC | O_DIRECTORY |
                                        O_NOFOLLOW | O_NONBLOCK | O_NOCTTY));
    struct stat root_metadata {};
    if (!root_descriptor ||
        ::fstat(root_descriptor.get(), &root_metadata) != 0 ||
        !S_ISDIR(root_metadata.st_mode)) {
      return invalid_case(detail_case_root);
    }

    UniqueFd json_descriptor;
    struct stat json_metadata {};
    const Status json_open =
        open_regular_at(root_descriptor.get(), fs::path{"case.json"}, rank,
                        detail_case_json, detail_case_json, json_descriptor,
                        json_metadata);
    if (!json_open) {
      return json_open;
    }
    std::string json;
    const Status json_read =
        read_bounded_text(json_descriptor, json_metadata,
                          detail::kMaxJsonBytes, detail_case_json,
                          detail_json_too_large, json);
    if (!json_read) {
      return json_read;
    }

    yyjson_read_err read_error{};
    Document document(yyjson_read_opts(json.data(), json.size(), 0U, nullptr,
                                       &read_error));
    if (document.get() == nullptr) {
      if (read_error.code == YYJSON_READ_ERROR_MEMORY_ALLOCATION) {
        return {StatusCode::allocation_failure, detail_json_syntax};
      }
      return invalid_case(detail_json_syntax);
    }
    yyjson_val* root = yyjson_doc_get_root(document.get());
    if (has_duplicate_keys(root, 0U)) {
      return invalid_case(detail_json_duplicate_key);
    }
    if (!root_has_case_keys(root)) {
      return invalid_case(detail_json_schema);
    }

    yyjson_val* schema_version = yyjson_obj_get(root, "schema_version");
    if (!yyjson_is_uint(schema_version) ||
        yyjson_get_uint(schema_version) != 1U ||
        !equals(string_value(root, "units"), "SI")) {
      return invalid_case(detail_json_value);
    }

    yyjson_val* mesh = yyjson_obj_get(root, "mesh");
    yyjson_val* flow = yyjson_obj_get(root, "flow");
    yyjson_val* solver = yyjson_obj_get(root, "solver");
    yyjson_val* boundaries = yyjson_obj_get(root, "boundaries");
    yyjson_val* schemes = yyjson_obj_get(root, "schemes");
    yyjson_val* turbulence = yyjson_obj_get(root, "turbulence");
    yyjson_val* time = yyjson_obj_get(root, "time");
    yyjson_val* transported_scalars =
        yyjson_obj_get(root, "transported_scalars");
    yyjson_val* thermophysics = yyjson_obj_get(root, "thermophysics");
    const auto geometry_text = string_value(mesh, "kind");
    const bool reference_axes_schema =
        (geometry_text && format_name(*geometry_text,"runtime_axes_v1"));
    const bool mesh_schema =
        reference_axes_schema
            ? object_has_exact_keys(
                  mesh,
                  {"kind", "axes_file", "domain", "exact_cells",
                   "base_spacing", "minimum_spacing", "max_growth_ratio",
                   "focus_regions", "limits", "data_files",
                   "immersed_boundary"})
            : object_has_exact_keys(
                  mesh,
                  {"kind", "domain", "exact_cells", "base_spacing",
                   "minimum_spacing", "max_growth_ratio", "focus_regions",
                   "limits", "data_files", "immersed_boundary"});
    if (!mesh_schema ||
        !(object_has_exact_keys(flow,{"model", "pressure_reference", "reacting"}) ||
          object_has_exact_keys(flow,{"model", "pressure_reference", "reacting", "thermodynamic_pressure_pa"})) ||
        !(object_has_exact_keys(solver,
                                {"coupling", "pressure_correctors"}) ||
          object_has_exact_keys(
              solver,
              {"coupling", "pressure_correctors", "pressure_linear",
               "terminal_tolerances"}) ||
          object_has_exact_keys(solver,
              {"coupling", "pressure_correctors", "pressure_linear",
               "terminal_tolerances", "cold_stopping"}) ||
          object_has_exact_keys(solver,
              {"coupling", "pressure_correctors", "pressure_linear",
               "terminal_tolerances", "reference_outer_iterations"}) ||
          object_has_exact_keys(solver,
              {"coupling", "pressure_correctors", "pressure_linear",
               "terminal_tolerances", "cold_stopping", "reference_outer_iterations"})) ||
        !object_has_exact_keys(boundaries,
                               {"x_min", "x_max", "y_min", "y_max",
                                "z_min", "z_max"}) ||
        !object_has_exact_keys(thermophysics, {"data_file"}) ||
        !yyjson_is_arr(transported_scalars) ||
        yyjson_arr_size(transported_scalars) > kMaxTransportedScalars ||
        (turbulence != nullptr &&
         !object_has_exact_keys(turbulence, {"model"}) &&
         !object_has_exact_keys(turbulence, {"model", "coefficient"}))) {
      return invalid_case(detail_json_schema);
    }

    yyjson_val* domain = yyjson_obj_get(mesh, "domain");
    yyjson_val* limits = yyjson_obj_get(mesh, "limits");
    yyjson_val* focus_regions = yyjson_obj_get(mesh, "focus_regions");
    if (!object_has_exact_keys(domain, {"lower", "upper"}) ||
        !object_has_exact_keys(
            limits, {"max_global_cells", "max_memory_bytes_per_rank"}) ||
        !yyjson_is_arr(focus_regions) ||
        yyjson_arr_size(focus_regions) > detail::kMaxFocusRegions) {
      return invalid_case(detail_json_schema);
    }

    const auto turbulence_text =
        turbulence == nullptr
            ? std::optional<std::string_view>{"vreman_wall_function"}
            : string_value(turbulence, "model");
    const auto pressure_reference_text =
        string_value(flow, "pressure_reference");
    const auto coupling_text = string_value(solver, "coupling");
    if (!geometry_text || !turbulence_text || !pressure_reference_text ||
        !coupling_text ||
        !parse_geometry(*geometry_text, model.mesh.kind) ||
        !parse_turbulence(*turbulence_text, model.turbulence) ||
        !parse_pressure_reference(*pressure_reference_text,
                                  model.pressure_reference) ||
        !equals(string_value(flow, "model"),
                "single_phase_low_mach_compressible")) {
      return invalid_case(detail_json_value);
    }
    double fixed_pressure_pa{};
    if (yyjson_obj_get(flow,"thermodynamic_pressure_pa") &&
        (!finite_real(yyjson_obj_get(flow,"thermodynamic_pressure_pa"),fixed_pressure_pa) ||
         fixed_pressure_pa <= 0 || model.pressure_reference != PressureReferenceKind::boundary_absolute))
      return invalid_case(detail_json_value);
    if (turbulence && yyjson_obj_get(turbulence, "coefficient")) {
      if (model.turbulence != TurbulenceKind::smagorinsky ||
          !finite_real(yyjson_obj_get(turbulence, "coefficient"), model.smagorinsky_coefficient) ||
          model.smagorinsky_coefficient < 0.0)
        return invalid_case(detail_json_value);
    }
    if (*coupling_text == "PISO" || *coupling_text == "CN_BE") {
      model.solver.coupling = CouplingKind::piso;
    } else if (*coupling_text == "SIMPLE") {
      model.solver.coupling = CouplingKind::simple;
    } else if (*coupling_text == "outer_corrected") {
      model.solver.coupling = CouplingKind::outer_corrected;
    } else {
      return invalid_case(detail_json_value);
    }
    constexpr std::array<std::string_view, 6U> face_names{
        "x_min", "x_max", "y_min", "y_max", "z_min", "z_max"};
    for (std::size_t face = 0U; face < face_names.size(); ++face) {
      if (!parse_boundary_face(
              yyjson_obj_getn(boundaries, face_names[face].data(),
                              face_names[face].size()),
              model.boundaries[face])) {
        return invalid_case(detail_json_value);
      }
    }
    if ((yyjson_obj_get(solver, "pressure_linear") != nullptr &&
         !parse_solver_controls(solver, model.solver)) ||
        !parse_schemes_object(schemes, model.schemes) ||
        !parse_time_object(time, model.time) ||
        ((*coupling_text == "CN_BE" || *coupling_text == "outer_corrected") &&
         model.time.scheme != TimeScheme::cn_be)) {
      return invalid_case(detail_json_value);
    }
    model.solver.coupling = effective_coupling(model.time.scheme, model.solver.coupling);

    model.transported_scalars.reserve(
        yyjson_arr_size(transported_scalars));
    std::size_t scalar_index = 0U;
    std::size_t scalar_maximum = 0U;
    yyjson_val* scalar_value = nullptr;
    yyjson_arr_foreach(transported_scalars, scalar_index, scalar_maximum,
                       scalar_value) {
      if (!object_has_exact_keys(
              scalar_value,
              {"stable_name", "role", "molecular_schmidt",
               "turbulent_schmidt"})) {
        return invalid_case(detail_json_schema);
      }
      const auto stable_name = string_value(scalar_value, "stable_name");
      const auto role = string_value(scalar_value, "role");
      TransportedScalarSpec scalar;
      if (!stable_name || !role || !valid_name(*stable_name) ||
          !parse_transported_scalar_role(*role, scalar.role) ||
          !finite_real(yyjson_obj_get(scalar_value, "molecular_schmidt"),
                       scalar.molecular_schmidt) ||
          !finite_real(yyjson_obj_get(scalar_value, "turbulent_schmidt"),
                       scalar.turbulent_schmidt)) {
        return invalid_case(detail_json_value);
      }
      scalar.stable_name.assign(stable_name->data(), stable_name->size());
      model.transported_scalars.push_back(std::move(scalar));
    }
    if (!valid_transported_scalars(model.transported_scalars)) {
      return invalid_case(detail_json_value);
    }

    if (!parse_real3(yyjson_obj_get(domain, "lower"), model.mesh.lower) ||
        !parse_real3(yyjson_obj_get(domain, "upper"), model.mesh.upper) ||
        !ordered_domain(model.mesh.lower, model.mesh.upper) ||
        !parse_optional_cells(yyjson_obj_get(mesh, "exact_cells"),
                              model.mesh.has_exact_cells,
                              model.mesh.exact_cells) ||
        !parse_optional_positive_real3(yyjson_obj_get(mesh, "base_spacing"),
                                       model.mesh.has_base_spacing,
                                       model.mesh.base_spacing) ||
        !parse_positive_real3(yyjson_obj_get(mesh, "minimum_spacing"),
                              model.mesh.minimum_spacing) ||
        !finite_real(yyjson_obj_get(mesh, "max_growth_ratio"),
                     model.mesh.max_growth_ratio) ||
        model.mesh.max_growth_ratio < 1.0) {
      return invalid_case(detail_json_value);
    }
    if (reference_axes_schema) {
      model.mesh.lower = {
          reference_binary32_value(model.mesh.lower.x),
          reference_binary32_value(model.mesh.lower.y),
          reference_binary32_value(model.mesh.lower.z)};
      model.mesh.upper = {
          reference_binary32_value(model.mesh.upper.x),
          reference_binary32_value(model.mesh.upper.y),
          reference_binary32_value(model.mesh.upper.z)};
    }

    yyjson_val* max_global_cells = yyjson_obj_get(limits, "max_global_cells");
    yyjson_val* max_memory_bytes =
        yyjson_obj_get(limits, "max_memory_bytes_per_rank");
    if (!yyjson_is_uint(max_global_cells) ||
        !yyjson_is_uint(max_memory_bytes) ||
        yyjson_get_uint(max_global_cells) == 0U ||
        yyjson_get_uint(max_memory_bytes) == 0U) {
      return invalid_case(detail_json_value);
    }
    model.mesh.limits.max_global_cells = yyjson_get_uint(max_global_cells);
    model.mesh.limits.max_memory_bytes_per_rank =
        yyjson_get_uint(max_memory_bytes);

    model.mesh.focus_regions.reserve(yyjson_arr_size(focus_regions));
    std::size_t focus_index = 0U;
    std::size_t focus_maximum = 0U;
    yyjson_val* focus_value = nullptr;
    yyjson_arr_foreach(focus_regions, focus_index, focus_maximum, focus_value) {
      if (!object_has_exact_keys(
              focus_value, {"lower", "upper", "target_spacing"})) {
        return invalid_case(detail_json_schema);
      }
      FocusRegionSpec focus;
      if (!parse_real3(yyjson_obj_get(focus_value, "lower"), focus.lower) ||
          !parse_real3(yyjson_obj_get(focus_value, "upper"), focus.upper) ||
          !ordered_domain(focus.lower, focus.upper) ||
          !parse_positive_real3(yyjson_obj_get(focus_value, "target_spacing"),
                                focus.target_spacing) ||
          !componentwise_at_least(focus.target_spacing,
                                  model.mesh.minimum_spacing)) {
        return invalid_case(detail_json_value);
      }
      const Real3 clipped_lower{
          std::max(focus.lower.x, model.mesh.lower.x),
          std::max(focus.lower.y, model.mesh.lower.y),
          std::max(focus.lower.z, model.mesh.lower.z)};
      const Real3 clipped_upper{
          std::min(focus.upper.x, model.mesh.upper.x),
          std::min(focus.upper.y, model.mesh.upper.y),
          std::min(focus.upper.z, model.mesh.upper.z)};
      if (!ordered_domain(clipped_lower, clipped_upper)) {
        return invalid_case(detail_json_value);
      }
      focus.lower = clipped_lower;
      focus.upper = clipped_upper;
      model.mesh.focus_regions.push_back(focus);
    }
    std::sort(model.mesh.focus_regions.begin(), model.mesh.focus_regions.end(),
              focus_less);
    model.mesh.focus_regions.erase(
        std::unique(model.mesh.focus_regions.begin(),
                    model.mesh.focus_regions.end(), same_focus),
        model.mesh.focus_regions.end());
    const GeometryKind parsed_geometry = model.mesh.kind;
    if (parsed_geometry == GeometryKind::runtime_axes_v1) {
      model.mesh.kind = GeometryKind::tensor_stretched;
    }
    const bool valid_mesh_controls = valid_canonical_mesh(model.mesh);
    model.mesh.kind = parsed_geometry;
    if (!valid_mesh_controls) {
      return invalid_case(detail_json_value);
    }

    yyjson_val* reacting = yyjson_obj_get(flow, "reacting");
    yyjson_val* pressure_correctors =
        yyjson_obj_get(solver, "pressure_correctors");
    auto* reaction = yyjson_obj_get(root, "reaction");
    if (!yyjson_is_bool(reacting) ||
        (yyjson_get_bool(reacting) != (reaction != nullptr)) ||
        (reaction != nullptr && !parse_reaction(reaction, model.reaction)) ||
        !yyjson_is_uint(pressure_correctors) ||
        yyjson_get_uint(pressure_correctors) != 2U) {
      return invalid_case(detail_json_value);
    }

    if (auto *spray = yyjson_obj_get(root, "spray")) {
      model.spray.emplace();
      if (!parse_spray(spray, *model.spray))
        return invalid_case(detail_json_value);
    }
    yyjson_val* data_files = yyjson_obj_get(mesh, "data_files");
    yyjson_val* immersed_boundary =
        yyjson_obj_get(mesh, "immersed_boundary");
    yyjson_val* stl_file = nullptr;
    std::optional<std::string_view> marker_file;
    ImmersedFluidSide immersed_fluid_side{ImmersedFluidSide::outside};
    IbmReconstructionPolicy immersed_reconstruction_policy{
        IbmReconstructionPolicy::strict_quadratic};
    if (!yyjson_is_null(immersed_boundary)) {
      const bool legacy_strict = object_has_exact_keys(
          immersed_boundary, {"stl_file", "fluid_side"});
      const bool explicit_policy = object_has_exact_keys(
          immersed_boundary,
          {"stl_file", "fluid_side", "reconstruction_policy"});
      const bool imported_geometry = object_has_exact_keys(
          immersed_boundary, {"stl_file", "fluid_side", "reconstruction_policy",
                              "geometry_mode", "marker_file"});
      if (!legacy_strict && !explicit_policy && !imported_geometry) {
        return invalid_case(detail_json_schema);
      }
      if (imported_geometry) {
        const auto mode = string_value(immersed_boundary, "geometry_mode");
        marker_file = string_value(immersed_boundary, "marker_file");
        if (!mode || *mode != "imported_cartesian_marker" || !marker_file ||
            !model.mesh.has_exact_cells)
          return invalid_case(detail_json_value);
      }
      stl_file = yyjson_obj_get(immersed_boundary, "stl_file");
      const auto fluid_side = string_value(immersed_boundary, "fluid_side");
      const auto reconstruction_policy =
          string_value(immersed_boundary, "reconstruction_policy");
      if (!yyjson_is_str(stl_file) || !fluid_side.has_value() ||
          !parse_immersed_fluid_side(*fluid_side, immersed_fluid_side) ||
          ((explicit_policy || imported_geometry) &&
           (!reconstruction_policy.has_value() ||
            !parse_ibm_reconstruction_policy(
                *reconstruction_policy,
                immersed_reconstruction_policy)))) {
        return invalid_case(detail_json_value);
      }
    }
    const auto thermophysical_file =
        string_value(thermophysics, "data_file");
    const auto axes_file = reference_axes_schema
                               ? string_value(mesh, "axes_file")
                               : std::optional<std::string_view>{};
    if (!yyjson_is_arr(data_files) ||
        !thermophysical_file.has_value() ||
        (reference_axes_schema && !axes_file.has_value()) ||
        (!yyjson_is_null(immersed_boundary) && !yyjson_is_str(stl_file))) {
      return invalid_case(detail_reference_count);
    }
    const std::size_t data_file_count = yyjson_arr_size(data_files);
    const std::size_t total_reference_count =
        data_file_count + (marker_file ? 1U : 0U) +
        (yyjson_obj_get(root, "patch_inlets") != nullptr ? 1U : 0U) + (model.spray ? 1U : 0U) +
        (model.reaction.representation ==
                 ReactionSpec::Representation::direct_cantera
             ? 1U
             : 0U) +
        (yyjson_is_str(stl_file) ? 1U : 0U) + (reference_axes_schema ? 2U : 1U);
    if (data_file_count > detail::kMaxReferencedFiles ||
        total_reference_count > detail::kMaxReferencedFiles) {
      return invalid_case(detail_reference_count);
    }

    std::set<std::pair<dev_t, ino_t>> referenced_targets;
    std::string axes_source;
    if (reference_axes_schema) {
      fs::path relative;
      UniqueFd descriptor;
      struct stat metadata {};
      const Status opened = open_direct_file(
          root_descriptor.get(), *axes_file, ".dat", rank, relative,
          descriptor, metadata);
      if (!opened) {
        return opened;
      }
      if (!referenced_targets
               .insert(std::make_pair(metadata.st_dev, metadata.st_ino))
               .second) {
        return invalid_case(detail_reference_path);
      }
      const Status read = read_bounded_text(
          descriptor, metadata, detail::kMaxReferencedFileBytes,
          detail_reference_missing, detail_reference_too_large, axes_source);
      if (!read) {
        return read;
      }
      const Status parsed = parse_reference_runtime_axes(
          axes_source, model.mesh, model.mesh.runtime_faces);
      if (!parsed) {
        return parsed;
      }
      model.mesh.axes_file = std::move(relative);
      model.mesh.lower = {model.mesh.runtime_faces[0U].front(),
                          model.mesh.runtime_faces[1U].front(),
                          model.mesh.runtime_faces[2U].front()};
      model.mesh.upper = {model.mesh.runtime_faces[0U].back(),
                          model.mesh.runtime_faces[1U].back(),
                          model.mesh.runtime_faces[2U].back()};
      if (!valid_canonical_mesh(model.mesh)) {
        return invalid_case(detail_json_value);
      }
    }

    Hash64 hash;
    // The explicit name preserves the already-executed CN/BE algorithm and
    // its native restart identity. SIMPLE retains its distinct wire contract.
    hash.text(model.solver.coupling == CouplingKind::simple
                  ? kSimpleSemanticContract : kSemanticContract);
    hash_mesh(hash, model.mesh);
    if (reference_axes_schema) {
      hash.text("reference-runtime-axes-source-v1");
      hash.integer(static_cast<std::uint64_t>(axes_source.size()));
      hash.bytes(axes_source.data(), axes_source.size());
    }
    hash.integer(static_cast<std::uint8_t>(model.turbulence));
    if (model.turbulence == TurbulenceKind::smagorinsky)
      hash.real(model.smagorinsky_coefficient);
    hash.integer(static_cast<std::uint8_t>(model.pressure_reference));
    hash_transported_scalars(hash, model.transported_scalars);
    for (const BoundaryFaceSpec& face :
         fingerprint_boundaries ? *fingerprint_boundaries : model.boundaries) {
      hash_boundary(hash, face);
    }
    hash_solver(hash, fingerprint_solver ? *fingerprint_solver : model.solver);
    hash_schemes(hash, model.schemes);
    Hash64 legacy_time_hash = hash;
    const bool cold_method = model.time.scheme == TimeScheme::cn_be;
    if (cold_method) {
      TimeControlSpec legacy_time = model.time;
      legacy_time.scheme = TimeScheme::variable_bdf2;
      hash_time(legacy_time_hash, legacy_time);
    }
    hash_time(hash, model.time);
    // The REFERENCE stopping contract changes this plan, while the explicit
    // BDF migration lane continues to bind exactly the original physical case.
    if (model.solver.cold_stopping) {
      const auto& stopping = *model.solver.cold_stopping;
      hash.text("reference-stopping-v1");
      hash.real(stopping.reference_time);
      hash.real(stopping.momentum);
      hash.real(stopping.enthalpy);
      hash.real(stopping.species);
    }
    if (model.solver.reference_outer_iterations != 0U) {
      hash.text("reference-outer-iterations-v1");
      hash.integer(model.solver.reference_outer_iterations);
    }
    if (cold_method) hash.mirror_remaining(legacy_time_hash);
    hash.integer(static_cast<std::uint16_t>(data_file_count));

    Hash64 physical_hash = hash.detached();
    model.data_files.reserve(data_file_count);
    {
      fs::path relative;
      UniqueFd descriptor;
      struct stat metadata {};
      const Status opened = open_direct_file(
          root_descriptor.get(), *thermophysical_file, ".d", rank, relative,
          descriptor, metadata);
      if (!opened) {
        return opened;
      }
      if (!referenced_targets
               .insert(std::make_pair(metadata.st_dev, metadata.st_ino))
               .second) {
        return invalid_case(detail_reference_path);
      }
      hash.text("thermophysics");
      hash.text(relative.generic_string());
      std::string data;
      const Status read = read_bounded_text(
          descriptor, metadata, detail::kMaxThermophysicalFileBytes,
          detail_reference_missing, detail_reference_too_large, data);
      if (!read) {
        return read;
      }
      hash.integer(static_cast<std::uint64_t>(data.size()));
      hash.bytes(data.data(), data.size());
      ThermophysicalSpec thermophysics;
      const Status parsed =
          detail::parse_thermophysical_text(data, thermophysics);
      if (!parsed) {
        return invalid_case(detail_json_value);
      }
      thermophysics.data_file = std::move(relative);
      thermophysics.fixed_pressure_pa = fixed_pressure_pa;
      if (!detail::valid_thermophysical_spec(thermophysics)) {
        return invalid_case(detail_json_value);
      }
      if (!thermophysics_compatible_with_reference_axes(thermophysics,
                                                    reference_axes_schema)) {
        return invalid_case(detail_json_value);
      }
      const PlanFingerprint thermophysical_fingerprint =
          detail::thermophysical_spec_fingerprint(thermophysics);
      if (thermophysical_fingerprint == 0U) {
        return invalid_case(detail_json_value);
      }
      hash.text("typed-thermophysics");
      hash.integer(thermophysical_fingerprint);
      if (transport_base != nullptr) {
        ThermophysicalSpec physical = thermophysics;
        for (auto &species : physical.species) {
          species.transport_law = TransportLaw::constant;
          species.viscosity_reference = species.conductivity = 1.0;
          species.transport_reference_temperature = species.sutherland_temperature =
              species.prandtl = species.critical_temperature = species.critical_pressure = 0.0;
        }
        const auto identity = detail::thermophysical_spec_fingerprint(physical);
        if (identity == 0U) return invalid_case(detail_json_value);
        physical_hash.text("thermodynamics-without-transport-v1");
        physical_hash.text(thermophysics.data_file.generic_string());
        physical_hash.integer(identity);
        // Existing plan and BDF migration hashes keep their exact byte lanes.
        // Only this separate witness omits the molecular transport parameters.
        if (cold_method) legacy_time_hash.mirror_remaining(physical_hash);
        else hash.mirror_remaining(physical_hash);
      }
      model.thermophysics = std::move(thermophysics);
    }
    std::size_t index = 0U;
    std::size_t maximum = 0U;
    yyjson_val* file_value = nullptr;
    yyjson_arr_foreach(data_files, index, maximum, file_value) {
      if (!yyjson_is_str(file_value)) {
        return invalid_case(detail_reference_path);
      }
      const std::string_view name{yyjson_get_str(file_value),
                                  yyjson_get_len(file_value)};
      fs::path relative;
      UniqueFd descriptor;
      struct stat metadata {};
      const Status opened = open_direct_file(
          root_descriptor.get(), name, ".d", rank, relative, descriptor,
          metadata);
      if (!opened) {
        return opened;
      }
      if (!referenced_targets
               .insert(std::make_pair(metadata.st_dev, metadata.st_ino))
               .second) {
        return invalid_case(detail_reference_path);
      }
      hash.text("data");
      hash.text(relative.generic_string());
      const Status hashed = hash_bounded_file(descriptor, metadata, hash);
      if (!hashed) {
        return hashed;
      }
      model.data_files.push_back(std::move(relative));
    }

    if (yyjson_is_str(stl_file)) {
      const std::string_view name{yyjson_get_str(stl_file),
                                  yyjson_get_len(stl_file)};
      fs::path relative;
      UniqueFd descriptor;
      struct stat metadata {};
      const Status opened = open_direct_file(
          root_descriptor.get(), name, ".stl", rank, relative, descriptor,
          metadata);
      if (!opened) {
        return opened;
      }
      if (!referenced_targets
               .insert(std::make_pair(metadata.st_dev, metadata.st_ino))
               .second) {
        return invalid_case(detail_reference_path);
      }
      hash.text("stl");
      hash.text(relative.generic_string());
      const Status hashed = hash_bounded_file(descriptor, metadata, hash);
      if (!hashed) {
        return hashed;
      }
      model.immersed_boundary =
          ImmersedBoundarySpec{std::move(relative), immersed_fluid_side,
                               immersed_reconstruction_policy};
      hash.integer(static_cast<std::uint8_t>(immersed_fluid_side));
      hash.integer(
          static_cast<std::uint8_t>(immersed_reconstruction_policy));
    } else {
      hash.text("no-immersed-boundary");
    }

    if (model.reaction.mode != ReactionMode::none) {
      const auto& r = fingerprint_reaction ? *fingerprint_reaction : model.reaction;
      hash.text("reaction-case-v1");
      hash.integer(static_cast<std::uint8_t>(r.mode));
      hash.integer(static_cast<std::uint8_t>(r.representation));
      hash.text(r.mechanism_sha256); hash.text(r.phase);
      hash.real(r.analytic_rate_s); hash.real(r.analytic_cp_j_per_kg_k);
      hash.real(r.relative_tolerance); hash.real(r.absolute_tolerance);
      hash.integer(r.maximum_internal_steps); hash.real(r.mixing_c_z);
      hash.real(r.turbulent_schmidt);
      if (r.esf) {
        const auto& e = *r.esf;
        hash.integer(e.fields); hash.integer(e.seed);
        hash.integer(e.initial_species_offsets.size());
        for (double v : e.initial_species_offsets) hash.real(v);
        hash.integer(static_cast<std::uint8_t>(e.tcr.mode));
        if (dynamic_tcr_model(e.tcr.model)) {
          hash.text(e.tcr.model==TcrModel::dyn711_v1 ? "dyn711_v1" : "cdphyso_dynamic_v1");
          hash.text(e.tcr.fuel);
          if(e.tcr.model==TcrModel::dyn711_v1) {
            hash.text(e.tcr.mixture_fraction);hash.real(e.tcr.oxidizer_oxygen_mass_fraction);
          }
        }
        hash.integer(e.tcr.reactants.size());
        for (const auto& name : e.tcr.reactants) hash.text(name);
        hash.integer(e.tcr.progress_weights.size());
        for (double v : e.tcr.progress_weights) hash.real(v);
        hash.integer(e.tcr.initialization_sign + 1); hash.real(e.tcr.weak_rate_threshold);
      }
      if (r.representation == ReactionSpec::Representation::direct_cantera) {
        fs::path relative;
        UniqueFd descriptor;
        struct stat metadata {};
        const auto opened = open_direct_file(root_descriptor.get(), r.mechanism_file.generic_string(),
            ".yaml", rank, relative, descriptor, metadata);
        if (!opened) return opened;
        if (!referenced_targets.insert(std::make_pair(metadata.st_dev, metadata.st_ino)).second)
          return invalid_case(detail_reference_path);
        hash.text(relative.generic_string());
        const auto hashed = hash_bounded_file(descriptor, metadata, hash);
        if (!hashed) return hashed;
      }
    }
    if (model.spray) {
      const auto &spray = *model.spray;
      fs::path relative;
      UniqueFd descriptor;
      struct stat metadata {};
      const auto opened = open_direct_file(
          root_descriptor.get(), spray.liquid_file.generic_string(), ".asset",
          rank, relative, descriptor, metadata);
      if (!opened)
        return opened;
      if (!referenced_targets
               .insert(std::make_pair(metadata.st_dev, metadata.st_ino))
               .second)
        return invalid_case(detail_reference_path);
      std::string content;
      const auto read = read_bounded_text(descriptor, metadata, 65536,
                                          detail_reference_missing,
                                          detail_reference_too_large, content);
      if (!read)
        return read;
      Hash64 liquid;
      liquid.bytes(content.data(), content.size());
      if (liquid.finish() != spray.liquid_fingerprint)
        return invalid_case(detail_json_value);
      detail::hash_spray(hash, spray);
      hash.text(content);
    }
    if (marker_file) {
      fs::path relative;
      UniqueFd descriptor;
      struct stat metadata {};
      const Status opened = open_direct_file(root_descriptor.get(), *marker_file,
          ".d", rank, relative, descriptor, metadata);
      if (!opened) return opened;
      if (!referenced_targets.insert({metadata.st_dev, metadata.st_ino}).second)
        return invalid_case(detail_reference_path);
      const std::uint64_t cells = static_cast<std::uint64_t>(model.mesh.exact_cells.x) *
          model.mesh.exact_cells.y * model.mesh.exact_cells.z;
      if (cells > detail::kMaxReferencedFileBytes || metadata.st_size < 0 ||
          static_cast<std::uint64_t>(metadata.st_size) != cells)
        return invalid_case(detail_json_value);
      std::string marker;
      const Status read = read_bounded_text(descriptor, metadata,
          detail::kMaxReferencedFileBytes, detail_reference_missing,
          detail_reference_too_large, marker);
      if (!read) return read;
      if (marker.size() != cells || std::any_of(marker.begin(), marker.end(),
          [](unsigned char cell) { return cell > 1U; }))
        return invalid_case(detail_json_value);
      Hash64 marker_hash;
      marker_hash.bytes(marker.data(), marker.size());
      model.immersed_boundary->marker_file = std::move(relative);
      model.immersed_boundary->marker_fingerprint = marker_hash.finish();
      hash.text("imported-cartesian-marker-v1");
      hash.text(model.immersed_boundary->marker_file->generic_string());
      hash.integer(model.immersed_boundary->marker_fingerprint);
    }

    if (yyjson_val* input = yyjson_obj_get(root, "patch_inlets")) {
      model.patch_inlets.emplace();
      PatchInletsSpec& inlets = *model.patch_inlets;
      if (!parse_patch_inlets(input, inlets) || !model.mesh.has_exact_cells)
        return invalid_case(detail_json_value);
      UniqueFd descriptor;
      struct stat metadata {};
      fs::path relative;
      const Status opened = open_direct_file(root_descriptor.get(),
          inlets.labels_file.generic_string(), ".d", rank, relative,
          descriptor, metadata);
      if (!opened) return opened;
      if (!referenced_targets.insert({metadata.st_dev, metadata.st_ino}).second)
        return invalid_case(detail_reference_path);
      const std::uint64_t cells = static_cast<std::uint64_t>(model.mesh.exact_cells.x) *
          model.mesh.exact_cells.y * model.mesh.exact_cells.z;
      if (cells > detail::kMaxReferencedFileBytes / 4U || metadata.st_size < 0 ||
          static_cast<std::uint64_t>(metadata.st_size) != cells * 4U)
        return invalid_case(detail_json_value);
      std::string labels;
      const Status read = read_bounded_text(descriptor, metadata,
          detail::kMaxReferencedFileBytes, detail_reference_missing,
          detail_reference_too_large, labels);
      if (!read) return read;
      if (labels.size() != cells * 4U) return invalid_case(detail_json_value);
      Hash64 labels_hash;
      labels_hash.bytes(labels.data(), labels.size());
      inlets.labels_fingerprint = labels_hash.finish();
      if (!valid_patch_inlets(model)) return invalid_case(detail_json_value);
      std::vector<std::uint64_t> positive(inlets.patches.size(), 0U);
      std::vector<std::uint64_t> negative(inlets.patches.size(), 0U);
      for (std::size_t offset = 0U; offset < labels.size(); offset += 4U) {
        std::uint32_t raw = 0U;
        for (unsigned byte = 0U; byte < 4U; ++byte)
          raw |= static_cast<std::uint32_t>(
              static_cast<unsigned char>(labels[offset + byte])) << (8U * byte);
        const std::int64_t label = raw <= INT32_MAX ? raw :
            static_cast<std::int64_t>(raw) - INT64_C(4294967296);
        if (label == 0) continue;
        const std::int64_t magnitude = label < 0 ? -label : label;
        const auto found = std::lower_bound(inlets.patches.begin(), inlets.patches.end(),
            magnitude, [](const PatchInletSpec& patch, std::int64_t value) {
              return patch.label < value;
            });
        if (found == inlets.patches.end() || found->label != magnitude ||
            (label < 0 && !found->immersed))
          return invalid_case(detail_json_value);
        const auto index = static_cast<std::size_t>(found - inlets.patches.begin());
        ++(label > 0 ? positive[index] : negative[index]);
      }
      for (std::size_t index = 0U; index < positive.size(); ++index)
        if (positive[index] == 0U ||
            (inlets.patches[index].immersed && positive[index] != negative[index]))
          return invalid_case(detail_json_value);
      hash.text("patch-inlets-v1");
      hash.text(inlets.labels_file.generic_string());
      hash.integer(inlets.labels_fingerprint);
      for (const PatchInletSpec& patch : inlets.patches) {
        hash.integer(patch.label);
        hash.integer(patch.face);
        hash.integer(static_cast<std::uint8_t>(patch.immersed ? 1U : 0U));
        hash_boundary(hash, patch.boundary);
      }
    }

    model.fingerprint = hash.finish();
    model.legacy_time_fingerprint = cold_method ? legacy_time_hash.finish() : 0U;
    const auto serialized = serialize_model(model, payload);
    if (serialized && transport_base != nullptr) *transport_base = physical_hash.finish();
    return serialized;
  } catch (const std::bad_alloc&) {
    return {StatusCode::allocation_failure, detail_none};
  } catch (...) {
    return invalid_case(detail_case_root);
  }
}

Status bcast_header(std::array<std::uint64_t, 4U>& header, MPI_Comm communicator) {
  if (MPI_Bcast(header.data(), static_cast<int>(header.size()), MPI_UINT64_T, 0,
                communicator) != MPI_SUCCESS) {
    return {StatusCode::mpi_failure, detail_collective};
  }
  return {};
}

}  // namespace

namespace detail {

#if defined(HUNDUN_V04_ENABLE_TEST_ACCESS)
void set_file_open_observer_for_test(FileOpenObserver observer) noexcept {
  g_file_open_observer.store(observer, std::memory_order_relaxed);
}

int last_lowest_failing_rank_for_test() noexcept {
  return g_last_lowest_failing_rank.load(std::memory_order_relaxed);
}

Status serialize_model_for_test(const ValidatedModel& model,
                                std::vector<std::uint8_t>& out) {
  return serialize_model(model, out);
}

Status deserialize_model_for_test(const std::vector<std::uint8_t>& bytes,
                                  ValidatedModel& out) {
  return deserialize_model(bytes, out);
}
#endif

}  // namespace detail

Status CaseCompiler::validate_chemistry_refinement(MPI_Comm communicator,
    const fs::path& source_root, const ValidatedModel& source,
    const fs::path& target_root, const ValidatedModel& target) {
  if (communicator == MPI_COMM_NULL)
    return {StatusCode::invalid_plan, detail_collective};
  const auto eligible=[](const ValidatedModel& source,const ValidatedModel& target) {
    const auto& a=source.reaction;
    const auto& b=target.reaction;
    return source.fingerprint && target.fingerprint &&
      a.mode!=ReactionMode::none && b.mode==a.mode &&
      a.representation==ReactionSpec::Representation::direct_cantera &&
      b.representation==a.representation &&
      b.relative_tolerance<=a.relative_tolerance &&
      b.absolute_tolerance<=a.absolute_tolerance &&
      b.maximum_internal_steps>=a.maximum_internal_steps &&
      (b.relative_tolerance<a.relative_tolerance || b.absolute_tolerance<a.absolute_tolerance);
  };
  const bool supported=eligible(source,target);
  std::array<std::uint64_t,3> minimum{source.fingerprint,target.fingerprint,supported ? 1U : 0U},maximum=minimum;
  if (MPI_Allreduce(MPI_IN_PLACE,minimum.data(),3,MPI_UINT64_T,MPI_MIN,communicator)!=MPI_SUCCESS ||
      MPI_Allreduce(MPI_IN_PLACE,maximum.data(),3,MPI_UINT64_T,MPI_MAX,communicator)!=MPI_SUCCESS)
    return {StatusCode::mpi_failure,detail_collective};
  if (minimum!=maximum || !minimum[2]) return invalid_case(detail_json_value);
  int rank{};
  if (MPI_Comm_rank(communicator,&rank)!=MPI_SUCCESS)
    return {StatusCode::mpi_failure,detail_collective};
  std::array<std::uint64_t,4> header{};
  if (!rank) try {
    ValidatedModel actual_source,actual_target,witness;
    std::vector<std::uint8_t> payload;
    auto status=compile_on_root(source_root,rank,actual_source,payload);
    if (status) status=compile_on_root(target_root,rank,actual_target,payload);
    if (status && (actual_source.fingerprint!=source.fingerprint || actual_target.fingerprint!=target.fingerprint))
      status=invalid_case(detail_json_value);
    if (status && !eligible(actual_source,actual_target)) status=invalid_case(detail_json_value);
    if (status) {
      auto normalized=actual_target.reaction;
      normalized.relative_tolerance=actual_source.reaction.relative_tolerance;
      normalized.absolute_tolerance=actual_source.reaction.absolute_tolerance;
      normalized.maximum_internal_steps=actual_source.reaction.maximum_internal_steps;
      status=compile_on_root(target_root,rank,witness,payload,nullptr,nullptr,nullptr,&normalized);
      if (status && witness.fingerprint!=actual_source.fingerprint)
        status=invalid_case(detail_json_value);
    }
    header[0]=static_cast<std::uint64_t>(status.code);header[1]=status.detail;
  } catch (const std::bad_alloc&) {
    header[0]=static_cast<std::uint64_t>(StatusCode::allocation_failure);header[1]=detail_json_value;
  } catch (...) {
    header[0]=static_cast<std::uint64_t>(StatusCode::invalid_case);header[1]=detail_json_value;
  }
  const auto status=bcast_header(header,communicator);
  if (!status) return status;
  return {static_cast<StatusCode>(header[0]),static_cast<std::uint32_t>(header[1])};
}

Status CaseCompiler::validate_transport_change(MPI_Comm communicator,
    const fs::path& source_root, const ValidatedModel& source,
    const fs::path& target_root, const ValidatedModel& target) {
  if (communicator == MPI_COMM_NULL)
    return {StatusCode::invalid_plan, detail_collective};
  const auto all_law = [](const ValidatedModel &model, TransportLaw law) {
    return !model.thermophysics.species.empty() && std::all_of(
        model.thermophysics.species.begin(), model.thermophysics.species.end(),
        [=](const SpeciesThermophysicalSpec &species) { return species.transport_law == law; });
  };
  const bool transport_change = all_law(source, TransportLaw::sutherland) &&
      all_law(target, TransportLaw::perry);
  bool outlet_change = false;
  for (std::size_t face = 0; face < target.boundaries.size(); ++face) {
    if (source.boundaries[face].flow_kind == BoundaryKind::zero_gradient_mass_outlet &&
        target.boundaries[face].flow_kind == BoundaryKind::pressure_outlet &&
        target.boundaries[face].allow_backflow) {
      outlet_change = true;
    }
  }
  outlet_change &= all_law(source, TransportLaw::perry) &&
      all_law(target, TransportLaw::perry);
  const bool solver_change = source.solver.pressure.algorithm != target.solver.pressure.algorithm;
  const bool supported = source.fingerprint != 0U && target.fingerprint != 0U &&
      source.time.scheme == TimeScheme::cn_be && target.time.scheme == TimeScheme::cn_be &&
      source.reaction.mode == ReactionMode::none && target.reaction.mode == ReactionMode::none &&
      !source.spray && !target.spray && (transport_change || outlet_change || solver_change);
  std::array<std::uint64_t, 3U> minimum{
      source.fingerprint, target.fingerprint, supported ? 1U : 0U}, maximum = minimum;
  if (MPI_Allreduce(MPI_IN_PLACE, minimum.data(), 3, MPI_UINT64_T, MPI_MIN, communicator) != MPI_SUCCESS ||
      MPI_Allreduce(MPI_IN_PLACE, maximum.data(), 3, MPI_UINT64_T, MPI_MAX, communicator) != MPI_SUCCESS)
    return {StatusCode::mpi_failure, detail_collective};
  if (minimum != maximum || minimum[2] == 0U) return invalid_case(detail_json_value);
  int rank = 0;
  if (MPI_Comm_rank(communicator, &rank) != MPI_SUCCESS)
    return {StatusCode::mpi_failure, detail_collective};
  std::array<std::uint64_t, 4U> header{};
  if (rank == 0) {
    ValidatedModel actual_source, actual_target;
    std::vector<std::uint8_t> payload;
    PlanFingerprint source_base{}, target_base{};
    auto status = compile_on_root(source_root, rank, actual_source, payload,
                                  transport_change ? &source_base : nullptr);
    if (status) status = compile_on_root(target_root, rank, actual_target, payload,
                                        transport_change ? &target_base : nullptr);
    if (status && (actual_source.fingerprint != source.fingerprint ||
                   actual_target.fingerprint != target.fingerprint))
      status = invalid_case(detail_json_value);
    if (status && outlet_change) {
      // Re-hash the target with only the admitted outlet kind/backflow switch
      // restored. Every other input, including transport and asset bytes,
      // remains in the ordinary source identity lane.
      auto normalized = actual_target.boundaries;
      for (std::size_t face = 0; face < normalized.size(); ++face) {
        if (actual_source.boundaries[face].flow_kind == BoundaryKind::zero_gradient_mass_outlet &&
            normalized[face].flow_kind == BoundaryKind::pressure_outlet &&
            normalized[face].allow_backflow) {
          normalized[face].flow_kind = BoundaryKind::zero_gradient_mass_outlet;
          normalized[face].allow_backflow = actual_source.boundaries[face].allow_backflow;
        }
      }
      ValidatedModel witness;
      status = compile_on_root(target_root, rank, witness, payload, nullptr, &normalized);
      source_base = actual_source.fingerprint;
      target_base = witness.fingerprint;
    }
    if (status && solver_change) {
      auto normalized = actual_target.solver;
      normalized.pressure.algorithm = actual_source.solver.pressure.algorithm;
      normalized.pressure.krylov_restart = actual_source.solver.pressure.krylov_restart;
      normalized.pressure.mg_correction_scaling = actual_source.solver.pressure.mg_correction_scaling;
      ValidatedModel witness;
      status = compile_on_root(target_root,rank,witness,payload,nullptr,nullptr,&normalized);
      source_base = actual_source.fingerprint;
      target_base = witness.fingerprint;
    }
    if (status && (source_base == 0U || source_base != target_base))
      status = invalid_case(detail_json_value);
    header[0] = static_cast<std::uint64_t>(status.code);
    header[1] = status.detail;
  }
  const auto broadcast = bcast_header(header, communicator);
  if (!broadcast) return broadcast;
  return {static_cast<StatusCode>(header[0]), static_cast<std::uint32_t>(header[1])};
}

Status CaseCompiler::load_and_compile(MPI_Comm communicator,
                                      const fs::path& case_root,
                                      ValidatedModel& out) {
  if (communicator == MPI_COMM_NULL) {
    return {StatusCode::invalid_plan, detail_collective};
  }

  int rank = 0;
  int size = 0;
  if (MPI_Comm_rank(communicator, &rank) != MPI_SUCCESS ||
      MPI_Comm_size(communicator, &size) != MPI_SUCCESS || size <= 0) {
    return {StatusCode::mpi_failure, detail_collective};
  }

  Status root_status{};
  ValidatedModel root_model;
  std::vector<std::uint8_t> payload;
  if (rank == 0) {
    root_status = compile_on_root(case_root, rank, root_model, payload);
  }

  std::array<std::uint64_t, 4U> header{};
  if (rank == 0) {
    header[0] = static_cast<std::uint64_t>(root_status.code);
    header[1] = root_status.detail;
    header[2] = root_status ? static_cast<std::uint64_t>(payload.size()) : 0U;
    header[3] = root_status ? std::numeric_limits<std::uint64_t>::max() : 0U;
  }
  const Status header_status = bcast_header(header, communicator);
  if (!header_status) {
    return header_status;
  }
  if (header[0] > static_cast<std::uint64_t>(StatusCode::io_failure) ||
      header[1] > std::numeric_limits<std::uint32_t>::max()) {
    return {StatusCode::invalid_plan, detail_wire};
  }
  const Status collective_status{static_cast<StatusCode>(header[0]),
                                 static_cast<std::uint32_t>(header[1])};
  if (!collective_status) {
    record_lowest_failing_rank(
        header[3] <= static_cast<std::uint64_t>(std::numeric_limits<int>::max())
            ? static_cast<int>(header[3])
            : -1);
    return collective_status;
  }
  record_lowest_failing_rank(-1);
  if (header[2] == 0U || header[2] > detail::kMaxWireBytes ||
      header[2] > static_cast<std::uint64_t>(std::numeric_limits<int>::max())) {
    return {StatusCode::invalid_plan, detail_wire};
  }

  int allocation_ok = 1;
  if (rank != 0) {
    try {
      payload.resize(static_cast<std::size_t>(header[2]));
    } catch (...) {
      allocation_ok = 0;
    }
  }
  int all_allocations_ok = 0;
  if (MPI_Allreduce(&allocation_ok, &all_allocations_ok, 1, MPI_INT, MPI_MIN,
                    communicator) != MPI_SUCCESS) {
    return {StatusCode::mpi_failure, detail_collective};
  }
  if (all_allocations_ok == 0) {
    const int candidate = allocation_ok != 0 ? size : rank;
    int lowest = size;
    if (MPI_Allreduce(&candidate, &lowest, 1, MPI_INT, MPI_MIN, communicator) !=
        MPI_SUCCESS) {
      return {StatusCode::mpi_failure, detail_collective};
    }
    record_lowest_failing_rank(lowest);
    return {StatusCode::allocation_failure,
            static_cast<std::uint32_t>(lowest)};
  }

  if (MPI_Bcast(payload.data(), static_cast<int>(payload.size()), MPI_BYTE, 0,
                communicator) != MPI_SUCCESS) {
    return {StatusCode::mpi_failure, detail_collective};
  }

  ValidatedModel decoded;
  const Status decode_status = deserialize_model(payload, decoded);
  int decode_ok = decode_status ? 1 : 0;
  int all_decode_ok = 0;
  if (MPI_Allreduce(&decode_ok, &all_decode_ok, 1, MPI_INT, MPI_MIN,
                    communicator) != MPI_SUCCESS) {
    return {StatusCode::mpi_failure, detail_collective};
  }
  if (all_decode_ok == 0) {
    const int local_allocation_failure =
        decode_status.code == StatusCode::allocation_failure ? 1 : 0;
    int any_allocation_failure = 0;
    if (MPI_Allreduce(&local_allocation_failure, &any_allocation_failure, 1,
                      MPI_INT, MPI_MAX, communicator) != MPI_SUCCESS) {
      return {StatusCode::mpi_failure, detail_collective};
    }
    const bool selected_failure =
        any_allocation_failure != 0 ? local_allocation_failure != 0
                                    : decode_ok == 0;
    const int candidate = selected_failure ? rank : size;
    int lowest = size;
    if (MPI_Allreduce(&candidate, &lowest, 1, MPI_INT, MPI_MIN, communicator) !=
        MPI_SUCCESS) {
      return {StatusCode::mpi_failure, detail_collective};
    }
    record_lowest_failing_rank(lowest);
    return any_allocation_failure != 0
               ? Status{StatusCode::allocation_failure,
                        static_cast<std::uint32_t>(lowest)}
               : Status{StatusCode::invalid_plan, detail_wire};
  }

  out = std::move(decoded);
  return {};
}

}  // namespace hundun::v04
