// SPDX-License-Identifier: Apache-2.0
// Developed by WANG YUDONG | Email: wangyudong@buaa.edu.cn | Github/Wechat: windcicada | Year.M: 2026.09

#pragma once

#include "hundun/v04_flow.hpp"
#include "hundun/v04_ibm.hpp"
#include "solver_species_guess_detail.hpp"
#include "solver_y_history.hpp"
#include "solver_cold.hpp"

#include <memory>
#include "solver_cartesian_detail.hpp"
#include "solver_mass_source_detail.hpp"
#include "solver_scalar_boundary_detail.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <type_traits>
#include <vector>

namespace hundun::v04::detail {

enum class SpeciesCouplingSolver : std::uint8_t { diagonal, dilu };

// Passive transport uses a conservative mass correction, not a cellwise density
// rescaling. The predictor's *actual paired* flux includes its BDF/EX weights
// and any common conservative limiter. For dm_f=(phi_final-phi_star)/a0:
//   M_final q + sum_f dm_f q_upwind = (Mq)_star.
// The legacy standalone remap can also transport species; ProductDriver uses
// solve_target_species so species and energy share their target-time method.
// The remap row sum is M_star to the continuity residual. Positive masses
// therefore give an M-matrix and preserve the predictor's bounds. Donor order
// applies only to the flux correction (O(dt^2) in a smooth BDF2 step), not to
// the configured predictor convection scheme.
class ScalarMassRemap {
 public:
  static constexpr std::uint32_t kInvalid = 10214U;
  static constexpr std::uint32_t kNonconverged = 10215U;
  static constexpr std::uint32_t kRecouple = 10216U;
  static constexpr std::uint32_t kTargetNonconverged = 10217U;
  static constexpr unsigned maximum_coupling_sweeps = 16U;
  static constexpr double tolerance =
      32.0 * std::numeric_limits<double>::epsilon();
  // Absolute composition backward error, after a complete EOS/momentum/
  // limiter recoupling. Distinct from the inner matrix's relative residual:
  // requiring the latter of the entire floating-point nonlinear map causes
  // roundoff-level AFC branch chatter. Independent inventory tests retain
  // their finite-dt 1e-12 gate; no global inventory correction is applied.
  static constexpr double composition_tolerance =
      128.0 * std::numeric_limits<double>::epsilon();

  struct Report {
    bool target_species_evaluated{};
    bool provisional_target_species{};
    bool accelerated_coupling_guess{};
    bool quantized_coupling_guess{}; // Usable provisional state; final audit required.
    unsigned iterations{};
    double initial_species_residual{};
    double residual{};
    double convergence_residual{}; // Quantization-aware, with a trace scale for target species.
    double mass_pairing_residual{};
    double requested_residual_ratio{}; // Maximum row residual / caller budget.
  };

  // Declare this consumer's batch requirement before the shared engine is
  // frozen; it must not depend on which pressure Krylov method is selected.
  static Status reduction_requirement(Span<const TransportedScalarRole> roles,
                                      std::size_t& out) noexcept {
    if (roles.size != 0U && roles.data == nullptr)
      return {StatusCode::invalid_plan, kInvalid};
    std::size_t passives = 0U;
    for (std::size_t i = 0U; i < roles.size; ++i)
      if (roles.data[i] == TransportedScalarRole::passive_scalar) ++passives;
    if (passives > std::numeric_limits<std::size_t>::max() / 2U)
      return {StatusCode::invalid_plan, kInvalid};
    out = std::max(std::size_t{4U}, 2U * passives);
    for (std::size_t i = 0U; i < roles.size; ++i)
      if (roles.data[i] == TransportedScalarRole::species)
        out = std::max(out, SpeciesCouplingHistory::reduction_capacity);
    return {};
  }

  // Local allocation and collective communication binding are separate so
  // the caller can agree bad_alloc before any rank enters HaloEngine::reserve.
  Status allocate(const MeshPatch& patch, Span<const FieldId> fields,
                  Span<const TransportedScalarRole> roles,
                  std::uint8_t ghosts,
                  SpeciesCouplingSolver solver = SpeciesCouplingSolver::diagonal) {
    if (solver != SpeciesCouplingSolver::diagonal &&
        solver != SpeciesCouplingSolver::dilu)
      return {StatusCode::invalid_plan, kInvalid};
    target_solver_ = solver;
    cells_ = patch.cells;
    patch_ = patch;
    ghosts_ = ghosts;
    if (!valid_cells(cells_) || fields.size != roles.size ||
        fields.size == 0U || ghosts == 0U)
      return {StatusCode::invalid_plan, kInvalid};
    const auto multiply = [](std::size_t a, std::size_t b,
                             std::size_t& out) {
      if (b && a > std::numeric_limits<std::size_t>::max() / b) return false;
      out = a * b;
      return true;
    };
    std::size_t sy = static_cast<std::size_t>(cells_.x) + 2U * ghosts;
    std::size_t sz{}, stride{}, count{};
    if (!multiply(sy, static_cast<std::size_t>(cells_.y) + 2U * ghosts, sz) ||
        !multiply(sz, static_cast<std::size_t>(cells_.z) + 2U * ghosts, stride) ||
        !multiply(static_cast<std::size_t>(cells_.x), cells_.y, count) ||
        !multiply(count, cells_.z, count) ||
        !multiply(count, fields.size, quantity_count_))
      return {StatusCode::invalid_plan, kInvalid};
    count_ = count;
    mass_.resize(count);
    quantity_.resize(quantity_count_);
    next_.resize(quantity_count_);
    storage_.resize(fields.size);
    views_.resize(fields.size);
    halo_specs_.resize(fields.size);
    roles_.assign(roles.data, roles.data + roles.size);
    if (std::find(roles_.begin(), roles_.end(), TransportedScalarRole::species) != roles_.end()) {
      for(std::size_t s=0U;s<roles_.size();++s)
        if(roles_[s]==TransportedScalarRole::species) species_indices_.push_back(s);
      target_species_history_.resize(species_indices_.size());
      target_species_diffusivity_.resize(species_indices_.size());
      target_species_diagonal_.resize(species_indices_.size() * count_);
      if (target_solver_ == SpeciesCouplingSolver::dilu) {
        target_species_rows_.resize(species_indices_.size());
        target_species_dilu_.reserve(species_indices_.size());
        for (auto& rows : target_species_rows_) {
          rows.resize(count_);
          // Direct correction sweeps do not publish a Krylov certificate.
          target_species_dilu_.push_back(
              std::make_unique<ColdPressureDilu>(rows, cells_, LinearIdentity{}));
        }
      }
    }
    const auto passive_count = static_cast<std::size_t>(std::count(
        roles_.begin(), roles_.end(), TransportedScalarRole::passive_scalar));
    intervals_.resize(passive_count);
    bounds_local_.resize(2U * passive_count);
    bounds_global_.resize(2U * passive_count);
    for (std::size_t s = 0U; s < fields.size; ++s) {
      storage_[s].assign(stride, 0.0);
      FieldView v;
      v.base = storage_[s].data() + ghosts + ghosts * sy + ghosts * sz;
      v.interior = cells_;
      v.ghosts = {ghosts, ghosts, ghosts};
      v.components = 1U;
      v.stride_y = sy;
      v.stride_z = sz;
      v.component_stride = stride;
      v.field = fields.data[s];
      v.revision = 1U;
      v.storage_identity = reinterpret_cast<StorageIdentity>(storage_[s].data());
      v.revision_domain = reinterpret_cast<RevisionDomainIdentity>(this);
      views_[s] = v;
      halo_specs_[s] = {v.field, ghosts, 1U};
    }
    Status status = FaceFluxStorage::allocate_workspace(cells_, 1U, flux_);
    if (status) status = flux_.workspace_view(0U, 1U, predictor_flux_);
    return status;
  }

  Status bind(MPI_Comm comm, const BoundaryPlan& boundary) noexcept {
    boundary_ = &boundary;
    return halo_.reserve(comm, patch_, {halo_specs_.data(), halo_specs_.size()},
                         boundary.halo_topology());
  }

  Status close_candidate_scalars(Span<FieldView> scalars,
      BoundaryResolvedValues values, ReductionEngine& reductions) noexcept {
    Status local;
    if (!boundary_ || scalars.size!=views_.size() || !scalars.data)
      local={StatusCode::invalid_plan,kInvalid};
    for(std::size_t i=0;i<scalars.size && local;++i)
      if(scalars.data[i].field!=views_[i].field)
        local={StatusCode::invalid_plan,kInvalid};
    auto status=reductions.consensus(local);
    if(!status)return status;
    HaloTicket ticket;
    status=halo_.begin(176U,{scalars.data,scalars.size},{},ticket);
    if(status)status=halo_.finish(ticket,{scalars.data,scalars.size});
    if(status)status=apply_boundary_ghosts(BoundaryStage::scalar,*boundary_,
        {scalars.data,scalars.size},values);
    return reductions.consensus(status);
  }
  Status reserve_coupling_history() { return history_.reserve(quantity_count_); }
  void begin_coupling_sweep(unsigned sweep) noexcept { history_.begin(sweep); }
  Status update_coupling_guess(Span<const FieldView> input,
      Span<const std::uint8_t> activity, ReductionEngine& reductions,
      Report& report) noexcept {
    // solve_target_species has already validated all views and the activity
    // mask collectively; its output is kept separate from the next guess.
    return history_.update(cells_, input, {views_.data(), views_.size()},
        {species_indices_.data(), species_indices_.size()}, activity,
        report.initial_species_residual, reductions,
        report.accelerated_coupling_guess);
  }

  const HaloEngine& halo() const noexcept { return halo_; }

  // Owned capacities, not a process RSS/peak estimate. Halo/MPI bookkeeping
  // is reported by its own service and is deliberately not double-counted.
  std::uint64_t owned_payload_bytes() const noexcept {
    std::uint64_t bytes = flux_.counters().aligned_payload_bytes;
    const auto add = [&](const auto& values) {
      using Element = typename std::decay_t<decltype(values)>::value_type;
      const auto count = values.capacity();
      if (count > (UINT64_MAX - bytes) / sizeof(Element)) bytes = UINT64_MAX;
      else bytes += count * sizeof(Element);
    };
    add(mass_); add(quantity_); add(next_); add(storage_);
    add(species_indices_); add(target_species_history_); add(target_species_diffusivity_); add(target_species_diagonal_);
    add(target_species_rows_);
    add(target_species_dilu_);
    for (const auto& rows : target_species_rows_) add(rows);
    for (const auto& preconditioner : target_species_dilu_) {
      const auto owned = preconditioner->owned_payload_bytes();
      bytes = sizeof(ColdPressureDilu) > UINT64_MAX - bytes
          ? UINT64_MAX : bytes + sizeof(ColdPressureDilu);
      bytes = owned > UINT64_MAX - bytes ? UINT64_MAX : bytes + owned;
    }
    for (const auto& values : storage_) add(values);
    add(views_); add(halo_specs_); add(roles_); add(intervals_);
    add(bounds_local_); add(bounds_global_);
    const auto history_bytes = history_.owned_payload_bytes();
    bytes = history_bytes > UINT64_MAX - bytes ? UINT64_MAX : bytes + history_bytes;
    return bytes;
  }

  Status prepare_passive_intervals(ThermophysicalPredictorInput& input,
                                  ReductionEngine& reductions) noexcept {
    if (intervals_.empty()) return {};
    Status local;
    if (input.passive_scalars_accepted.size != intervals_.size() ||
        input.passive_scalar_nonadvective_rhs.size != intervals_.size() ||
        !input.passive_scalars_accepted.data ||
        !input.passive_scalar_nonadvective_rhs.data || !boundary_ ||
        !std::isfinite(input.dt) || input.dt <= 0 ||
        !valid_cell_view(input.density_accepted, cells_, 0U, 1U, 0U) ||
        !valid_mass_source(input.mass_source, input.mass_source.identity,
                           input.time, cells_))
      local = {StatusCode::invalid_plan, kInvalid};
    std::fill(bounds_local_.begin(), bounds_local_.end(),
              -std::numeric_limits<double>::max());
    for (std::size_t s = 0U; s < intervals_.size() && local; ++s) {
      const auto q = input.passive_scalars_accepted.data[s];
      const auto rate = input.passive_scalar_nonadvective_rhs.data[s].accepted;
      const auto current =
          input.passive_scalar_nonadvective_rhs.data[s].current;
      if (!valid_cell_view(q, cells_, 0U, 1U, 1U) ||
          (rate.base && !valid_cell_view(rate, cells_, 0U, 1U, 0U)) ||
          (current.base && !valid_cell_view(current, cells_, 0U, 1U, 0U))) {
        local = {StatusCode::invalid_plan, kInvalid};
        break;
      }
      const auto include = [&](double value) {
        if (!std::isfinite(value)) { local = {StatusCode::rejected_step, kInvalid}; return; }
        bounds_local_[2U*s] = std::max(bounds_local_[2U*s], -value);
        bounds_local_[2U*s+1U] = std::max(bounds_local_[2U*s+1U], value);
      };
      for (int z = 0; z < cells_.z; ++z)
        for (int y = 0; y < cells_.y; ++y)
          for (int x = 0; x < cells_.x; ++x) {
            const Int3 c{x,y,z};
            const double value = q.unchecked(c,0U);
            include(value);
            // Include the explicit physical/source endpoint. This permits
            // signed/source-driven passives without imposing [0,1]. A stable
            // source-free diffusion step does not enlarge the global range.
            if (!current.base && !input.mass_source.identity && rate.base) {
              include(value + input.dt * rate.unchecked(c, 0U) /
                                  input.density_accepted.unchecked(c, 0U));
            } else if (current.base || input.mass_source.identity) {
              const double rho = input.density_accepted.unchecked(c, 0U);
              const double mass =
                  rho + input.dt * mass_source_rate(input.mass_source, c);
              if (!std::isfinite(rho) || rho <= 0 || !std::isfinite(mass) ||
                  mass <= 0) {
                local = {StatusCode::rejected_step, kInvalid};
              } else {
                const double rhs =
                    (rate.base ? rate.unchecked(c, 0U) : 0.0) +
                    (current.base ? current.unchecked(c, 0U) : 0.0);
                include((rho * value + input.dt * rhs) / mass);
              }
            }
            for (int f = 0; f < 6; ++f) {
              const BoundaryFacePlan* face = nullptr;
              const int axis = f/2, n = axis==0 ? x : axis==1 ? y : z;
              const int extent = axis==0 ? cells_.x : axis==1 ? cells_.y : cells_.z;
              if (n != (f%2 ? extent-1 : 0) ||
                  !boundary_->face(static_cast<CartesianFace>(f),face) ||
                  !face->local_owner || face->periodic) continue;
              Int3 donor = c;
              (axis==0 ? donor.x : axis==1 ? donor.y : donor.z) += f%2 ? 1 : -1;
              include(0.5*(value + q.unchecked(donor,0U)));
            }
          }
    }
    Status status = reductions.checked_max(
        {bounds_local_.data(), bounds_local_.size()},
        {bounds_global_.data(), bounds_global_.size()}, local);
    if (!status) return status;
    for (std::size_t s=0U; s<intervals_.size(); ++s) {
      const double lower=-bounds_global_[2U*s], upper=bounds_global_[2U*s+1U];
      const double guard=128.0*std::numeric_limits<double>::epsilon()*
                         std::max(std::abs(lower),std::abs(upper));
      intervals_[s]={lower-guard,upper+guard};
    }
    input.passive_intervals={intervals_.data(),intervals_.size()};
    return {};
  }

  Status capture(const CartesianKernelPlan& kernels, ConstFieldView density,
                 Span<const FieldView> scalars, ConstFaceFluxView flux,
                 double a0) noexcept {
    return capture_basis(kernels,density,scalars,flux,a0,{},false);
  }

  // rho_n (q_star-q_n)/dt + div(F_star*q_star) - q_star div(F_star)
  // has the conservative storage M_star=rho_n V-sum(F_star)/a0.
  // Capture that mass after frozen-density transport (a0=1/dt). Chemistry
  // added to this transported state shares M_star in its extensive ledger.
  // EOS/statistical densities retain separate identities in the scheduler.
  Status capture_frozen_density(const CartesianKernelPlan& kernels,
                 ConstFieldView density, Span<const FieldView> scalars,
                 ConstFaceFluxView flux, double a0,
                 Span<const std::uint8_t> activity={}) noexcept {
    return capture_basis(kernels,density,scalars,flux,a0,activity,true);
  }

 private:
  Status capture_basis(const CartesianKernelPlan& kernels, ConstFieldView density,
                 Span<const FieldView> scalars, ConstFaceFluxView flux,
                 double a0, Span<const std::uint8_t> activity,
                 bool frozen_density) noexcept {
    if (!std::isfinite(a0) || a0 <= 0.0 ||
        kernels.fingerprint()==0 || kernels.cells().x!=cells_.x ||
        kernels.cells().y!=cells_.y || kernels.cells().z!=cells_.z ||
        scalars.size != views_.size() || !scalars.data ||
        !valid_cell_view(density, cells_, 0U, 1U, 0U) ||
        !valid_flux_view(flux, cells_, flux.revision) ||
        (activity.size && (activity.size!=count_ || !activity.data)))
      return {StatusCode::invalid_plan, kInvalid};
    const std::array<ConstFaceFieldView, 3U> source{flux.x, flux.y, flux.z};
    const std::array<FaceFieldView, 3U> target{
        predictor_flux_.x, predictor_flux_.y, predictor_flux_.z};
    for (std::size_t s = 0U; s < scalars.size; ++s)
      if (scalars.data[s].field != views_[s].field ||
          !valid_cell_view(as_const(scalars.data[s]), cells_, 0U, 1U, 0U))
        return {StatusCode::invalid_plan, kInvalid};
    for (auto face:source)
      for (int z=0;z<face.extents.z;++z)for (int y=0;y<face.extents.y;++y)
        for (int x=0;x<face.extents.x;++x)
          if (!std::isfinite(face.unchecked({x,y,z})))
            return {StatusCode::rejected_step,kInvalid};
    const auto mass_at=[&](Int3 c,std::size_t i) noexcept {
      const double accepted=density.unchecked(c,0)*cell_volume(kernels,c);
      if (!frozen_density || (activity.size && activity.data[i]==0)) return accepted;
      return frozen_density_carrier_mass(flux,c,accepted,a0);
    };
    // Preserve the last complete basis on a local failure. The caller agrees
    // capture status across ranks before using the next collective solve.
    std::size_t i=0;
    for (int z=0;z<cells_.z;++z)for (int y=0;y<cells_.y;++y)
      for (int x=0;x<cells_.x;++x,++i) {
        const Int3 c{x,y,z};
        const double mass=mass_at(c,i),rho=density.unchecked(c,0);
        if (!std::isfinite(rho) || rho<=0 || !std::isfinite(mass) || mass<=0)
          return {StatusCode::rejected_step,kInvalid};
        for (std::size_t s=0;s<scalars.size;++s)
          if (!std::isfinite(scalars.data[s].unchecked(c,0)) ||
              !std::isfinite(mass*scalars.data[s].unchecked(c,0)))
            return {StatusCode::rejected_step,kInvalid};
      }
    a0_=a0;
    for (std::size_t a=0;a<3;++a)
      for (int z=0;z<source[a].extents.z;++z)for (int y=0;y<source[a].extents.y;++y)
        for (int x=0;x<source[a].extents.x;++x)
          target[a].unchecked({x,y,z})=source[a].unchecked({x,y,z});
    i=0;
    for (int z=0;z<cells_.z;++z)for (int y=0;y<cells_.y;++y)
      for (int x=0;x<cells_.x;++x,++i) {
        const Int3 c{x,y,z};
        mass_[i]=mass_at(c,i);
        for (std::size_t s=0;s<scalars.size;++s)
          quantity_[s*count_+i]=mass_[i]*scalars.data[s].unchecked(c,0);
      }
    return {};
  }

 public:

  Status solve(const CartesianKernelPlan& kernels, ConstFieldView density,
               ConstFieldView velocity, ConstFaceFluxView flux, Span<const FieldView> scalars,
               Span<const std::uint8_t> activity,
               BoundaryResolvedValues boundary_values,
               ReductionEngine& reductions, Report& report,
               bool include_species=true) noexcept {
    report = {};
    Status local;
    if (boundary_ == nullptr || scalars.size != views_.size() ||
        !valid_cell_view(density, cells_, 0U, 1U, 0U) ||
        !valid_cell_view(velocity, cells_, 0U, 3U, 0U) ||
        !valid_flux_view(flux, cells_, flux.revision) ||
        (activity.size != 0U && (activity.size != count_ || !activity.data)))
      local = {StatusCode::invalid_plan, kInvalid};
    for (std::size_t s = 0U; s < scalars.size && local; ++s) {
      if (scalars.data[s].field != views_[s].field ||
          !valid_cell_view(as_const(scalars.data[s]), cells_, 0U, 1U, 0U)) {
        local = {StatusCode::invalid_plan, kInvalid};
        break;
      }
      std::size_t i = 0U;
      for (int z = 0; z < cells_.z; ++z)
        for (int y = 0; y < cells_.y; ++y)
          for (int x = 0; x < cells_.x; ++x, ++i)
          {
            views_[s].unchecked({x, y, z}, 0U) =
                scalars.data[s].unchecked({x, y, z}, 0U);
          }
    }
    Status status = reductions.consensus(local);
    if (!status) return status;
    const std::array<ConstFaceFieldView, 3U> final{flux.x, flux.y, flux.z};
    const ConstFaceFluxView prediction = as_const(predictor_flux_);
    const std::array<ConstFaceFieldView, 3U> base{
        prediction.x, prediction.y, prediction.z};
    for (unsigned iteration = 0U; iteration < 128U; ++iteration) {
      for (FieldView& v : views_) ++v.revision;
      HaloTicket ticket;
      status = halo_.begin(176U, {views_.data(), views_.size()}, {}, ticket);
      if (status) status = halo_.finish(ticket, {views_.data(), views_.size()});
      if (status)
        status = apply_boundary_ghosts(BoundaryStage::scalar, *boundary_,
            {views_.data(), views_.size()}, boundary_values);
      status = reductions.consensus(status);
      if (!status) return status;
      double maximum[4U]{};
      std::size_t i = 0U;
      for (int z = 0; z < cells_.z && local; ++z)
        for (int y = 0; y < cells_.y && local; ++y)
          for (int x = 0; x < cells_.x; ++x, ++i) {
            const Int3 c{x, y, z};
            const double mass = density.unchecked(c, 0U) * cell_volume(kernels, c);
            const bool active = activity.size == 0U || activity.data[i] != 0U;
            std::array<double, 6U> outward{};
            std::array<Int3, 6U> neighbours{};
            double diagonal = mass, signed_mass = 0.0;
            for (std::size_t f = 0U; f < 6U; ++f) {
              const std::size_t axis = f / 2U;
              Int3 face = c, neighbour = c;
              auto coordinate = [&](Int3& point) -> int& {
                return axis == 0U ? point.x : axis == 1U ? point.y : point.z;
              };
              const int sign = (f % 2U) == 0U ? -1 : 1;
              if (sign > 0) ++coordinate(face);
              coordinate(neighbour) += sign;
              neighbours[f] = neighbour;
              outward[f] = sign * (final[axis].unchecked(face) -
                                  base[axis].unchecked(face)) / a0_;
              diagonal += std::max(outward[f], 0.0);
              signed_mass += outward[f];
            }
            if (!std::isfinite(diagonal) || diagonal <= 0.0 ||
                !std::isfinite(mass) || mass <= 0.0) {
              local = {StatusCode::rejected_step, kInvalid};
              break;
            }
            if (active)
              maximum[2U] = std::max(maximum[2U],
                  std::abs((mass - mass_[i]) + signed_mass) /
                      (mass + mass_[i]));
            for (std::size_t s = 0U; s < views_.size(); ++s) {
              const double q = views_[s].unchecked(c, 0U);
              if(!include_species && roles_[s]==TransportedScalarRole::species) {
                next_[s*count_+i]=q;
                continue;
              }
              long double rhs = quantity_[s * count_ + i];
              for (std::size_t f = 0U; f < 6U; ++f)
                if (outward[f] < 0.0)
                  rhs -= static_cast<long double>(outward[f]) *
                         scalar_upwind_donor(*boundary_,as_const(views_[s]),neighbours[f],velocity);
              const long double residual = static_cast<long double>(diagonal) * q - rhs;
              const long double scale = std::abs(static_cast<long double>(diagonal) * q) +
                                        std::abs(rhs);
              const double norm = scale == 0.0L ? 0.0 :
                  static_cast<double>(std::abs(residual) / scale);
              // A subnormal (or zero) q cannot resolve less than half the
              // binary64 spacing. Extended-precision donor products can be
              // nonzero even when rhs/diagonal correctly rounds to zero.
              // Keep the raw norm as evidence; only subtract the unavoidable
              // quantization error for the termination test. In ordinary
              // rows this floor is negligible, not a mixture-mass tolerance.
              const long double quantization =
                  0.5L * static_cast<long double>(diagonal) *
                  std::numeric_limits<double>::denorm_min();
              const double convergence_norm = scale == 0.0L ? 0.0 :
                  static_cast<double>(std::max(0.0L,
                      std::abs(residual) - quantization) / scale);
              const double value = active ? static_cast<double>(rhs / diagonal) : q;
              if (!std::isfinite(value) || !std::isfinite(norm)) {
                local = {StatusCode::rejected_step, kInvalid};
                break;
              }
              next_[s * count_ + i] = value;
              if (active) {
                maximum[0U] = std::max(maximum[0U], norm);
                maximum[3U] = std::max(maximum[3U], convergence_norm);
                if (roles_[s] == TransportedScalarRole::species) {
                  // Composition coupling is normalized by mixture mass,
                  // i.e. absolute mass-fraction error, including trace species.
                  // The inner remap solve still uses each equation's relative
                  // residual; no inventory is clipped or renormalized.
                  const double composition_error =
                      static_cast<double>(std::abs(residual)/(mass+mass_[i]));
                  maximum[1U] = std::max(maximum[1U], composition_error);
                }
              }
            }
          }
      double global[4U]{};
      status = reductions.checked_max({maximum, 4U}, {global, 4U}, local);
      if (!status) return status;
      if (iteration == 0U) report.initial_species_residual = global[1U];
      report.iterations = iteration;
      report.residual = global[0U];
      report.convergence_residual = global[3U];
      report.mass_pairing_residual = global[2U];
      if (report.convergence_residual <= tolerance) return {};
      for (std::size_t s = 0U; s < views_.size(); ++s) {
        i = 0U;
        for (int z = 0; z < cells_.z; ++z)
          for (int y = 0; y < cells_.y; ++y)
            for (int x = 0; x < cells_.x; ++x, ++i)
              views_[s].unchecked({x, y, z}, 0U) = next_[s * count_ + i];
      }
    }
    return {StatusCode::rejected_step, kNonconverged};
  }

  // The thermodynamic species must close the same target-time BDF convection
  // and diffusion equations as h. The BDF/EX predictor is an initial guess,
  // not a different final species equation. Passives retain the paired remap.
  // Reuses the owned scalar views/halo and caller-provided dead Schur scratch;
  // no hot allocation or independently published face flux is introduced.
  Status solve_target_species(const EquationPlanSet& equations,
      EquationStateView state, EquationMaterialView material,
      EquationAssemblyContext context, EquationSystemView scratch,
      FieldView diffusivity, Span<const FieldView> input,
      Span<const std::uint8_t> activity, BoundaryResolvedValues boundary_values,
      ReductionEngine& reductions, Report& report,
      bool intermediate_coupling = false,
      const ThermodynamicsPlan* thermo = nullptr,
      ConstFieldView temperature = {}, Span<double> enthalpy_residual = {},
      bool continuity_reduced = false,
      Span<const EquationContributionView> contributions = {},
      Span<const double> residual_limits = {}) noexcept {
    if(species_indices_.empty()) return {};
    Status local;
    const auto& kernels=equations.kernels();
    const auto& species=equations.species();
    if (!valid_mass_source(state.mass_source,state.mass_source.identity,
                           context.time,cells_))
      local={StatusCode::invalid_plan,kInvalid};
    // REFERENCE's advective BE row is R_Y-Y*R_mass with old-density storage.
    // This row operation supplies an uncommitted coupling guess. The public
    // target-time assembler and final conservation audit retain R_Y itself.
    if (continuity_reduced && (!intermediate_coupling ||
        context.scope != EquationAssemblyScope::momentum_predictor ||
        !context.provisional_mass_flux || context.bdf.a2 != 0.0 ||
        context.bdf.a0 != 1.0/context.dt || context.bdf.a1 != -context.bdf.a0))
      local={StatusCode::invalid_plan,kInvalid};
    if (thermo && (!valid_cell_view(temperature,cells_,0U,1U,0U) ||
        enthalpy_residual.size!=count_ || enthalpy_residual.data==nullptr))
      local={StatusCode::invalid_plan,kInvalid};
    if(species.size()!=species_indices_.size() ||
        state.independent_species.size!=species.size() ||
        state.independent_species.data==nullptr || input.size!=views_.size() ||
        input.data==nullptr || !valid_cell_view(as_const(diffusivity),cells_,0U,1U,1U) ||
        !valid_cell_view(material.molecular_viscosity,cells_,0U,1U,1U) ||
        !valid_cell_view(material.effective_viscosity,cells_,0U,1U,1U) ||
        (activity.size!=0U && (activity.size!=count_ || activity.data==nullptr)))
      local={StatusCode::invalid_plan,kInvalid};
    if (residual_limits.size && (residual_limits.size != species.size() ||
        !residual_limits.data)) local={StatusCode::invalid_plan,kInvalid};
    for(std::size_t s=0U;s<species.size() && local;++s) {
      if (residual_limits.size && (!(residual_limits.data[s] > 0) ||
          !std::isfinite(residual_limits.data[s]))) {
        local={StatusCode::invalid_plan,kInvalid}; break;
      }
      const auto slot=species_indices_[s];
      if(!valid_cell_view(as_const(input.data[slot]),cells_,0U,1U,0U) ||
          input.data[slot].field!=views_[slot].field) {
        local={StatusCode::invalid_plan,kInvalid}; break;
      }
      target_species_history_[s]=state.independent_species.data[s];
      for(int z=0;z<cells_.z;++z) for(int y=0;y<cells_.y;++y) for(int x=0;x<cells_.x;++x)
        views_[slot].unchecked({x,y,z},0U)=input.data[slot].unchecked({x,y,z},0U);
      // One coefficient workspace is evaluated for one equation at a time.
      target_species_diffusivity_[s]=as_const(diffusivity);
    }
    auto status=reductions.consensus(local);
    if(!status) return status;
    state.independent_species={target_species_history_.data(),target_species_history_.size()};
    material.scalar_mass_diffusivity={target_species_diffusivity_.data(),target_species_diffusivity_.size()};
    // The passive remap has already consumed the paired predictor flux.
    // Its private face storage is now dead until the next capture, and may
    // hold the scalar assembler's positive diffusion coefficients. No final
    // or pending physical face-flux storage is overwritten.
    scratch.x_coefficient=predictor_flux_.x;
    scratch.y_coefficient=predictor_flux_.y;
    scratch.z_coefficient=predictor_flux_.z;
    const std::array<ConstFaceFieldView,3U> flux{context.mass_flux.x,context.mass_flux.y,context.mass_flux.z};
    const unsigned passive_iterations=report.iterations;
    for(unsigned iteration=0U;iteration<128U;++iteration) {
      for(auto& v:views_) ++v.revision;
      HaloTicket ticket;
      status=halo_.begin(176U,{views_.data(),views_.size()},{},ticket);
      if(status) status=halo_.finish(ticket,{views_.data(),views_.size()});
      if(status) status=apply_boundary_ghosts(BoundaryStage::scalar,*boundary_,
          {views_.data(),views_.size()},boundary_values);
      status=reductions.consensus(status);
      if(!status) return status;
      for(std::size_t s=0U;s<species.size();++s)
        target_species_history_[s].trial=as_const(views_[species_indices_[s]]);
      double maximum[5]{}; // relative, absolute, converged, requested ratio, unresolved row
      if (thermo) std::fill(enthalpy_residual.data,
          enthalpy_residual.data+enthalpy_residual.size,0.0);
      for(std::size_t s=0U;s<species.size() && local;++s) {
        const auto slot=species_indices_[s];
        const auto& spec=*species.spec(s);
        Span<const EquationContributionView> sources;
        if (!select_species_sources(contributions, spec.field, sources)) {
          local = {StatusCode::invalid_plan, kInvalid};
          break;
        }
        // Same molecular/turbulent Schmidt coefficient as the persisted
        // physical species rate. Only face slabs are stencil consumers.
        for(int z=-1;z<=cells_.z && local;++z)
          for(int y=-1;y<=cells_.y && local;++y)
            for(int x=-1;x<=cells_.x;++x) {
              if((x<0 || x>=cells_.x)+(y<0 || y>=cells_.y)+(z<0 || z>=cells_.z)>1) continue;
              const Int3 c{x,y,z};
              const double mu=material.molecular_viscosity.unchecked(c,0U);
              double mut=material.effective_viscosity.unchecked(c,0U)-mu;
              if(mut<0.0 && mut>-1e-12*std::max(1.0,mu)) mut=0.0;
              const double gamma=mu/spec.molecular_schmidt+mut/spec.turbulent_schmidt;
              if(!std::isfinite(gamma) || gamma<=0.0 || mu<0.0 || mut<0.0) {
                local={StatusCode::rejected_step,kInvalid}; break;
              }
              diffusivity.unchecked(c,0U)=gamma;
            }
        // Only q changes in this inner solve. Density, diffusivity, time and
        // flux remain fixed; each new solve rebuilds the diagonal at iteration 0.
        if (local && iteration == 0U) {
          local = assemble_species_coupling_rows(species, s, state, material,
                                                 context, scratch, sources);
          std::size_t cell_index = s * count_;
          for (int z = 0; z < cells_.z && local; ++z)
            for (int y = 0; y < cells_.y; ++y)
              for (int x = 0; x < cells_.x; ++x, ++cell_index)
                target_species_diagonal_[cell_index] =
                    scratch.diagonal.unchecked({x, y, z}, 0U);
        } else if (local) {
          std::size_t cell_index = s * count_;
          for (int z = 0; z < cells_.z; ++z)
            for (int y = 0; y < cells_.y; ++y)
              for (int x = 0; x < cells_.x; ++x, ++cell_index)
                scratch.diagonal.unchecked({x, y, z}, 0U) =
                    target_species_diagonal_[cell_index];
          local = assemble_species_coupling_residual(species, s, state, material,
                                                     context, scratch, sources);
        }
        if (local && continuity_reduced) {
          std::size_t index{};
          for (int z=0;z<cells_.z;++z) for (int y=0;y<cells_.y;++y)
            for (int x=0;x<cells_.x;++x,++index) {
              if (activity.size && activity.data[index]==0U) continue;
              const Int3 c{x,y,z};
              const double divergence=(context.mass_flux.x.unchecked({x+1,y,z})-
                  context.mass_flux.x.unchecked(c)+context.mass_flux.y.unchecked({x,y+1,z})-
                  context.mass_flux.y.unchecked(c)+context.mass_flux.z.unchecked({x,y,z+1})-
                  context.mass_flux.z.unchecked(c))/cell_volume(kernels,c);
              const double continuity=(state.density.trial.unchecked(c,0)-
                  state.density.accepted.unchecked(c,0))/context.dt+divergence-
                  mass_source_rate(state.mass_source,c);
              scratch.diagonal.unchecked(c,0)-=continuity;
              scratch.residual.unchecked(c,0)-=views_[slot].unchecked(c,0)*continuity;
            }
        }
        if (local && target_solver_ == SpeciesCouplingSolver::dilu &&
            iteration == 0U) {
          auto& yrows = target_species_rows_[s];
          std::size_t row_index{};
          const std::array<ConstFaceFieldView, 3> diffusion{
              as_const(scratch.x_coefficient), as_const(scratch.y_coefficient),
              as_const(scratch.z_coefficient)};
          for (int z = 0; z < cells_.z && local; ++z)
            for (int y = 0; y < cells_.y && local; ++y)
              for (int x = 0; x < cells_.x; ++x, ++row_index) {
                Int3 c{x, y, z};
                auto& row = yrows[row_index];
                row = {};
                if (activity.size && activity.data[row_index] == 0U) {
                  row.diagonal = 1;
                  continue;
                }
                const double volume = cell_volume(kernels, c);
                row.diagonal = scratch.diagonal.unchecked(c, 0);
                const Int3 neighbours[] = {{x - 1, y, z}, {x + 1, y, z},
                                           {x, y - 1, z}, {x, y + 1, z},
                                           {x, y, z - 1}, {x, y, z + 1}};
                for (unsigned face_id = 0; face_id < 6; ++face_id) {
                  unsigned axis = face_id / 2;
                  Int3 face = face_id % 2 ? neighbours[face_id] : c;
                  double D = diffusion[axis].unchecked(face),
                         F = flux[axis].unchecked(face) * (face_id % 2 ? 1 : -1);
                  double convective_diagonal=std::max(F,0.0)/volume;
                  row.neighbour[face_id] = (D + std::max(-F, 0.0)) / volume;
                  if (context.mixture_transport) {
                    const int normal=axis==0 ? face.x : axis==1 ? face.y : face.z;
                    const double lower=interpolate_face(kernels,
                        static_cast<CartesianAxis>(axis),normal,1.0,0.0);
                    const double owner=face_id%2 ? lower : 1.0-lower;
                    convective_diagonal=F*owner/volume;
                    row.neighbour[face_id]=(D-F*(1.0-owner))/volume;
                  }
                  // Common VLS diffusion already contains the upwind
                  // stabilization. Use its actual central/VLS coefficients;
                  // adding another upwind operator changes trace directions.
                  row.diagonal += convective_diagonal;
                  double imposed{};
                  if (context.immersed_interface &&
                      context.immersed_interface->prescribed_face_flux(
                          static_cast<CartesianAxis>(axis), face, imposed)) {
                    if (context.mixture_transport)
                      row.diagonal-=convective_diagonal;
                    row.neighbour[face_id] = 0;
                  }
                  int coordinate = axis == 0   ? x
                                   : axis == 1 ? y
                                               : z,
                      extent = axis == 0   ? cells_.x
                               : axis == 1 ? cells_.y
                                           : cells_.z;
                  if (coordinate != (face_id % 2 ? extent - 1 : 0)) continue;
                  const BoundaryFacePlan* boundary_face{};
                  local = boundary_->face(static_cast<CartesianFace>(face_id),
                                          boundary_face);
                  if (!local || !boundary_face) break;
                  if (!boundary_face->local_owner || boundary_face->periodic)
                    continue;
                  switch (boundary_face->flow_kind) {
                    case BoundaryKind::velocity_inlet:
                    case BoundaryKind::mass_flow_inlet:
                      row.diagonal += context.mixture_transport
                          ? row.neighbour[face_id] : D / volume;
                      break;
                    case BoundaryKind::pressure_outlet:
                      if (boundary_->allow_backflow().data[boundary_face->flow_parameter] != 0 &&
                          (face_id % 2 ? 1.0 : -1.0) *
                              state.velocity.trial.unchecked(c, axis) < 0.0)
                        row.diagonal += context.mixture_transport
                            ? row.neighbour[face_id] : D / volume;
                      else
                        row.diagonal -= row.neighbour[face_id];
                      break;
                    case BoundaryKind::symmetry:
                    case BoundaryKind::no_slip_wall:
                    case BoundaryKind::zero_gradient_mass_outlet:
                      row.diagonal -= row.neighbour[face_id];
                      break;
                    default:
                      local = {StatusCode::invalid_plan, 17820};
                      break;
                  }
                  row.neighbour[face_id] = 0;
                }
              }
          if (local) {
            local = target_species_dilu_[s]->prepare();
          }
        }
        if (local && target_solver_ == SpeciesCouplingSolver::dilu)
          local = target_species_dilu_[s]->apply(as_const(scratch.residual),
                                                 scratch.rhs, 0);

        std::size_t i=0U;
        for(int z=0;z<cells_.z && local;++z)
          for(int y=0;y<cells_.y && local;++y)
            for(int x=0;x<cells_.x;++x,++i) {
              const Int3 c{x,y,z}; const double q=views_[slot].unchecked(c,0U);
              next_[slot*count_+i]=q;
              if(activity.size!=0U && activity.data[i]==0U) continue;
              const double residual=scratch.residual.unchecked(c,0U);
              if (thermo) {
                double difference{};
                local=thermo->independent_species_enthalpy_difference(
                    s,temperature.unchecked(c,0U),difference);
                if (!local) break;
                enthalpy_residual.data[i]+=difference*residual;
              }
              const double diagonal=species_coupling_search_diagonal(kernels,
                  species.convection(),context.mass_flux,c,scratch.diagonal.unchecked(c,0U));
              const long double scale=std::abs(static_cast<long double>(diagonal)*q)+
                  std::abs(static_cast<long double>(diagonal)*q-residual);
              const long double floor=0.5L*diagonal*std::numeric_limits<double>::denorm_min();
              const double norm=scale==0.0L ? 0.0 : static_cast<double>(std::abs(residual)/scale);
              // Mass fractions have the natural reference scale one. Retain
              // the relative row test above epsilon; below it, bound the
              // absolute row correction by tolerance * epsilon. A trace near
              // 1e-280 must not reject a step whose composition has converged.
              // Keep the raw relative residual separately for diagnostics.
              const long double reference_scale =
                  static_cast<long double>(diagonal) *
                  std::numeric_limits<double>::epsilon();
              const double converged=scale==0.0L ? 0.0 : static_cast<double>(std::max(0.0L,std::abs(static_cast<long double>(residual))-floor)/std::max(scale,reference_scale));
              const double mass_scale=context.bdf.a0*
                  (state.density.trial.unchecked(c,0U)+state.density.accepted.unchecked(c,0U));
              const double correction=target_solver_ == SpeciesCouplingSolver::dilu
                  ? scratch.rhs.unchecked(c,0U) : residual/diagonal;
              const double value=species_search_update(q,correction);
              if(!std::isfinite(value) || !std::isfinite(norm) || !std::isfinite(diagonal) || diagonal<=0.0 || mass_scale<=0.0) {
                local={StatusCode::rejected_step,kInvalid}; break;
              }
              maximum[0]=std::max(maximum[0],norm);
              maximum[1]=std::max(maximum[1],std::abs(residual)/mass_scale);
              maximum[2]=std::max(maximum[2],converged);
              if (residual_limits.size) {
                const double ratio=std::abs(residual)/residual_limits.data[s];
                maximum[3]=std::max(maximum[3],ratio);
                if (ratio>1 && !species_search_quantized(q,value,diagonal,residual))
                  maximum[4]=1;
              }
              next_[slot*count_+i]=value;
            }
      }
      double global[5]{};
      status=reductions.checked_max({maximum,5U},{global,5U},local);
      if(!status) return status;
      if(iteration==0U) {
        report.initial_species_residual=global[1];
        report.target_species_evaluated=true;
        report.provisional_target_species =
            context.scope != EquationAssemblyScope::final_conservative;
      }
      report.iterations=passive_iterations+iteration;
      report.residual=global[0]; report.convergence_residual=global[2];
      report.requested_residual_ratio=global[3];
      if(report.convergence_residual<=tolerance && global[3]<=1.0) return {};
      // The caller's extra inner margin can be smaller than half one
      // represented composition ULP. Return this state as a provisional
      // guess only when every over-budget row is quantization-limited.
      // The unmodified final conservative equations still decide acceptance.
      if (intermediate_coupling && report.provisional_target_species &&
          residual_limits.size && iteration>0 && global[3]>1 && global[4]==0 &&
          report.convergence_residual<=tolerance) {
        report.quantized_coupling_guess=true;
        return {};
      }
      // An explicit uncommitted outer update may use inexact inner solves.
      // Its caller still owns the complete final species/equation audit.
      if (intermediate_coupling && residual_limits.size == 0U &&
          target_solver_ == SpeciesCouplingSolver::dilu &&
          iteration >= 2U &&
          global[1] <= std::max(0.01 * report.initial_species_residual,
                               64.0 * std::numeric_limits<double>::epsilon())) return {};
      std::size_t i=0U;
      for(int z=0;z<cells_.z;++z) for(int y=0;y<cells_.y;++y) for(int x=0;x<cells_.x;++x,++i) {
        const Int3 c{x,y,z};
        // Bound only the nonlinear search step. Do not clip/normalize the
        // physical solution or accept until its unmodified equations close.
        double theta=1.0; long double sum=0.0L, delta_sum=0.0L;
        for(const auto slot:species_indices_) {
          const double q=views_[slot].unchecked(c,0U), delta=next_[slot*count_+i]-q;
          sum+=q; delta_sum+=static_cast<long double>(next_[slot*count_+i])-q;
          if(delta<0.0 && q+delta<0.0) theta=std::min(theta,0.9*q/(-delta));
          if(delta>0.0 && q+delta>1.0) theta=std::min(theta,0.9*(1.0-q)/delta);
        }
        if(delta_sum>0.0L && sum+delta_sum>1.0L)
          theta=std::min(theta,static_cast<double>(0.9L*(1.0L-sum)/delta_sum));
        // Check the represented candidate, including rounding in each update.
        // A sum of rounded deltas can hide an excess of half a double ULP
        // when the dependent species is exactly zero. Search the common step
        // length; the equation residual and the composition stay authoritative.
        const auto admissible=[&](double step) {
          long double total=0.0L;
          for (const auto slot:species_indices_) {
            const double q=views_[slot].unchecked(c,0U);
            const double value=step==1.0 ? next_[slot*count_+i]
                : q+step*(next_[slot*count_+i]-q);
            if (!std::isfinite(value) || value<0.0 || value>1.0) return false;
            total+=value;
          }
          return total<=1.0L;
        };
        for (unsigned search=0; !admissible(theta); ++search)
          theta=search<64 ? 0.5*theta : 0.0;
        for(const auto slot:species_indices_) {
          auto& q=views_[slot].unchecked(c,0U);
          q=theta==1.0 ? next_[slot*count_+i] : q+theta*(next_[slot*count_+i]-q);
        }
      }
    }
    return {StatusCode::rejected_step,kTargetNonconverged};
  }

  Status copy_thermophysical_coupling_guess(const ThermodynamicsPlan& thermo,
      double pressure_reference, ConstFieldView pressure, FieldView enthalpy,
      Span<const FieldView> target, Span<double> composition,
      bool use_target_solution=false) const noexcept {
    if(target.size!=views_.size() || target.data==nullptr ||
        composition.size!=species_indices_.size() || composition.data==nullptr ||
        !valid_cell_view(pressure,cells_,0U,1U,0U) ||
        !valid_cell_view(as_const(enthalpy),cells_,0U,1U,0U))
      return {StatusCode::invalid_plan,kInvalid};
    std::size_t i=0U;
    for(int z=0;z<cells_.z;++z) for(int y=0;y<cells_.y;++y) for(int x=0;x<cells_.x;++x,++i) {
      const Int3 c{x,y,z}; bool changed=false;
      const auto guess=[&](std::size_t slot) noexcept {
        return use_target_solution
            ? (history_.valid() ? history_.guess(slot*count_+i)
                                : views_[slot].unchecked(c,0U))
            : next_[slot*count_+i];
      };
      for(std::size_t s=0U;s<species_indices_.size();++s) {
        const auto slot=species_indices_[s];
        composition.data[s]=target.data[slot].unchecked(c,0U);
        changed |= composition.data[s]!=guess(slot);
      }
      if(!changed) continue;
      ThermoState state;
      auto status=thermo.evaluate_from_reference_pressure(pressure_reference,
          pressure.unchecked(c,0U),enthalpy.unchecked(c,0U),
          {composition.data,composition.size},{},state);
      if(!status) return status;
      long double change=0.0L;
      for(std::size_t s=0U;s<species_indices_.size();++s) {
        double difference{};
        status=thermo.independent_species_enthalpy_difference(s,state.temperature,difference);
        if(!status) return status;
        const auto slot=species_indices_[s];
        change+=static_cast<long double>(difference)*
            (static_cast<long double>(guess(slot))-composition.data[s]);
      }
      const double next_h=static_cast<double>(static_cast<long double>(enthalpy.unchecked(c,0U))+change);
      if(!std::isfinite(next_h)) return {StatusCode::rejected_step,kInvalid};
      enthalpy.unchecked(c,0U)=next_h;
      for(const auto slot:species_indices_)
        target.data[slot].unchecked(c,0U)=guess(slot);
    }
    return {};
  }

  // Borrowed until the next remap/target solve. Includes the converged halo.
  ConstFieldView target_species(std::size_t species) const noexcept {
    return as_const(views_[species_indices_[species]]);
  }

  void copy_solution(Span<const FieldView> target,
                     TransportedScalarRole role) const noexcept {
    for (std::size_t s = 0U; s < views_.size(); ++s) {
      if (roles_[s] != role) continue;
      for (int z = 0; z < cells_.z; ++z)
        for (int y = 0; y < cells_.y; ++y)
          for (int x = 0; x < cells_.x; ++x)
            target.data[s].unchecked({x, y, z}, 0U) =
                views_[s].unchecked({x, y, z}, 0U);
    }
  }

 private:
  SpeciesCouplingHistory history_;
  Int3 cells_{};
  MeshPatch patch_{};
  std::uint8_t ghosts_{};
  std::size_t count_{}, quantity_count_{};
  double a0_{};
  const BoundaryPlan* boundary_{};
  std::vector<double> mass_, quantity_, next_;
  std::vector<double> bounds_local_, bounds_global_;
  std::vector<double> target_species_diagonal_;
  SpeciesCouplingSolver target_solver_{SpeciesCouplingSolver::diagonal};
  std::vector<std::vector<ColdPressureRow>> target_species_rows_;
  std::vector<std::unique_ptr<ColdPressureDilu>> target_species_dilu_;
  std::vector<ScalarAdmissibleInterval> intervals_;
  std::vector<std::vector<double>> storage_;
  std::vector<FieldView> views_;
  std::vector<HaloFieldSpec> halo_specs_;
  std::vector<TransportedScalarRole> roles_;
  std::vector<std::size_t> species_indices_;
  std::vector<PrimitiveHistory> target_species_history_;
  std::vector<ConstFieldView> target_species_diffusivity_;
  HaloEngine halo_;
  FaceFluxStorage flux_;
  FaceFluxView predictor_flux_{};
};

}  // namespace hundun::v04::detail
