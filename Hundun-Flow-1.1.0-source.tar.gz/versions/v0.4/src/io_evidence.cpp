// SPDX-License-Identifier: Apache-2.0
// Developed by WANG YUDONG | Email: wangyudong@buaa.edu.cn | Github/Wechat: windcicada | Year.M: 2026.09

#include "hundun/v04_io.hpp"

#include "app_evidence_detail.hpp"
#include "app_identity_detail.hpp"
#include "io_output_detail.hpp"

#include <mpi.h>

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <limits>
#include <locale>
#include <new>
#include <sstream>
#include <string>
#include <utility>

namespace hundun::v04 {
namespace {

std::string_view termination_name(LinearTermination termination) noexcept {
  switch (termination) {
    case LinearTermination::converged:
      return "converged";
    case LinearTermination::zero_rhs:
      return "zero_rhs";
    case LinearTermination::maximum_iterations:
      return "maximum_iterations";
    case LinearTermination::breakdown:
      return "breakdown";
    case LinearTermination::non_finite:
      return "non_finite";
    case LinearTermination::operator_failure:
      return "operator_failure";
    case LinearTermination::preconditioner_failure:
      return "preconditioner_failure";
    case LinearTermination::collective_failure:
      return "collective_failure";
    case LinearTermination::invalid_plan:
      return "invalid_plan";
    case LinearTermination::convergence_audit_failure:
      return "convergence_audit_failure";
  }
  return "invalid";
}

std::string_view pressure_solve_contract_name(
    RuntimePressureSolveContract contract) noexcept {
  switch (contract) {
    case RuntimePressureSolveContract::pressure_continuity:
      return "pressure_continuity";
    case RuntimePressureSolveContract::continuity_energy_coupled:
      return "continuity_energy_coupled";
    case RuntimePressureSolveContract::cn_be:
      return "cn_be";
    case RuntimePressureSolveContract::invalid:
      break;
  }
  return "invalid";
}

std::string_view coupling_name(RuntimeCouplingKind coupling) noexcept {
  switch (coupling) {
    case RuntimeCouplingKind::piso:
      return "PISO";
    case RuntimeCouplingKind::simple:
      return "SIMPLE";
    case RuntimeCouplingKind::cn_be:
      return "CN_BE";
    case RuntimeCouplingKind::invalid:
      break;
  }
  return "invalid";
}

std::string_view pressure_energy_refinement_termination_name(
    RuntimePressureEnergyRefinementTermination termination) noexcept {
  switch (termination) {
    case RuntimePressureEnergyRefinementTermination::
        component_residuals_converged:
      return "component_residuals_converged";
    case RuntimePressureEnergyRefinementTermination::
        iteration_capacity_exhausted:
      return "iteration_capacity_exhausted";
    case RuntimePressureEnergyRefinementTermination::rejected_candidate:
      return "rejected_candidate";
    case RuntimePressureEnergyRefinementTermination::none:
      return "none";
  }
  return "invalid";
}

bool accepted_terminal_metric(double residual, double tolerance,
                              bool enabled_required = true) noexcept {
  if (!std::isfinite(residual) || residual < 0.0 ||
      !std::isfinite(tolerance) || tolerance < 0.0 ||
      (enabled_required && tolerance == 0.0))
    return false;
  // A zero tolerance is the V2 pressure-continuity convention for a disabled
  // energy gate.  Coupled V3 records never enter this branch.
  return tolerance == 0.0 || residual <= tolerance;
}

bool valid_runtime_cfl_winner(const RuntimeConvectiveCflWinner& winner,
                              double dt) noexcept {
  const auto same = [](double left, double right) noexcept {
    return std::abs(left - right) <=
           64.0 * std::numeric_limits<double>::epsilon() *
               std::max({1.0, std::abs(left), std::abs(right)});
  };
  return winner.valid && winner.global_cell.x >= 0 &&
         winner.global_cell.y >= 0 && winner.global_cell.z >= 0 &&
         winner.rank >= 0 && std::isfinite(dt) && dt > 0.0 &&
         std::isfinite(winner.out) && winner.out >= 0.0 &&
         std::isfinite(winner.absolute) && winner.absolute >= 0.0 &&
         std::isfinite(winner.density_volume) &&
         winner.density_volume > 0.0 &&
         std::isfinite(winner.outgoing_mass_flow) &&
         winner.outgoing_mass_flow >= 0.0 &&
         std::isfinite(winner.absolute_mass_flow) &&
         winner.absolute_mass_flow >= 0.0 &&
         std::isfinite(winner.directional) && winner.directional >= 0.0 &&
         std::isfinite(winner.maximum_face_mass_flow) && winner.maximum_face_mass_flow >= 0.0 &&
         same(winner.directional,(dt/winner.density_volume)*winner.maximum_face_mass_flow) &&
         same(winner.out,
              (dt / winner.density_volume) *
                  winner.outgoing_mass_flow) &&
         same(winner.absolute,
              (dt / winner.density_volume) *
                  (0.5 * winner.absolute_mass_flow));
}

bool valid_runtime_run_start(const RuntimeEvidenceRecord& record) noexcept {
  const RuntimeRunStartAnchor& anchor = record.run_start;
  const bool refinement = anchor.history_policy == RestartHistoryPolicy::refine_chemistry;
  if (anchor.transport_source_case != 0U &&
      (anchor.kind != RuntimeRunStartKind::restart || anchor.source_format_version < 3U ||
       anchor.source_format_version > 5U ||
       (!refinement && (anchor.history_policy != RestartHistoryPolicy::rebuild_method_history ||
                       record.coupling != RuntimeCouplingKind::cn_be)))) return false;
  if (refinement && anchor.transport_source_case == 0U) return false;
  if (!std::isfinite(anchor.previous_time) || anchor.previous_time < 0.0 ||
      record.step <= anchor.previous_step)
    return false;
  const bool empty_manifest = std::all_of(
      anchor.restart_manifest_sha256.begin(),
      anchor.restart_manifest_sha256.end(),
      [](char value) noexcept { return value == '\0'; });
  const bool zero_manifest = std::all_of(
      anchor.restart_manifest_sha256.begin(),
      anchor.restart_manifest_sha256.begin() +
          kRuntimeSha256HexCharacters,
      [](char value) noexcept { return value == '0'; });
  const bool first = record.step == anchor.previous_step + 1U;
  const auto same_time = [](double left, double right) noexcept {
    return std::abs(left - right) <=
           128.0 * std::numeric_limits<double>::epsilon() *
               std::max({1.0, std::abs(left), std::abs(right)});
  };
  if (anchor.kind == RuntimeRunStartKind::fresh) {
    if (anchor.previous_step != 0U || anchor.previous_time != 0.0 ||
        !empty_manifest || record.restart_recovery ||
        ((record.step == 1U) != record.startup))
      return false;
  } else if (anchor.kind == RuntimeRunStartKind::restart) {
    if (anchor.previous_step == 0U || empty_manifest ||
        !detail::valid_runtime_sha256(anchor.restart_manifest_sha256) ||
        zero_manifest ||
        record.startup || (record.restart_recovery && !first) ||
        (first && record.restart_recovery &&
         (record.requested_bdf_order != 1U || record.bdf_order != 1U)))
      return false;
    if (anchor.source_format_version != 0U) {
      const bool rebuild = anchor.history_policy == RestartHistoryPolicy::rebuild_method_history;
      const bool missing = anchor.source_format_version == 1U || anchor.source_format_version == 6U;
      if (anchor.source_format_version > 6U ||
          (refinement && anchor.source_format_version == 6U) ||
          anchor.target_history_signature == 0U ||
          (anchor.source_format_version < 3U || missing
               ? anchor.source_history_signature != 0U
               : anchor.source_history_signature == 0U) ||
          (!rebuild &&
           anchor.history_policy != RestartHistoryPolicy::require_compatible && !refinement) ||
          (!rebuild && !missing &&
           anchor.source_history_signature !=
               anchor.target_history_signature) ||
          (first && record.restart_recovery != (missing || rebuild)))
        return false;
    }
  } else {
    return false;
  }
  return !first ||
         same_time(record.previous_committed_time, anchor.previous_time);
}

std::string_view predictor_constraint_name(
    std::uint8_t constraint) noexcept {
  switch (constraint) {
    case 0U:
      return "none";
    case 1U:
      return "density";
    case 2U:
      return "independent_species";
    case 3U:
      return "dependent_species";
    case 4U:
      return "enthalpy_lower";
    case 5U:
      return "enthalpy_upper";
    case 6U:
      return "passive_lower";
    case 7U:
      return "passive_upper";
  }
  return "invalid";
}

std::string_view predictor_low_state_name(std::uint8_t low_state) noexcept {
  switch (low_state) {
    case 0U:
      return "none";
    case 1U:
      return "bdf_accepted_rate";
    case 2U:
      return "scaled_euler";
    case 3U:
      return "implicit_upwind";
    case 4U:
      return "implicit_upwind_source_limited";
    case 5U:
      return "bdf_accepted_rate_homotopy";
    case 6U:
      return "bdf_local_donor_flux";
    case 7U:
      return "bdf_local_donor_flux_source_limited";
  }
  return "invalid";
}

Status validate_record(const IoServicePlan& services,
                       const RuntimeEvidenceRecord& record) noexcept {
  const bool cold_contract = record.pressure_solve_contract ==
                             RuntimePressureSolveContract::cn_be;
  const auto &cold = record.cold;
  const auto accepted_solve = [&](const LinearSolveResult &solve) {
    return solve.status &&
           (solve.termination == LinearTermination::converged ||
            solve.termination == LinearTermination::zero_rhs ||
            (cold.pdf_before_flow && solve.termination == LinearTermination::maximum_iterations)) &&
           std::isfinite(solve.initial_true_residual) &&
           solve.initial_true_residual >= 0.0 &&
           std::isfinite(solve.final_true_residual) &&
           solve.final_true_residual >= 0.0 &&
           std::isfinite(solve.recursive_residual) &&
           solve.recursive_residual >= 0.0;
  };
  const auto positive_scale = [](double value) {
    return std::isfinite(value) && value > 0.0;
  };
  const bool valid_reference_stopping = cold.stopping && cold.stopping->valid() &&
      positive_scale(cold.momentum_reference_scale) &&
      positive_scale(cold.enthalpy_reference_scale) &&
      cold.species_reference_scales.size() == cold.independent_species_count + 1U &&
      std::all_of(cold.species_reference_scales.begin(), cold.species_reference_scales.end(),
                  positive_scale) &&
      accepted_terminal_metric(cold.reference_residual[0], cold.pdf_before_flow ? 0.0 : cold.stopping->momentum, !cold.pdf_before_flow) &&
      accepted_terminal_metric(cold.reference_residual[1], cold.pdf_before_flow ? 0.0 : cold.stopping->enthalpy, !cold.pdf_before_flow) &&
      accepted_terminal_metric(cold.reference_residual[2], cold.pdf_before_flow ? 0.0 : cold.stopping->species, !cold.pdf_before_flow);
  const bool valid_cold_norms = cold.stopping
      ? valid_reference_stopping &&
        accepted_terminal_metric(cold.momentum_residual, 0.0, false) &&
        accepted_terminal_metric(cold.enthalpy_residual, 0.0, false) &&
        accepted_terminal_metric(cold.species_residual, 0.0, false)
      : accepted_terminal_metric(cold.momentum_residual, cold.pdf_before_flow ? 0.0 : 1e-10, !cold.pdf_before_flow) &&
        accepted_terminal_metric(cold.enthalpy_residual, cold.pdf_before_flow ? 0.0 : 1e-10, !cold.pdf_before_flow) &&
        accepted_terminal_metric(cold.species_residual,
                                  cold.pdf_before_flow ? 0.0 : 128.0 * std::numeric_limits<double>::epsilon(), !cold.pdf_before_flow) &&
        cold.momentum_reference_scale == 0.0 && !cold.momentum_reference_from_corrector &&
        cold.enthalpy_reference_scale == 0.0 &&
        cold.species_reference_scales.empty() &&
        cold.reference_residual == std::array<double, 3U>{};
  const bool valid_cold =
      cold.active && cold.outer_iterations > 0U &&
      (!cold.midpoint_passive || cold.passive_scalar_count != 0U) &&
      accepted_terminal_metric(cold.passive_residual,cold.pdf_before_flow ? 0.0 : 128.0*std::numeric_limits<double>::epsilon(),!cold.pdf_before_flow) &&
      accepted_terminal_metric(cold.passive_balance_defect,cold.pdf_before_flow ? 0.0 : 128.0*std::numeric_limits<double>::epsilon(),!cold.pdf_before_flow) &&
      (cold.passive_scalar_count != 0U || (cold.passive_solve_calls==0U &&
       cold.passive_iterations==0U && cold.passive_residual==0.0 && cold.passive_balance_defect==0.0)) &&
      (!cold.midpoint_enthalpy || cold.independent_species_count == 0U) &&
      (!cold.pressure_iccg || (std::isfinite(cold.pressure_original_l2_limit) &&
       cold.pressure_original_l2_limit > 0 &&
       accepted_terminal_metric(cold.pressure_original_l2,cold.pressure_original_l2_limit))) &&
      (cold.reference_outer_iterations == 0U ||
       cold.reference_outer_iterations == cold.outer_iterations) &&
      (!cold.pdf_before_flow ||
       (cold.independent_species_count > 0U &&
        cold.outer_iterations == (cold.reference_outer_iterations ? cold.reference_outer_iterations : 2U) &&
        cold.species_endpoint_solve_calls == 0U && cold.species_iterations == 0U)) &&
      cold.outer_iterations <= ColdCouplingReport::maximum_outer_iterations &&
      cold.momentum_solve_calls == 3U * cold.outer_iterations &&
      cold.pressure_solve_calls == cold.outer_iterations &&
      (cold.pdf_before_flow ? cold.enthalpy_solve_calls == 0U && cold.enthalpy_iterations == 0U : cold.enthalpy_solve_calls > 0U) &&
      cold.enthalpy_solve_calls <= cold.outer_iterations &&
      cold.enthalpy_retained_calls <= cold.outer_iterations &&
      cold.enthalpy_solve_calls + cold.enthalpy_retained_calls == (cold.pdf_before_flow ? 0U : cold.outer_iterations) &&
      cold.species_endpoint_solve_calls <= cold.outer_iterations &&
      cold.species_solve_calls ==
          (cold.independent_species_count == 0U || cold.pdf_before_flow ? 0U
              : cold.outer_iterations + cold.species_endpoint_solve_calls) &&
      (cold.independent_species_count != 0U ||
       (cold.species_endpoint_solve_calls == 0U &&
        cold.species_iterations == 0U && cold.species_residual == 0.0)) &&
      std::all_of(cold.final_momentum.begin(), cold.final_momentum.end(),
                  accepted_solve) &&
      accepted_solve(cold.final_pressure) &&
      (cold.pdf_before_flow || accepted_solve(cold.final_enthalpy)) &&
      cold.momentum_iterations >=
          std::uint64_t(cold.final_momentum[0].iterations) +
              cold.final_momentum[1].iterations +
              cold.final_momentum[2].iterations &&
      cold.pressure_iterations >= cold.final_pressure.iterations &&
      cold.enthalpy_iterations >= cold.final_enthalpy.iterations &&
      valid_cold_norms &&
      record.linear_iterations >= cold.momentum_iterations + cold.pressure_iterations +
                                      cold.enthalpy_iterations + cold.species_iterations + cold.passive_iterations &&
      cold.solid_velocity_max == 0.0 && record.bdf_order == 1U &&
      record.requested_bdf_order == 1U && !record.temporal_method_fallback &&
      record.pressure_solve_calls == 0U &&
      record.momentum_predictor_solve_calls == 0U &&
      record.momentum_predictor_passes == 0U &&
      !record.momentum_advective_cfl.present &&
      record.pressure_energy_refinement_solve_calls == 0U &&
      record.pressure_energy_refinement_termination ==
          RuntimePressureEnergyRefinementTermination::none;
  const bool pressure_continuity_contract =
      record.pressure_solve_contract ==
      RuntimePressureSolveContract::pressure_continuity;
  const bool continuity_energy_coupled_contract =
      record.pressure_solve_contract ==
      RuntimePressureSolveContract::continuity_energy_coupled;
  const bool valid_coupling =
      cold_contract
          ? valid_cold && record.coupling == RuntimeCouplingKind::cn_be
          : !cold.active && ((record.coupling == RuntimeCouplingKind::piso &&
                              record.momentum_predictor_passes == 1U) ||
                             (record.coupling == RuntimeCouplingKind::simple &&
                              record.momentum_predictor_passes == 2U));
  const auto& algorithm = record.algorithm;
  const bool valid_algorithm = !algorithm.present ||
      (record.requested_bdf_order == 1U && record.bdf_order == 1U &&
       (cold_contract
            ? algorithm.time_scheme == TimeScheme::cn_be &&
              algorithm.coupling == CouplingKind::outer_corrected
            : algorithm.time_scheme == TimeScheme::backward_euler &&
              ((algorithm.coupling == CouplingKind::piso &&
                record.coupling == RuntimeCouplingKind::piso) ||
               (algorithm.coupling == CouplingKind::simple &&
                record.coupling == RuntimeCouplingKind::simple))));
  const RuntimeTerminalPhysicalAudit& terminal =
      record.terminal_physical_audit;
  constexpr double kConvectiveCflComparisonSlack =
      1.0 + 64.0 * std::numeric_limits<double>::epsilon();
  const RuntimeCommittedConvectiveCflAudit& committed =
      record.committed_convective_cfl;
  const bool valid_committed_convective_cfl =
      committed.valid &&
      committed.density_revision != 0U &&
      committed.final_flux_revision == terminal.final_flux_revision &&
      committed.density_view_collective != 0U &&
      committed.final_flux_view_collective != 0U &&
      ((record.stl == 0U) == (committed.activity_collective == 0U)) &&
      std::isfinite(committed.dt) && committed.dt > 0.0 &&
      std::isfinite(committed.out_max) && committed.out_max >= 0.0 &&
      std::isfinite(committed.abs_max) && committed.abs_max >= 0.0 &&
      std::isfinite(committed.limit) && committed.limit > 0.0 &&
      valid_cfl_definition(committed.definition) &&
      std::isfinite(committed.directional_max) && committed.directional_max >= 0 &&
      (committed.definition != ConvectiveCflDefinition::directional_max ||
       (valid_runtime_cfl_winner(committed.directional_winner,committed.dt) &&
        committed.directional_winner.directional == committed.directional_max)) &&
      selected_cfl(committed.definition,committed.out_max,committed.directional_max) <=
          committed.limit * kConvectiveCflComparisonSlack &&
      valid_runtime_cfl_winner(committed.out_winner, committed.dt) &&
      valid_runtime_cfl_winner(committed.abs_winner, committed.dt) &&
      committed.out_winner.out == committed.out_max &&
      committed.abs_winner.absolute == committed.abs_max;
  const RuntimeAdvectiveCflAudit& advective =
      record.momentum_advective_cfl;
  const bool valid_advective_convective_cfl =
      advective.present && advective.plan != 0U &&
      advective.time_revision_collective != 0U &&
      advective.density_view_collective != 0U &&
      advective.face_flux_view_collective != 0U &&
      ((record.stl == 0U) == (advective.activity_collective == 0U)) &&
      advective.face_flux_view_collective !=
          committed.final_flux_view_collective &&
      std::isfinite(advective.dt) && advective.dt > 0.0 &&
      std::isfinite(advective.out_max) && advective.out_max >= 0.0 &&
      std::isfinite(advective.abs_max) && advective.abs_max >= 0.0 &&
      std::isfinite(advective.limit) && advective.limit > 0.0 &&
      advective.limit == committed.limit && advective.dt == committed.dt &&
      advective.definition == committed.definition &&
      std::isfinite(advective.directional_max) && advective.directional_max >= 0 &&
      selected_cfl(advective.definition,advective.out_max,advective.directional_max) <=
          advective.limit * kConvectiveCflComparisonSlack;
  const bool valid_terminal_physical_audit =
      terminal.present && terminal.final_flux_revision != 0U &&
      accepted_terminal_metric(terminal.eos_residual, terminal.eos_tolerance) &&
      accepted_terminal_metric(terminal.continuity_residual,
          cold_contract && cold.pdf_before_flow ? 0.0 : terminal.continuity_tolerance,
          !(cold_contract && cold.pdf_before_flow)) &&
      accepted_terminal_metric(
          terminal.energy_residual, cold_contract && cold.pdf_before_flow ? 0.0 : terminal.energy_tolerance,
          continuity_energy_coupled_contract || (cold_contract && !cold.pdf_before_flow)) &&
      accepted_terminal_metric(terminal.closed_mass_residual,
                               terminal.closed_mass_tolerance) &&
      accepted_terminal_metric(terminal.gauge_residual,
                               terminal.gauge_tolerance) &&
      valid_committed_convective_cfl &&
      (!cold_contract || !cold.stopping ||
       (terminal.energy_residual == cold.reference_residual[1] &&
        terminal.energy_tolerance == cold.stopping->enthalpy));
  const bool valid_temporal_method =
      (record.requested_bdf_order == 1U ||
       record.requested_bdf_order == 2U) &&
      (record.bdf_order == 1U || record.bdf_order == 2U) &&
      (record.temporal_method_fallback
           ? record.requested_bdf_order == 2U && record.bdf_order == 1U &&
                 record.thermophysical_predictor_calls == 2U
           : record.requested_bdf_order == record.bdf_order &&
                 record.thermophysical_predictor_calls == 1U);
  const bool valid_fast_predictor_collectives =
      record.temporal_method_fallback
          ? record.predictor_blocking_collectives > 1U
          : record.predictor_blocking_collectives == 1U;
  const bool enthalpy_endpoint_converged =
      record.predictor_enthalpy_endpoint.status &&
      (record.predictor_enthalpy_endpoint.termination ==
           LinearTermination::converged ||
       record.predictor_enthalpy_endpoint.termination ==
           LinearTermination::zero_rhs);
  const bool uses_enthalpy_endpoint = record.predictor_low_state == 3U ||
                                      record.predictor_low_state == 4U;
  const bool valid_enthalpy_endpoint =
      uses_enthalpy_endpoint
          ? record.predictor_enthalpy_solve_calls == 1U &&
                enthalpy_endpoint_converged &&
                record.predictor_enthalpy_endpoint.operator_applies > 0U &&
                record.predictor_enthalpy_endpoint.reduction_calls > 0U &&
                std::isfinite(record.predictor_enthalpy_endpoint_alpha) &&
                record.predictor_enthalpy_endpoint_alpha >= 0.0 &&
                record.predictor_enthalpy_endpoint_alpha <= 1.0 &&
                (record.predictor_low_state != 3U ||
                 record.predictor_enthalpy_endpoint_alpha == 1.0) &&
                (record.predictor_low_state != 4U ||
                 record.predictor_enthalpy_endpoint_alpha < 1.0)
          : record.predictor_enthalpy_solve_calls == 0U &&
                record.predictor_enthalpy_endpoint_alpha == 1.0;
  const bool valid_bdf_endpoint =
      std::isfinite(record.predictor_bdf_endpoint_alpha) &&
      record.predictor_bdf_endpoint_alpha >= 0.0 &&
      record.predictor_bdf_endpoint_alpha <= 1.0 &&
      (record.predictor_low_state == 5U
           ? record.predictor_bdf_endpoint_alpha < 1.0
           : record.predictor_bdf_endpoint_alpha == 1.0);
  const bool valid_source_endpoint =
      std::isfinite(record.predictor_source_endpoint_alpha) &&
      record.predictor_source_endpoint_alpha >= 0.0 &&
      record.predictor_source_endpoint_alpha <= 1.0 &&
      (record.predictor_low_state == 7U
           ? record.predictor_source_endpoint_alpha < 1.0
           : record.predictor_source_endpoint_alpha == 1.0);
  const bool valid_momentum_correction_metrics =
      record.momentum_correction_metrics_applicable
          ? record.momentum_active_correction_faces > 0U &&
                record.momentum_predictor_activations <=
                    record.momentum_active_correction_faces &&
                std::isfinite(record.momentum_minimum_face_alpha) &&
                record.momentum_minimum_face_alpha >= 0.0 &&
                record.momentum_minimum_face_alpha <= 1.0 &&
                std::isfinite(record.momentum_limited_face_fraction) &&
                record.momentum_limited_face_fraction ==
                    static_cast<double>(
                        record.momentum_predictor_activations) /
                        static_cast<double>(
                            record.momentum_active_correction_faces)
          : record.momentum_active_correction_faces == 0U &&
                record.momentum_predictor_activations == 0U &&
                record.momentum_minimum_face_alpha == 0.0 &&
                record.momentum_limited_face_fraction == 0.0;
  const bool valid_momentum_predictor =
      std::isfinite(record.momentum_predictor_theta) &&
      record.momentum_predictor_theta > 0.0 &&
      record.momentum_predictor_theta <= 1.0 &&
      (record.momentum_predictor_limited
           ? record.momentum_predictor_activations > 0U &&
                 record.momentum_predictor_theta < 1.0
           : record.momentum_predictor_activations == 0U &&
                 record.momentum_predictor_theta == 1.0) &&
      valid_momentum_correction_metrics &&
      (record.momentum_correction_metrics_applicable ||
       !record.momentum_predictor_limited);
  const bool valid_predictor =
      std::isfinite(record.predictor_theta) &&
      record.predictor_theta >= 0.0 && record.predictor_theta <= 1.0 &&
      std::isfinite(record.predictor_mass_flux_scale) &&
      record.predictor_mass_flux_scale >= 0.0 &&
      record.predictor_mass_flux_scale <= 1.0 &&
      (!record.predictor_limited
           ? record.predictor_theta == 1.0 &&
                 record.predictor_mass_flux_scale == 1.0 &&
                 record.predictor_low_margin == 0.0 &&
                 record.predictor_high_margin == 0.0 &&
                 record.predictor_low_order_substeps == 0U &&
                 record.predictor_low_order_halo_exchanges == 0U &&
                 valid_fast_predictor_collectives &&
                 record.predictor_low_order_transport_passes == 0U &&
                 record.predictor_limiting_rank == -1 &&
                 record.predictor_constraint == 0U &&
                 record.predictor_low_state == 0U
           : record.predictor_theta < 1.0 &&
                 std::isfinite(record.predictor_low_margin) &&
                 record.predictor_low_margin >= 0.0 &&
                 std::isfinite(record.predictor_high_margin) &&
                 record.predictor_high_margin < 0.0 &&
                 record.predictor_low_order_substeps > 0U &&
                 ((record.predictor_low_state == 6U ||
                   record.predictor_low_state == 7U)
                      ? record.predictor_low_order_halo_exchanges == 1U
                      : record.predictor_low_order_halo_exchanges ==
                            record.predictor_low_order_substeps - 1U) &&
                 record.predictor_blocking_collectives > 1U &&
                 record.predictor_low_order_transport_passes > 0U &&
                 record.predictor_limiting_cell_x >= 0 &&
                 record.predictor_limiting_cell_y >= 0 &&
                 record.predictor_limiting_cell_z >= 0 &&
                 record.predictor_limiting_rank >= 0 &&
                 record.predictor_constraint >= 1U &&
                 record.predictor_constraint <= 7U &&
                 record.predictor_low_state >= 1U &&
                 record.predictor_low_state <= 7U &&
                 (record.predictor_low_state != 1U ||
                  record.predictor_mass_flux_scale == 1.0) &&
                 (record.predictor_low_state != 5U ||
                  record.predictor_mass_flux_scale == 1.0) &&
                 ((record.predictor_low_state != 6U &&
                   record.predictor_low_state != 7U) ||
                  record.predictor_mass_flux_scale >= 0.0) &&
                 ((record.predictor_low_state != 3U &&
                   record.predictor_low_state != 4U) ||
                  record.predictor_mass_flux_scale == 1.0)) &&
      valid_enthalpy_endpoint && valid_bdf_endpoint && valid_source_endpoint;
  const std::size_t refinement_count =
      record.pressure_energy_refinement_solve_calls;
  bool valid_refinement =
      refinement_count <= record.pressure_energy_refinement.size() &&
      record.pressure_energy_refinement_termination ==
          RuntimePressureEnergyRefinementTermination::
              component_residuals_converged;
  RevisionToken refinement_target_generation = 0U;
  std::uint64_t refinement_linear_iterations = 0U;
  for (std::size_t index = 0U; valid_refinement && index < refinement_count;
       ++index) {
    const RuntimePressureEnergyRefinementSolve& entry =
        record.pressure_energy_refinement[index];
    const LinearSolveResult& solve = entry.solve;
    const bool accepted_termination =
        solve.termination == LinearTermination::converged ||
        solve.termination == LinearTermination::zero_rhs;
    const bool finite = std::isfinite(solve.initial_true_residual) &&
                        solve.initial_true_residual >= 0.0 &&
                        std::isfinite(solve.final_true_residual) &&
                        solve.final_true_residual >= 0.0 &&
                        std::isfinite(solve.recursive_residual) &&
                        solve.recursive_residual >= 0.0;
    const bool valid_capture_counts =
        solve.recycle_capture_cycle_attempts >=
            solve.recycle_cycle_corrections &&
        solve.recycle_capture_cycle_attempts <=
            std::numeric_limits<std::uint64_t>::max() / 2U &&
        solve.recycle_capture_vector_passes ==
            2U * solve.recycle_capture_cycle_attempts &&
        solve.recycle_capture_reduction_calls ==
            solve.recycle_capture_cycle_attempts &&
        solve.recycle_capture_blocking_operations ==
            2U * solve.recycle_capture_cycle_attempts;
    const bool valid_capture_role =
        solve.convergence_audits == 0U &&
        solve.convergence_rejections == 0U &&
        solve.final_convergence_metric == 0.0 &&
        solve.convergence_limit == 0.0 &&
        solve.recycle_offered_directions == 0U &&
        solve.recycle_retained_directions == 0U &&
        solve.recycle_operator_applies == 0U &&
        solve.recycle_reduction_calls == 0U &&
        !solve.recycle_projection_attempted &&
        !solve.recycle_projection_accepted &&
        solve.recycle_projected_true_residual == 0.0;
    const bool same_target =
        entry.target_generation != 0U &&
        (index == 0U ||
         entry.target_generation == refinement_target_generation);
    bool unique_lineage = entry.collective_lineage != 0U;
    for (std::size_t prior = 0U; unique_lineage && prior < index; ++prior)
      unique_lineage =
          record.pressure_energy_refinement[prior].collective_lineage !=
          entry.collective_lineage;
    valid_refinement =
        solve.status && accepted_termination && finite &&
        valid_capture_counts && valid_capture_role && same_target &&
        unique_lineage && entry.ordinal == index + 1U;
    if (index == 0U)
      refinement_target_generation = entry.target_generation;
    if (solve.iterations >
        std::numeric_limits<std::uint64_t>::max() -
            refinement_linear_iterations) {
      valid_refinement = false;
    } else {
      refinement_linear_iterations += solve.iterations;
    }
  }
  valid_refinement =
      valid_refinement &&
      record.linear_iterations >= refinement_linear_iterations;
  if (detail::output_service(services, RuntimeServiceKind::evidence) ==
          nullptr ||
      record.build == 0U || record.binary == 0U || record.case_model == 0U ||
      record.product == 0U || record.step == 0U ||
      !valid_algorithm ||
      record.candidate_identity.cold_schema != cold_contract ||
      !detail::valid_runtime_candidate_identity(record.candidate_identity) ||
      record.build != detail::runtime_sha256_fingerprint(
                          record.candidate_identity.build_manifest) ||
      record.binary != detail::runtime_sha256_fingerprint(
                           record.candidate_identity.executable) ||
      !valid_runtime_run_start(record) ||
      !std::isfinite(record.previous_committed_time) ||
      !std::isfinite(record.time) ||
      !(record.time > record.previous_committed_time) ||
      std::abs((record.time - record.previous_committed_time) -
               record.committed_convective_cfl.dt) >
          128.0 * std::numeric_limits<double>::epsilon() *
              std::max({1.0, std::abs(record.time),
                        std::abs(record.previous_committed_time),
                        std::abs(record.momentum_advective_cfl.dt)}) ||
      !valid_temporal_method ||
      ((record.startup || record.retry || record.restart_recovery) &&
       record.statistics_eligible) ||
      (!cold_contract && record.pressure_solve_calls != 2U) ||
      !valid_coupling ||
      (!pressure_continuity_contract && !continuity_energy_coupled_contract &&
       !cold_contract) ||
      (!cold_contract && !valid_refinement) || !valid_terminal_physical_audit ||
      (!cold_contract && record.momentum_predictor_solve_calls != 3U) ||
      record.blocking_collectives < record.predictor_blocking_collectives ||
      (!cold_contract &&
       (!valid_momentum_predictor || !valid_advective_convective_cfl)) ||
      !valid_predictor ||
      (record.stages.size != 0U && record.stages.data == nullptr))
    return {StatusCode::invalid_plan, detail::kOutputInput};
  for (std::size_t corrector = 0U; corrector < record.pressure_solve_calls;
       ++corrector) {
    const LinearSolveResult& solve = record.pressure[corrector];
    const bool accepted_termination =
        solve.termination == LinearTermination::converged ||
        solve.termination == LinearTermination::zero_rhs;
    const bool finite = std::isfinite(solve.initial_true_residual) &&
                        solve.initial_true_residual >= 0.0 &&
                        std::isfinite(solve.final_true_residual) &&
                        solve.final_true_residual >= 0.0 &&
                        std::isfinite(solve.recursive_residual) &&
                        solve.recursive_residual >= 0.0;
    const bool no_linear_audit =
        solve.convergence_audits == 0U &&
        solve.convergence_rejections == 0U &&
        solve.final_convergence_metric == 0.0 &&
        solve.convergence_limit == 0.0;
    const bool accepted_linear_audit =
        solve.convergence_audits > 0U &&
        solve.convergence_rejections <= solve.convergence_audits &&
        std::isfinite(solve.final_convergence_metric) &&
        solve.final_convergence_metric >= 0.0 &&
        std::isfinite(solve.convergence_limit) &&
        solve.convergence_limit > 0.0 &&
        solve.final_convergence_metric <= solve.convergence_limit;
    const bool valid_audit =
        corrector == 0U
            ? no_linear_audit
            : (pressure_continuity_contract ? accepted_linear_audit
                                            : no_linear_audit);
    const bool valid_recycle_counts =
        solve.recycle_offered_directions <= kLinearRecycleMaximumDirections &&
        solve.recycle_retained_directions <=
            solve.recycle_offered_directions &&
        solve.recycle_capture_cycle_attempts >=
            solve.recycle_cycle_corrections &&
        solve.recycle_capture_cycle_attempts <=
            std::numeric_limits<std::uint64_t>::max() / 2U &&
        solve.recycle_capture_vector_passes ==
            2U * solve.recycle_capture_cycle_attempts &&
        solve.recycle_capture_reduction_calls ==
            solve.recycle_capture_cycle_attempts &&
        solve.recycle_capture_blocking_operations ==
            2U * solve.recycle_capture_cycle_attempts;
    const bool valid_recycle_role =
        corrector == 0U
            ? solve.recycle_offered_directions == 0U &&
                  solve.recycle_retained_directions == 0U &&
                  solve.recycle_operator_applies == 0U &&
                  solve.recycle_reduction_calls == 0U &&
                  !solve.recycle_projection_attempted &&
                  !solve.recycle_projection_accepted &&
                  solve.recycle_projected_true_residual == 0.0
            : solve.recycle_capture_vector_passes == 0U &&
                  solve.recycle_cycle_corrections == 0U &&
                  solve.recycle_capture_cycle_attempts == 0U &&
                  solve.recycle_capture_reduction_calls == 0U &&
                  solve.recycle_capture_blocking_operations == 0U &&
                  ((!solve.recycle_projection_attempted &&
                    solve.recycle_retained_directions == 0U &&
                    solve.recycle_operator_applies == 0U &&
                    solve.recycle_reduction_calls == 0U &&
                    !solve.recycle_projection_accepted &&
                    solve.recycle_projected_true_residual == 0.0) ||
                   (solve.recycle_projection_attempted &&
                    solve.recycle_offered_directions > 0U &&
                    solve.recycle_reduction_calls > 0U &&
                    solve.recycle_operator_applies ==
                        solve.recycle_offered_directions +
                            (solve.recycle_retained_directions != 0U ? 1U : 0U) &&
                    std::isfinite(solve.recycle_projected_true_residual) &&
                    solve.recycle_projected_true_residual >= 0.0 &&
                    (solve.recycle_retained_directions != 0U ||
                     (!solve.recycle_projection_accepted &&
                      solve.recycle_reduction_calls ==
                          solve.recycle_offered_directions &&
                      solve.recycle_projected_true_residual == 0.0))));
    const bool projection_improved =
        solve.recycle_projection_attempted &&
        solve.recycle_retained_directions > 0U &&
        solve.recycle_projected_true_residual <
            solve.initial_true_residual;
    const bool valid_recycle_admission =
        solve.recycle_projection_accepted == projection_improved &&
        (!solve.recycle_projection_accepted || solve.iterations != 0U ||
         solve.final_true_residual ==
             solve.recycle_projected_true_residual);
    if (!solve.status || !accepted_termination || !finite || !valid_audit ||
        !valid_recycle_counts || !valid_recycle_role ||
        !valid_recycle_admission)
      return {StatusCode::invalid_plan, detail::kOutputInput};
  }
  if (!cold_contract)
    for (const LinearSolveResult &solve : record.momentum_predictor) {
      const bool accepted_termination =
          solve.termination == LinearTermination::converged ||
          solve.termination == LinearTermination::zero_rhs;
      const bool finite = std::isfinite(solve.initial_true_residual) &&
                          solve.initial_true_residual >= 0.0 &&
                          std::isfinite(solve.final_true_residual) &&
                          solve.final_true_residual >= 0.0 &&
                          std::isfinite(solve.recursive_residual) &&
                          solve.recursive_residual >= 0.0;
      if (!solve.status || !accepted_termination || !finite ||
          solve.final_true_residual > solve.initial_true_residual ||
          solve.convergence_audits != 0U ||
          solve.convergence_rejections != 0U ||
          solve.recycle_offered_directions != 0U ||
          solve.recycle_retained_directions != 0U ||
          solve.recycle_operator_applies != 0U ||
          solve.recycle_reduction_calls != 0U ||
          solve.recycle_projection_attempted ||
          solve.recycle_projection_accepted ||
          solve.recycle_projected_true_residual != 0.0 ||
          solve.recycle_cycle_corrections != 0U ||
          solve.recycle_capture_vector_passes != 0U ||
          solve.recycle_capture_cycle_attempts != 0U ||
          solve.recycle_capture_reduction_calls != 0U ||
          solve.recycle_capture_blocking_operations != 0U)
        return {StatusCode::invalid_plan, detail::kOutputInput};
    }
  const std::uint64_t expected_offered_directions =
      std::min<std::uint64_t>(
          record.pressure[0U].recycle_cycle_corrections,
          static_cast<std::uint64_t>(kLinearRecycleMaximumDirections));
  if (record.pressure[1U].recycle_offered_directions !=
      expected_offered_directions)
    return {StatusCode::invalid_plan, detail::kOutputInput};
  for (std::size_t index = 0U; index < record.stages.size; ++index) {
    const StageTimingRecord stage = record.stages.data[index];
    if (stage.stage == 0U ||
        stage.minimum_nanoseconds > stage.mean_nanoseconds ||
        stage.mean_nanoseconds > stage.maximum_nanoseconds)
      return {StatusCode::invalid_plan, detail::kOutputInput};
    for (std::size_t prior = 0U; prior < index; ++prior)
      if (record.stages.data[prior].stage == stage.stage)
        return {StatusCode::invalid_plan, detail::kOutputInput};
  }
  return {};
}

std::string encode_record(const RuntimeEvidenceRecord& record) {
  std::ostringstream json;
  json.exceptions(std::ios::badbit | std::ios::failbit);
  json.imbue(std::locale::classic());
  json << std::setprecision(17)
       << "{\"schema\":\"" << (record.cold.active ? detail::kColdRuntimeEvidenceSchema : detail::kRuntimeEvidenceSchema) << "\""
       << ",\"build\":" << record.build
       << ",\"binary\":" << record.binary
       << ",\"candidate_identity\":{\"schema\":\""
       << detail::kRuntimeCandidateIdentitySchema << "\""
       << ",\"head\":\"" << record.candidate_identity.head.data()
       << "\",\"tree\":\"" << record.candidate_identity.tree.data()
       << "\",\"build_manifest_sha256\":\""
       << record.candidate_identity.build_manifest.data()
       << "\",\"executable_sha256\":\""
       << record.candidate_identity.executable.data()
       << "\",\"identity_sha256\":\""
       << record.candidate_identity.identity.data() << "\"}"
       << ",\"case\":" << record.case_model
       << ",\"stl\":" << record.stl
       << ",\"product\":" << record.product
       << ",\"cpu_plan\":" << record.cpu_plan;
  if (record.algorithm.present) {
    json << ",\"algorithm\":{\"time_scheme\":\""
         << (record.algorithm.time_scheme == TimeScheme::cn_be ? "cn_be" : "backward_euler")
         << "\",\"coupling\":\""
         << (record.algorithm.coupling == CouplingKind::outer_corrected ? "outer_corrected"
             : record.algorithm.coupling == CouplingKind::simple ? "SIMPLE" : "PISO")
         << "\"}";
  }
  json << ",\"run_start\":{\"kind\":\""
       << (record.run_start.kind == RuntimeRunStartKind::restart
               ? "restart"
               : "fresh")
       << "\",\"previous_step\":" << record.run_start.previous_step
       << ",\"previous_time\":" << record.run_start.previous_time
       << ",\"restart_manifest_sha256\":";
  if (record.run_start.kind == RuntimeRunStartKind::restart) {
    json << '\"' << record.run_start.restart_manifest_sha256.data() << '\"';
  } else {
    json << "null";
  }
  if (record.run_start.source_format_version != 0U) {
    json << ",\"history\":{\"source_format_version\":" << record.run_start.source_format_version
         << ",\"source_signature\":" << record.run_start.source_history_signature
         << ",\"target_signature\":" << record.run_start.target_history_signature
         << ",\"policy\":\""
         << (record.run_start.history_policy == RestartHistoryPolicy::rebuild_method_history
                 ? "rebuild_method_history"
                 : record.run_start.history_policy == RestartHistoryPolicy::refine_chemistry
                     ? "refine_chemistry" : "require_compatible") << "\"";
    if (record.run_start.transport_source_case != 0U)
      json << (record.run_start.history_policy == RestartHistoryPolicy::refine_chemistry
          ? ",\"chemistry_source_case\":" : ",\"transport_source_case\":")
           << record.run_start.transport_source_case;
    json << '}';
  }
  json << '}'
       << ",\"step\":" << record.step
       << ",\"previous_committed_time\":"
       << record.previous_committed_time
       << ",\"time\":" << record.time
       << ",\"requested_bdf_order\":"
       << static_cast<unsigned>(record.requested_bdf_order)
       << ",\"bdf_order\":" << static_cast<unsigned>(record.bdf_order)
       << ",\"coupling\":\"" << coupling_name(record.coupling) << "\""
       << ",\"temporal_method_fallback\":"
       << (record.temporal_method_fallback ? "true" : "false")
       << ",\"thermophysical_predictor_calls\":"
       << static_cast<unsigned>(record.thermophysical_predictor_calls)
       << ",\"launcher_ns\":" << record.launcher_nanoseconds
       << ",\"max_rank_step_ns\":"
       << record.maximum_rank_step_nanoseconds
       << ",\"max_rank_rss_bytes\":" << record.maximum_rank_rss_bytes
       << ",\"max_node_rss_bytes\":" << record.maximum_node_rss_bytes
       << ",\"structured_messages\":" << record.structured_messages
       << ",\"structured_bytes\":" << record.structured_bytes
       << ",\"ibm_messages\":" << record.ibm_messages
       << ",\"ibm_bytes\":" << record.ibm_bytes
       << ",\"blocking_collectives\":" << record.blocking_collectives
       << ",\"nonblocking_collectives\":"
       << record.nonblocking_collectives
       << ",\"reduction_ns\":" << record.reduction_nanoseconds
       << ",\"linear_iterations\":" << record.linear_iterations
       << ",\"exact_numeric_refills\":" << record.exact_numeric_refills
       << ",\"coarse_numeric_refills\":" << record.coarse_numeric_refills
       << ",\"preconditioner_setups\":" << record.preconditioner_setups
       << ",\"preconditioner_reuses\":" << record.preconditioner_reuses
       << ",\"heap_allocations\":" << record.heap_allocations
       << ",\"pressure_solve_calls\":"
       << static_cast<unsigned>(record.pressure_solve_calls)
       << ",\"pressure_solve_contract\":\""
       << pressure_solve_contract_name(record.pressure_solve_contract)
       << "\""
       << ",\"pressure_energy_refinement_solve_calls\":"
       << static_cast<unsigned>(
              record.pressure_energy_refinement_solve_calls)
       << ",\"pressure_energy_refinement_termination\":\""
       << pressure_energy_refinement_termination_name(
              record.pressure_energy_refinement_termination)
       << "\""
       << ",\"terminal_physical_audit\":{\"present\":"
       << (record.terminal_physical_audit.present ? "true" : "false")
       << ",\"final_flux_revision\":"
       << record.terminal_physical_audit.final_flux_revision
       << ",\"eos_residual\":"
       << record.terminal_physical_audit.eos_residual
       << ",\"eos_tolerance\":"
       << record.terminal_physical_audit.eos_tolerance
       << ",\"continuity_residual\":"
       << record.terminal_physical_audit.continuity_residual
       << ",\"continuity_tolerance\":"
       << record.terminal_physical_audit.continuity_tolerance
       << ",\"energy_residual\":"
       << record.terminal_physical_audit.energy_residual
       << ",\"energy_tolerance\":"
       << record.terminal_physical_audit.energy_tolerance
       << ",\"closed_mass_residual\":"
       << record.terminal_physical_audit.closed_mass_residual
       << ",\"closed_mass_tolerance\":"
       << record.terminal_physical_audit.closed_mass_tolerance
       << ",\"gauge_residual\":"
       << record.terminal_physical_audit.gauge_residual
       << ",\"gauge_tolerance\":"
       << record.terminal_physical_audit.gauge_tolerance
       << ",\"committed_convective_cfl\":{\"valid\":"
       << (record.committed_convective_cfl.valid ? "true" : "false")
       << ",\"density_revision\":"
       << record.committed_convective_cfl.density_revision
       << ",\"final_flux_revision\":"
       << record.committed_convective_cfl.final_flux_revision
       << ",\"density_view\":{\"field\":"
       << record.committed_convective_cfl.density_field
       << ",\"collective\":"
       << record.committed_convective_cfl.density_view_collective
       << "},\"face_flux_view\":{\"collective\":"
       << record.committed_convective_cfl.final_flux_view_collective
       << "},\"activity_collective\":"
       << record.committed_convective_cfl.activity_collective
       << ",\"dt\":" << record.committed_convective_cfl.dt
       << ",\"out_max\":" << record.committed_convective_cfl.out_max
       << ",\"abs_max\":" << record.committed_convective_cfl.abs_max
       << ",\"definition\":\"" << cfl_definition_name(record.committed_convective_cfl.definition) << '"'
       << ",\"directional_max\":" << record.committed_convective_cfl.directional_max
       << ",\"limit\":" << record.committed_convective_cfl.limit;
  const auto encode_cfl_winner = [&](std::string_view name,
                                     const RuntimeConvectiveCflWinner& winner) {
    json << ",\"" << name << "\":{\"valid\":"
         << (winner.valid ? "true" : "false")
         << ",\"global_cell\":[" << winner.global_cell.x << ','
         << winner.global_cell.y << ',' << winner.global_cell.z
         << "],\"rank\":" << winner.rank << ",\"out\":" << winner.out
         << ",\"abs\":" << winner.absolute
         << ",\"density_volume\":" << winner.density_volume
         << ",\"outgoing_mass_flow\":" << winner.outgoing_mass_flow
         << ",\"absolute_mass_flow\":" << winner.absolute_mass_flow
         << ",\"directional\":" << winner.directional
         << ",\"maximum_face_mass_flow\":" << winner.maximum_face_mass_flow
         << '}';
  };
  encode_cfl_winner("out_winner",
                    record.committed_convective_cfl.out_winner);
  encode_cfl_winner("abs_winner",
                    record.committed_convective_cfl.abs_winner);
  encode_cfl_winner("directional_winner",record.committed_convective_cfl.directional_winner);
  json << "}}"
       << ",\"momentum_predictor_solve_calls\":"
       << static_cast<unsigned>(record.momentum_predictor_solve_calls)
       << ",\"momentum_predictor_passes\":"
       << static_cast<unsigned>(record.momentum_predictor_passes)
       << ",\"momentum_predictor_limiter\":{\"scheme\":\"common_face_afc_v3_owner\",\"limited\":"
       << (record.momentum_predictor_limited ? "true" : "false")
       << ",\"correction_metrics_applicability\":\""
       << (record.momentum_correction_metrics_applicable ? "applicable"
                                                         : "not_applicable")
       << "\",\"retained_correction_l1_ratio\":";
  if (record.momentum_correction_metrics_applicable)
    json << record.momentum_predictor_theta;
  else
    json << "null";
  json << ",\"minimum_face_alpha\":";
  if (record.momentum_correction_metrics_applicable)
    json << record.momentum_minimum_face_alpha;
  else
    json << "null";
  json << ",\"active_correction_faces\":"
       << record.momentum_active_correction_faces
       << ",\"limited_faces\":"
       << record.momentum_predictor_activations
       << ",\"limited_face_fraction\":";
  if (record.momentum_correction_metrics_applicable)
    json << record.momentum_limited_face_fraction;
  else
    json << "null";
  json
       << ",\"advective_cfl\":{\"present\":"
       << (record.momentum_advective_cfl.present ? "true" : "false")
       << ",\"plan\":" << record.momentum_advective_cfl.plan
       << ",\"time_revision_collective\":"
       << record.momentum_advective_cfl.time_revision_collective
       << ",\"density_view_collective\":"
       << record.momentum_advective_cfl.density_view_collective
       << ",\"face_flux_view_collective\":"
       << record.momentum_advective_cfl.face_flux_view_collective
       << ",\"activity_collective\":"
       << record.momentum_advective_cfl.activity_collective
       << ",\"dt\":" << record.momentum_advective_cfl.dt
       << ",\"out_max\":" << record.momentum_advective_cfl.out_max
       << ",\"abs_max\":" << record.momentum_advective_cfl.abs_max
       << ",\"definition\":\"" << cfl_definition_name(record.momentum_advective_cfl.definition) << '"'
       << ",\"directional_max\":" << record.momentum_advective_cfl.directional_max
       << ",\"limit\":" << record.momentum_advective_cfl.limit
       << "}}"
       << ",\"thermophysical_predictor\":{\"limited\":"
       << (record.predictor_limited ? "true" : "false")
       << ",\"theta\":" << record.predictor_theta
       << ",\"low_state\":\""
       << predictor_low_state_name(record.predictor_low_state)
       << "\",\"mass_flux_scale\":"
       << record.predictor_mass_flux_scale
       << ",\"constraint\":\""
       << predictor_constraint_name(record.predictor_constraint)
       << "\",\"limiting_rank\":"
       << record.predictor_limiting_rank
       << ",\"limiting_global_cell\":["
       << record.predictor_limiting_cell_x << ','
       << record.predictor_limiting_cell_y << ','
       << record.predictor_limiting_cell_z
       << "],\"low_margin\":"
       << record.predictor_low_margin
       << ",\"high_margin\":"
       << record.predictor_high_margin
       << ",\"low_order_substeps\":"
       << record.predictor_low_order_substeps
       << ",\"low_order_transport_passes\":"
       << record.predictor_low_order_transport_passes
       << ",\"low_order_halo_exchanges\":"
       << record.predictor_low_order_halo_exchanges
       << ",\"blocking_collectives\":"
       << record.predictor_blocking_collectives
       << ",\"enthalpy_endpoint_alpha\":"
       << record.predictor_enthalpy_endpoint_alpha
       << ",\"bdf_endpoint_alpha\":"
       << record.predictor_bdf_endpoint_alpha
       << ",\"source_endpoint_alpha\":"
       << record.predictor_source_endpoint_alpha
       << ",\"enthalpy_solve_calls\":"
       << static_cast<unsigned>(record.predictor_enthalpy_solve_calls) << '}'
       << ",\"thermophysical_enthalpy_endpoint\":{\"status_code\":"
       << static_cast<unsigned>(record.predictor_enthalpy_endpoint.status.code)
       << ",\"termination\":\""
       << termination_name(record.predictor_enthalpy_endpoint.termination)
       << "\",\"iterations\":"
       << record.predictor_enthalpy_endpoint.iterations
       << ",\"initial_true_residual\":"
       << record.predictor_enthalpy_endpoint.initial_true_residual
       << ",\"final_true_residual\":"
       << record.predictor_enthalpy_endpoint.final_true_residual
       << ",\"recursive_residual\":"
       << record.predictor_enthalpy_endpoint.recursive_residual
       << ",\"reduction_calls\":"
       << record.predictor_enthalpy_endpoint.reduction_calls
       << ",\"operator_applies\":"
       << record.predictor_enthalpy_endpoint.operator_applies
       << ",\"preconditioner_applies\":"
       << record.predictor_enthalpy_endpoint.preconditioner_applies
       << ",\"norm_breakdown_restarts\":"
       << record.predictor_enthalpy_endpoint.norm_breakdown_restarts << '}'
       << ",\"pressure\":[";
  for (std::size_t corrector = 0U; corrector < record.pressure_solve_calls;
       ++corrector) {
    if (corrector != 0U) json << ',';
    const LinearSolveResult& solve = record.pressure[corrector];
    json << "{\"corrector\":" << corrector + 1U
         << ",\"status_code\":"
         << static_cast<unsigned>(solve.status.code)
         << ",\"termination\":\"" << termination_name(solve.termination)
         << "\",\"iterations\":" << solve.iterations
         << ",\"initial_true_residual\":" << solve.initial_true_residual
         << ",\"final_true_residual\":" << solve.final_true_residual
         << ",\"recursive_residual\":" << solve.recursive_residual
         << ",\"reduction_calls\":" << solve.reduction_calls
         << ",\"operator_applies\":" << solve.operator_applies
         << ",\"preconditioner_applies\":"
         << solve.preconditioner_applies
         << ",\"norm_breakdown_restarts\":"
         << solve.norm_breakdown_restarts
         << ",\"convergence_audits\":" << solve.convergence_audits
         << ",\"convergence_rejections\":"
         << solve.convergence_rejections
         << ",\"final_convergence_metric\":"
         << solve.final_convergence_metric
         << ",\"convergence_limit\":" << solve.convergence_limit
         << ",\"recycle_offered_directions\":"
         << solve.recycle_offered_directions
         << ",\"recycle_retained_directions\":"
         << solve.recycle_retained_directions
         << ",\"recycle_operator_applies\":"
         << solve.recycle_operator_applies
         << ",\"recycle_reduction_calls\":"
         << solve.recycle_reduction_calls
         << ",\"recycle_projection_attempted\":"
         << (solve.recycle_projection_attempted ? "true" : "false")
         << ",\"recycle_projection_accepted\":"
         << (solve.recycle_projection_accepted ? "true" : "false")
         << ",\"recycle_projected_true_residual\":"
         << solve.recycle_projected_true_residual
         << ",\"recycle_cycle_corrections\":"
         << solve.recycle_cycle_corrections
         << ",\"recycle_capture_vector_passes\":"
         << solve.recycle_capture_vector_passes
         << ",\"recycle_capture_cycle_attempts\":"
         << solve.recycle_capture_cycle_attempts
         << ",\"recycle_capture_reduction_calls\":"
         << solve.recycle_capture_reduction_calls
         << ",\"recycle_capture_blocking_operations\":"
         << solve.recycle_capture_blocking_operations << '}';
  }
  json << ']' << ",\"pressure_energy_refinement\":[";
  for (std::size_t index = 0U;
       index < record.pressure_energy_refinement_solve_calls; ++index) {
    if (index != 0U) json << ',';
    const RuntimePressureEnergyRefinementSolve& entry =
        record.pressure_energy_refinement[index];
    const LinearSolveResult& solve = entry.solve;
    json << "{\"ordinal\":" << static_cast<unsigned>(entry.ordinal)
         << ",\"target_generation\":" << entry.target_generation
         << ",\"collective_lineage\":" << entry.collective_lineage
         << ",\"status_code\":"
         << static_cast<unsigned>(solve.status.code)
         << ",\"termination\":\"" << termination_name(solve.termination)
         << "\",\"iterations\":" << solve.iterations
         << ",\"initial_true_residual\":" << solve.initial_true_residual
         << ",\"final_true_residual\":" << solve.final_true_residual
         << ",\"recursive_residual\":" << solve.recursive_residual
         << ",\"reduction_calls\":" << solve.reduction_calls
         << ",\"operator_applies\":" << solve.operator_applies
         << ",\"preconditioner_applies\":"
         << solve.preconditioner_applies
         << ",\"norm_breakdown_restarts\":"
         << solve.norm_breakdown_restarts
         << ",\"convergence_audits\":" << solve.convergence_audits
         << ",\"convergence_rejections\":"
         << solve.convergence_rejections
         << ",\"final_convergence_metric\":"
         << solve.final_convergence_metric
         << ",\"convergence_limit\":" << solve.convergence_limit
         << ",\"recycle_offered_directions\":"
         << solve.recycle_offered_directions
         << ",\"recycle_retained_directions\":"
         << solve.recycle_retained_directions
         << ",\"recycle_operator_applies\":"
         << solve.recycle_operator_applies
         << ",\"recycle_reduction_calls\":"
         << solve.recycle_reduction_calls
         << ",\"recycle_projection_attempted\":"
         << (solve.recycle_projection_attempted ? "true" : "false")
         << ",\"recycle_projection_accepted\":"
         << (solve.recycle_projection_accepted ? "true" : "false")
         << ",\"recycle_projected_true_residual\":"
         << solve.recycle_projected_true_residual
         << ",\"recycle_cycle_corrections\":"
         << solve.recycle_cycle_corrections
         << ",\"recycle_capture_vector_passes\":"
         << solve.recycle_capture_vector_passes
         << ",\"recycle_capture_cycle_attempts\":"
         << solve.recycle_capture_cycle_attempts
         << ",\"recycle_capture_reduction_calls\":"
         << solve.recycle_capture_reduction_calls
         << ",\"recycle_capture_blocking_operations\":"
         << solve.recycle_capture_blocking_operations << '}';
  }
  json << ']' << ",\"momentum_predictor\":[";
  for (std::size_t component = 0U;
       component < record.momentum_predictor_solve_calls; ++component) {
    if (component != 0U) json << ',';
    const LinearSolveResult& solve = record.momentum_predictor[component];
    json << "{\"component\":" << component
         << ",\"status_code\":"
         << static_cast<unsigned>(solve.status.code)
         << ",\"termination\":\"" << termination_name(solve.termination)
         << "\",\"iterations\":" << solve.iterations
         << ",\"initial_true_residual\":" << solve.initial_true_residual
         << ",\"final_true_residual\":" << solve.final_true_residual
         << ",\"recursive_residual\":" << solve.recursive_residual
         << ",\"reduction_calls\":" << solve.reduction_calls
         << ",\"operator_applies\":" << solve.operator_applies
         << ",\"preconditioner_applies\":"
         << solve.preconditioner_applies
         << ",\"norm_breakdown_restarts\":"
         << solve.norm_breakdown_restarts << '}';
  }
  json << ']'
       << ",\"startup\":" << (record.startup ? "true" : "false")
       << ",\"retry\":" << (record.retry ? "true" : "false")
       << ",\"restart_recovery\":"
       << (record.restart_recovery ? "true" : "false")
       << ",\"statistics_eligible\":"
       << (record.statistics_eligible ? "true" : "false")
       << ",\"stages\":[";
  for (std::size_t index = 0U; index < record.stages.size; ++index) {
    if (index != 0U) json << ',';
    const StageTimingRecord stage = record.stages.data[index];
    json << "{\"id\":" << stage.stage << ",\"min_ns\":"
         << stage.minimum_nanoseconds << ",\"mean_ns\":"
         << stage.mean_nanoseconds << ",\"max_ns\":"
         << stage.maximum_nanoseconds << '}';
  }
  json << ']';
  if (record.cold.active) {
    const auto &cold = record.cold;
    json << ",\"cold\":{\"outer_iterations\":" << cold.outer_iterations
         << ",\"reference_outer_iterations\":" << cold.reference_outer_iterations
         << ",\"pdf_before_flow\":" << (cold.pdf_before_flow ? "true" : "false")
         << ",\"enthalpy_scheme\":\"" << (cold.midpoint_enthalpy ? "CN" : "BE") << "\""
         << ",\"pressure_iccg\":" << (cold.pressure_iccg ? "true" : "false")
         << ",\"pressure_original_l2\":" << cold.pressure_original_l2
         << ",\"pressure_original_l2_limit\":" << cold.pressure_original_l2_limit
         << ",\"momentum_solve_calls\":" << cold.momentum_solve_calls
         << ",\"pressure_solve_calls\":" << cold.pressure_solve_calls
         << ",\"enthalpy_solve_calls\":" << cold.enthalpy_solve_calls
         << ",\"enthalpy_retained_calls\":" << cold.enthalpy_retained_calls
         << ",\"species_solve_calls\":" << cold.species_solve_calls
         << ",\"species_endpoint_solve_calls\":" << cold.species_endpoint_solve_calls
         << ",\"independent_species_count\":" << cold.independent_species_count
         << ",\"passive_scalar_count\":" << cold.passive_scalar_count
         << ",\"passive_scheme\":\"" << (cold.midpoint_passive ? "CN" : "BE") << '"'
         << ",\"passive_solve_calls\":" << cold.passive_solve_calls
         << ",\"passive_iterations\":" << cold.passive_iterations
         << ",\"passive_residual\":" << cold.passive_residual
         << ",\"passive_balance_defect\":" << cold.passive_balance_defect
         << ",\"momentum_iterations\":" << cold.momentum_iterations
         << ",\"pressure_iterations\":" << cold.pressure_iterations
         << ",\"enthalpy_iterations\":" << cold.enthalpy_iterations
         << ",\"species_iterations\":" << cold.species_iterations
         << ",\"momentum_residual\":" << cold.momentum_residual
         << ",\"species_residual\":" << cold.species_residual
         << ",\"enthalpy_residual\":" << cold.enthalpy_residual
         << ",\"solid_velocity_max\":" << cold.solid_velocity_max
         << ",\"normalization\":\"" << (cold.stopping ? "reference" : "local_time") << "\"";
    if (cold.stopping) {
      json << ",\"reference_time\":" << cold.stopping->reference_time
           << ",\"reference_tolerances\":[" << cold.stopping->momentum << ','
           << cold.stopping->enthalpy << ',' << cold.stopping->species << ']'
           << ",\"reference_residuals\":[" << cold.reference_residual[0] << ','
           << cold.reference_residual[1] << ',' << cold.reference_residual[2] << ']'
           << ",\"momentum_reference_scale\":" << cold.momentum_reference_scale
           << ",\"enthalpy_reference_scale\":" << cold.enthalpy_reference_scale
           << ",\"species_reference_scales\":[";
      for (std::size_t j = 0; j < cold.species_reference_scales.size(); ++j) {
        if (j) json << ',';
        json << cold.species_reference_scales[j];
      }
      json << ']';
      if (cold.momentum_reference_from_corrector)
        json << ",\"momentum_reference_origin\":\"first_corrector\"";
    }
    const auto write_final_solve = [&](const LinearSolveResult& solve) {
      json << "{\"status_code\":" << unsigned(solve.status.code)
           << ",\"termination\":\"" << termination_name(solve.termination)
           << "\",\"iterations\":" << solve.iterations
           << ",\"initial_true_residual\":" << solve.initial_true_residual
           << ",\"final_true_residual\":" << solve.final_true_residual
           << ",\"recursive_residual\":" << solve.recursive_residual << '}';
    };
    json << ",\"final_momentum\":[";
    for (std::size_t j = 0; j < cold.final_momentum.size(); ++j) {
      if (j) json << ',';
      write_final_solve(cold.final_momentum[j]);
    }
    json << "],\"final_pressure\":";
    write_final_solve(cold.final_pressure);
    json << ",\"final_enthalpy\":";
    write_final_solve(cold.final_enthalpy);
    json << '}';
  }
  json << "}\n";
  return json.str();
}

std::uint64_t hash_text(std::string_view text) noexcept {
  std::uint64_t hash = UINT64_C(1469598103934665603);
  for (const unsigned char value : text) {
    hash ^= value;
    hash *= UINT64_C(1099511628211);
  }
  return hash == 0U ? 1U : hash;
}

}  // namespace

Status detail::runtime_encode_evidence_line(MPI_Comm communicator,
                                            const IoServicePlan& services,
                                            const RuntimeEvidenceRecord& record,
                                            std::string& line) noexcept {
  line.clear();
  if (communicator == MPI_COMM_NULL)
    return {StatusCode::invalid_plan, detail::kOutputInput};
  std::string candidate;
  Status status =
      detail::output_collective_stage(communicator, [&]() -> Status {
        const Status validation = validate_record(services, record);
        if (!validation) return validation;
        candidate = encode_record(record);
        const RuntimeServiceCapacity* capacity =
            detail::output_service(services, RuntimeServiceKind::evidence);
        if (capacity == nullptr ||
            candidate.size() > capacity->maximum_staging_bytes_per_rank)
          return {StatusCode::invalid_plan, detail::kOutputCapacity};
        return {};
      });
  if (!status) return status;
  const std::uint64_t local_hash = hash_text(candidate);
  std::uint64_t minimum = local_hash;
  std::uint64_t maximum = local_hash;
  if (MPI_Allreduce(MPI_IN_PLACE, &minimum, 1, MPI_UINT64_T, MPI_MIN,
                    communicator) != MPI_SUCCESS ||
      MPI_Allreduce(MPI_IN_PLACE, &maximum, 1, MPI_UINT64_T, MPI_MAX,
                    communicator) != MPI_SUCCESS)
    return {StatusCode::mpi_failure, detail::kOutputCollective};
  if (minimum == 0U || minimum != maximum)
    return {StatusCode::invalid_plan, detail::kOutputInput};
  line = std::move(candidate);
  return {};
}

Status EvidenceWriter::append(MPI_Comm communicator,
                              const std::filesystem::path& evidence_file,
                              const IoServicePlan& services,
                              const RuntimeEvidenceRecord& record,
                              IoFailureContext* failure) noexcept {
  detail::IoFailureCapture capture(failure);
  int rank = 0;
  if (communicator == MPI_COMM_NULL ||
      MPI_Comm_rank(communicator, &rank) != MPI_SUCCESS)
    return {StatusCode::invalid_plan, detail::kOutputInput};
  std::filesystem::path parent;
  Status status = detail::output_collective_stage(
      communicator,
      [&]() -> Status {
        parent = evidence_file.parent_path();
        return evidence_file.empty() || parent.empty()
                   ? Status{StatusCode::invalid_plan, detail::kOutputInput}
                   : Status{};
      },
      &capture.context);
  if (!status) return status;
  std::string text;
  status = detail::runtime_encode_evidence_line(communicator, services, record,
                                                text);
  if (!status) return status;
  status = detail::output_create_directory(communicator, rank, parent,
                                           &capture.context);
  if (!status) return status;
  if (rank == 0) {
    status =
        detail::output_write_file(evidence_file, text, true, &capture.context)
            ? Status{}
            : Status{StatusCode::io_failure, detail::kOutputFile};
  }
  return detail::output_collective_status(communicator, status,
                                          &capture.context);
}

}  // namespace hundun::v04
