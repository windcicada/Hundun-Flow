// SPDX-License-Identifier: Apache-2.0
// Developed by WANG YUDONG | Email: wangyudong@buaa.edu.cn | Github/Wechat: windcicada | Year.M: 2026.09

#pragma once

#include "hundun/v04_io.hpp"

#include <mpi.h>

namespace hundun::v04::detail {

inline constexpr std::string_view kRuntimeEvidenceSchema =
    "HUNDUN_V04_EVIDENCE_V8";
inline constexpr std::string_view kColdRuntimeEvidenceSchema =
    "HUNDUN_V04_EVIDENCE_V9";
inline constexpr std::string_view kRuntimeCandidateIdentitySchema =
    "HUNDUN_V04_RUNTIME_CANDIDATE_IDENTITY_V2";

Status runtime_candidate_identity(MPI_Comm communicator,
                                  RuntimeCandidateIdentity& out,
                                  std::string_view target_manifest = {},
                                  bool cold_schema = false) noexcept;
bool valid_runtime_candidate_identity(
    const RuntimeCandidateIdentity& identity) noexcept;
PlanFingerprint runtime_sha256_fingerprint(
    const std::array<char, kRuntimeSha256HexCharacters + 1U>& digest) noexcept;
bool valid_runtime_sha256(const RuntimeSha256Digest& digest) noexcept;
bool runtime_sha256_bytes(Span<const std::uint8_t> bytes,
                          RuntimeSha256Digest& out) noexcept;

}  // namespace hundun::v04::detail
