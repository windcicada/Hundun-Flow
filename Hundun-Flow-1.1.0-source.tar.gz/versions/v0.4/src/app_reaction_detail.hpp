// SPDX-License-Identifier: Apache-2.0
#pragma once

#include "hundun/v04_case.hpp"
#include "esf_count_detail.hpp"
#include <cmath>
#include <limits>

namespace hundun::v04::detail {
inline bool valid_esf_spec(const EsfSpec& e) {
  if (!esf::valid_field_count(e.fields) || e.initial_species_offsets.size() > 1024)
    return false;
  for (double value : e.initial_species_offsets)
    if (!std::isfinite(value) || value < -1 || value > 1) return false;
  const auto& t = e.tcr;
  if (!std::isfinite(t.weak_rate_threshold) || t.weak_rate_threshold <= 0 ||
      t.initialization_sign < -1 || t.initialization_sign > 1) return false;
  const auto valid_name=[](const std::string &name) {
    return !name.empty() && name.size()<=255 && name.find('\0')==std::string::npos;
  };
  if (dynamic_tcr_model(t.model))
    return (t.mode == TcrMode::experimental || t.mode == TcrMode::shadow) &&
        valid_name(t.fuel) &&
        (t.model==TcrModel::dyn711_v1 ? valid_name(t.mixture_fraction) &&
            std::isfinite(t.oxidizer_oxygen_mass_fraction) &&
            t.oxidizer_oxygen_mass_fraction>0 && t.oxidizer_oxygen_mass_fraction<=1
            : t.mixture_fraction.empty() && t.oxidizer_oxygen_mass_fraction==0) &&
        t.reactants.empty() && t.progress_weights.empty() && t.initialization_sign == 0;
  if (t.model != TcrModel::reactant_root_v1 || !t.fuel.empty() || !t.mixture_fraction.empty() ||
      t.oxidizer_oxygen_mass_fraction!=0) return false;
  if (t.mode == TcrMode::off)
    return t.reactants.empty() && t.progress_weights.empty() && t.initialization_sign == 0;
  if ((t.mode != TcrMode::shadow && t.mode != TcrMode::experimental && t.mode != TcrMode::validated) ||
      t.reactants.empty() || t.reactants.size() > 255 ||
      t.progress_weights.empty() || t.progress_weights.size() > 255) return false;
  for (const auto& name : t.reactants)
    if (name.empty() || name.size() > 255 || name.find('\0') != std::string::npos) return false;
  for (double value : t.progress_weights)
    if (!std::isfinite(value)) return false;
  return true;
}
inline bool valid_reaction_spec(const ReactionSpec &r) {
  if ((r.mode == ReactionMode::esf_tpdf) != r.esf.has_value() ||
      (r.esf && !valid_esf_spec(*r.esf))) return false;
  if (r.mode == ReactionMode::none)
    return r.mechanism_sha256.empty() && r.phase.empty() &&
           r.mechanism_file.empty() &&
           r.representation == ReactionSpec::Representation::external_provider;
  if (r.mode != ReactionMode::finite_rate_mean &&
      r.mode != ReactionMode::pasr_algebraic_v1 &&
      r.mode != ReactionMode::esf_tpdf)
    return false;
  if (r.mechanism_sha256.size() != 64 ||
      r.mechanism_sha256.find_first_not_of("0123456789abcdef") !=
          std::string::npos ||
      r.phase.empty() || r.phase.size() > 255 || r.phase.find('\0') != std::string::npos ||
      !std::isfinite(r.relative_tolerance) || r.relative_tolerance <= 0 ||
      r.relative_tolerance >= 1 || !std::isfinite(r.absolute_tolerance) ||
      r.absolute_tolerance <= 0 || r.maximum_internal_steps == 0 ||
      r.maximum_internal_steps >
          std::uint32_t(std::numeric_limits<int>::max()) ||
      !std::isfinite(r.mixing_c_z) || r.mixing_c_z <= 0 ||
      !std::isfinite(r.turbulent_schmidt) || r.turbulent_schmidt <= 0 ||
      !std::isfinite(r.analytic_rate_s) || r.analytic_rate_s < 0 ||
      (r.analytic_cp_j_per_kg_k != 1000 && r.analytic_cp_j_per_kg_k != 1200))
    return false;
  switch (r.representation) {
  case ReactionSpec::Representation::external_provider:
  case ReactionSpec::Representation::analytic_isomer:
    return r.mechanism_file.empty();
  case ReactionSpec::Representation::direct_cantera:
    // The case reader additionally opens a bounded direct-root regular file.
    return !r.mechanism_file.empty() && !r.mechanism_file.has_parent_path() &&
           r.mechanism_file.extension() == ".yaml" &&
           r.mechanism_file.native().size() <= 255;
  }
  return false;
}
} // namespace hundun::v04::detail
